class_name HealthOrb
extends Node3D
## Glowing green orb dropped by robots. Drifts to the player when close and heals.

var _t := 0.0
var _player: Player
var _mesh: MeshInstance3D


func _ready() -> void:
	_player = get_tree().get_first_node_in_group("player") as Player
	_mesh = MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 0.2
	s.height = 0.4
	_mesh.mesh = s
	_mesh.material_override = Fx3D.glow_mat(Color(0.3, 1.0, 0.5), 5.0)
	add_child(_mesh)
	var l := OmniLight3D.new()
	l.light_color = Color(0.3, 1.0, 0.5)
	l.light_energy = 1.5
	l.omni_range = 3.0
	add_child(l)


func _physics_process(delta: float) -> void:
	_t += delta
	if _t > 14.0:
		queue_free()
		return
	_mesh.position.y = sin(_t * 3.0) * 0.12
	if global_position.y > 0.8:
		global_position.y = move_toward(global_position.y, 0.8, delta * 4.0)
	if _player == null or not _player.alive:
		return
	var target := _player.global_position + Vector3(0, 1.0, 0)
	var d := global_position.distance_to(target)
	if d < 6.0:
		global_position = global_position.move_toward(target, delta * (14.0 - d))
	if d < 0.9:
		_player.heal(15.0)
		Audio.play("pickup", -6.0)
		Fx3D.sparks(get_parent(), global_position, Color(0.3, 1.0, 0.5), 16, 4.0, 0.06, 0.4, 2.0)
		queue_free()
