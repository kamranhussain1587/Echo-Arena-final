class_name Player
extends CharacterBody3D
## First-person fighter: movement (double jump, flash-step dash), block/parry,
## camera juice (shake, FOV kick, tilt, weapon bob) and the hit pipeline.
## The fighter-specific moves live in a Kit (player/kits/*.gd).

signal hp_changed(hp: float, max_hp: float)
signal ult_changed(value: float)
signal died

const SPEED := 8.5
const ACCEL := 70.0
const AIR_ACCEL := 25.0
const GRAVITY := 24.0
const JUMP := 9.0
const DASH_SPEED := 30.0
const DASH_TIME := 0.15
const DASH_CD := 0.5
const BASE_FOV := 80.0

var fighter: int = 0
var max_hp := 100.0
var hp := 100.0
var ult := 0.0
var kit: Kit
var head: Node3D
var cam: Camera3D
var vm_root: Node3D
var hud: Node
var overlay: Node
var alive := true
var controls := true
var blocking := false
var invuln := 0.0
var speed_mult := 1.0
var damage_mult := 1.0
var combo := 0

var _parry_t := 0.0
var _dash_t := 0.0
var _dash_cd := 0.0
var _dash_dir := Vector3.ZERO
var _dash_speed := DASH_SPEED
var _jumps := 0
var _shake := 0.0
var _fov_kick := 0.0
var _tilt := 0.0
var _bob_t := 0.0
var _sway := Vector2.ZERO
var _combo_t := 0.0
var _was_floor := true
var _vm_base := Vector3.ZERO
var _block_vis := 0.0

## Style rank (D..SSS): climbs with hits, drops when you get hit.
const STYLE_LETTERS: Array[String] = ["D", "C", "B", "A", "S", "SS", "SSS"]
const STYLE_NAMES: Array[String] = ["DECENT", "COOL", "BRUTAL", "AMAZING", "SAVAGE", "SUPREME", "UNSTOPPABLE"]
var style := 0.0
var _style_rank := 0
var _dash_iframe := false
var _perfect_used := false
var _shield: MeshInstance3D
var _shield_mat: ShaderMaterial
var _shield_hit := 0.0
var _land_dip := 0.0

const SHIELD_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, shadows_disabled;
uniform vec4 color : source_color = vec4(0.3, 0.9, 1.0, 1.0);
uniform float alpha = 0.0;
uniform float hit = 0.0;
varying vec3 lp;
float hexd(vec2 p) { p = abs(p); return max(dot(p, normalize(vec2(1.0, 1.732))), p.x); }
void vertex() { lp = VERTEX; }
void fragment() {
	vec2 uv = lp.xz * 10.0;
	vec2 r = vec2(1.0, 1.732);
	vec2 h = r * 0.5;
	vec2 a = mod(uv, r) - h;
	vec2 b = mod(uv - h, r) - h;
	vec2 g = dot(a, a) < dot(b, b) ? a : b;
	float edge = smoothstep(0.455, 0.49, hexd(g));
	float rad = length(lp.xz) / 0.75;
	float fres = pow(clamp(rad, 0.0, 1.0), 3.0);
	float center_clear = mix(0.25, 1.0, smoothstep(0.15, 0.75, rad));
	float ripple = hit * smoothstep(0.08, 0.0, abs(rad - (1.0 - hit * 0.6)));
	float m = ((edge * 0.13 + 0.012) * center_clear + fres * 0.4 + ripple * 0.7) * alpha + hit * edge * 0.22 * alpha;
	ALBEDO = mix(color.rgb, vec3(1.0), hit * 0.5) * 1.15 * m;
	ALPHA = clamp(m, 0.0, 1.0);
}
"""


func _ready() -> void:
	add_to_group("player")
	collision_layer = 2
	collision_mask = 1 | 4
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)
	head = Node3D.new()
	head.position.y = 1.6
	add_child(head)
	cam = Camera3D.new()
	cam.fov = BASE_FOV
	cam.near = 0.03
	cam.far = 700.0
	head.add_child(cam)
	cam.current = true
	vm_root = Node3D.new()
	cam.add_child(vm_root)
	_shield = MeshInstance3D.new()
	var dome := SphereMesh.new()
	dome.radius = 0.75
	dome.height = 1.5
	dome.is_hemisphere = true
	dome.radial_segments = 48
	dome.rings = 16
	_shield.mesh = dome
	_shield_mat = ShaderMaterial.new()
	var ssh := Shader.new()
	ssh.code = SHIELD_SHADER
	_shield_mat.shader = ssh
	_shield.material_override = _shield_mat
	_shield.rotation.x = -PI * 0.5
	_shield.position = Vector3(0, -0.05, -0.12)
	_shield.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	cam.add_child(_shield)
	fighter = Game.fighter
	kit = load(Fighters.KIT_SCRIPTS[fighter]).new()
	add_child(kit)
	kit.setup(self)
	_shield_mat.set_shader_parameter("color", Fighters.color(fighter))
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _input(event: InputEvent) -> void:
	if not alive or not controls or get_tree().paused:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var s: float = Game.settings.sensitivity
		rotate_y(-event.relative.x * s)
		head.rotation.x = clampf(head.rotation.x - event.relative.y * s, deg_to_rad(-85), deg_to_rad(85))
		_sway += Vector2(event.relative.x, event.relative.y) * 0.0006
	elif event is InputEventMouseButton and event.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _physics_process(delta: float) -> void:
	_dash_cd = maxf(_dash_cd - delta, 0.0)
	_parry_t = maxf(_parry_t - delta, 0.0)
	invuln = maxf(invuln - delta, 0.0)
	if invuln <= 0.0:
		_dash_iframe = false
	_combo_t -= delta
	if _combo_t <= 0.0:
		combo = 0
		style = maxf(style - delta * (10.0 + style * 0.06), 0.0)
	_update_style_rank()

	var input := Vector2.ZERO
	if alive and controls:
		input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var wish := (transform.basis * Vector3(input.x, 0, input.y))
	wish.y = 0
	wish = wish.normalized() * input.length()
	var on_floor := is_on_floor()
	if on_floor:
		_jumps = 0

	blocking = alive and controls and Input.is_action_pressed("block") and _dash_t <= 0.0
	if alive and controls and Input.is_action_just_pressed("block"):
		_parry_t = 0.2

	if _dash_t > 0.0:
		_dash_t -= delta
		velocity = _dash_dir * _dash_speed
		if _dash_t <= 0.0:
			velocity = _dash_dir * SPEED * 0.8
	else:
		var top := SPEED * speed_mult * (0.45 if blocking else 1.0)
		var accel := ACCEL if on_floor else AIR_ACCEL
		var hv := Vector3(velocity.x, 0, velocity.z).move_toward(wish * top, accel * delta)
		velocity.x = hv.x
		velocity.z = hv.z
		velocity.y -= GRAVITY * delta
		if alive and controls and Input.is_action_just_pressed("jump"):
			if on_floor:
				velocity.y = JUMP
				_jumps = 1
				Audio.play("jump", -10.0)
			elif _jumps < 2:
				velocity.y = JUMP * 0.92
				_jumps = 2
				Audio.play("jump", -8.0, 0.05, 1.3)
				Fx3D.ring(get_parent(), global_position + Vector3(0, 0.1, 0), Fighters.color(fighter), 1.6, 0.3, 0.15)
		if alive and controls and Input.is_action_just_pressed("dash") and _dash_cd <= 0.0:
			var dir := wish if wish.length() > 0.1 else -transform.basis.z
			start_dash(dir.normalized())

	move_and_slide()
	var now_floor := is_on_floor()
	if now_floor and not _was_floor:
		Audio.play("land", -14.0)
		_land_dip = 1.0
		kit.on_landed()
	_was_floor = now_floor

	if alive and controls:
		kit.physics(delta)
		if not blocking:
			kit.primary(Input.is_action_pressed("attack"), Input.is_action_just_pressed("attack"))
		if Input.is_action_just_pressed("skill_1"):
			kit.skill1_press()
		if Input.is_action_just_released("skill_1"):
			kit.skill1_release()
		if Input.is_action_just_pressed("skill_2"):
			kit.skill2()
		if Input.is_action_just_pressed("ultimate"):
			if ult >= 100.0:
				ult = 0.0
				ult_changed.emit(ult)
				kit.ultimate()
			elif hud != null:
				hud.notice("ULTIMATE NOT READY")


func start_dash(dir: Vector3, speed := DASH_SPEED, time := DASH_TIME) -> void:
	_dash_dir = dir
	_dash_speed = speed
	_dash_t = time
	_dash_cd = DASH_CD
	invuln = maxf(invuln, time + 0.08)
	_dash_iframe = true
	_perfect_used = false
	_fov_kick = 14.0
	velocity.y = maxf(velocity.y, 0.0)
	Audio.play("dash", -6.0)
	if overlay != null:
		overlay.speed_burst(0.6)


func is_dashing() -> bool:
	return _dash_t > 0.0


func _process(delta: float) -> void:
	var rd := delta / maxf(Engine.time_scale, 0.05)  # real-time delta for camera juice
	_shake = maxf(_shake - rd * 1.6, 0.0)
	var amt := _shake * _shake
	cam.h_offset = randf_range(-1, 1) * amt * 0.25
	cam.v_offset = randf_range(-1, 1) * amt * 0.25
	_fov_kick = lerpf(_fov_kick, 0.0, 1.0 - exp(-rd * 6.0))
	cam.fov = BASE_FOV + _fov_kick + (6.0 if speed_mult > 1.01 else 0.0)
	var strafe := 0.0
	if alive and controls:
		strafe = Input.get_axis("move_left", "move_right")
	_tilt = lerpf(_tilt, -strafe * 2.2, 1.0 - exp(-rd * 8.0))
	cam.rotation.z = deg_to_rad(_tilt)
	# Weapon bob & sway.
	var hspeed := Vector2(velocity.x, velocity.z).length()
	if is_on_floor() and hspeed > 1.0:
		_bob_t += delta * hspeed * 1.3
	_sway = _sway.lerp(Vector2.ZERO, 1.0 - exp(-rd * 8.0))
	_block_vis = move_toward(_block_vis, 1.0 if blocking else 0.0, rd * 8.0)
	var bob := Vector3(sin(_bob_t) * 0.025, -absf(cos(_bob_t)) * 0.025, 0) * clampf(hspeed / SPEED, 0, 1)
	vm_root.position = bob + Vector3(-_sway.x, _sway.y, 0) * 0.6 + Vector3(0, -0.06 * _block_vis, 0.08 * _block_vis)
	_land_dip = move_toward(_land_dip, 0.0, rd * 5.0)
	if alive:
		head.position.y = 1.6 - sin(_land_dip * PI) * 0.09 + (sin(_bob_t * 2.0) * 0.025 * clampf(hspeed / SPEED, 0, 1) if is_on_floor() else 0.0)
	_shield_hit = move_toward(_shield_hit, 0.0, rd * 3.0)
	_shield_mat.set_shader_parameter("alpha", _block_vis)
	_shield_mat.set_shader_parameter("hit", _shield_hit)
	_shield.visible = _block_vis > 0.01
	_shield.scale = Vector3.ONE * (0.92 + 0.08 * _block_vis + _shield_hit * 0.05)
	vm_root.rotation = Vector3(0.25 * _block_vis, 0, 0.35 * _block_vis)


func add_shake(amount: float) -> void:
	_shake = minf(_shake + amount, 1.2)


# --- combat ---------------------------------------------------------------

func aim_dir() -> Vector3:
	return -cam.global_transform.basis.z


func aim_origin() -> Vector3:
	return cam.global_position


## Where the crosshair points (world or enemy), up to max_dist.
func aim_point(max_dist := 60.0) -> Vector3:
	var from := aim_origin()
	var to := from + aim_dir() * max_dist
	var q := PhysicsRayQueryParameters3D.create(from, to, 1 | 4, [get_rid()])
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	return hit.position if not hit.is_empty() else to


func enemies() -> Array:
	var out := []
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and not e.dead:
			out.append(e)
	return out


func nearest_enemy(max_dist := 40.0, front_only := false) -> Node3D:
	var best: Node3D = null
	var best_d := max_dist
	for e in enemies():
		var to: Vector3 = e.aim_point() - aim_origin()
		var d := to.length()
		if front_only and to.normalized().dot(aim_dir()) < 0.6:
			continue
		if d < best_d:
			best_d = d
			best = e
	return best


## Melee sweep in front of the camera. Returns number of enemies hit.
func melee(reach: float, arc_deg: float, dmg: float, heavy := false, knock := 3.0) -> int:
	var hits := 0
	var fwd := aim_dir()
	var flat_fwd := Vector3(fwd.x, 0, fwd.z).normalized()
	var cos_half := cos(deg_to_rad(arc_deg * 0.5))
	for e in enemies():
		var to: Vector3 = e.aim_point() - aim_origin()
		var dist: float = to.length() - e.hit_radius
		if dist > reach:
			continue
		if dist > 0.6 and to.normalized().dot(fwd) < cos_half:
			continue
		var dealt: float = e.take_hit(dmg * damage_mult, flat_fwd * knock / 3.0, heavy, aim_origin())
		register_hit(e, dealt, e.aim_point(), heavy)
		hits += 1
	if hits > 0:
		Game.hitstop(0.07 if heavy else 0.035)
		add_shake(0.25 if heavy else 0.12)
	return hits


## Damage everything within radius of a point.
func area_damage(center: Vector3, radius: float, dmg: float, heavy := true, knock := 6.0) -> int:
	var hits := 0
	for e in enemies():
		var to: Vector3 = e.aim_point() - center
		if to.length() - e.hit_radius > radius:
			continue
		var dir := Vector3(to.x, 0.3, to.z).normalized()
		var dealt: float = e.take_hit(dmg * damage_mult, dir * knock / 3.0, heavy, center)
		register_hit(e, dealt, e.aim_point(), heavy)
		hits += 1
	return hits


## Damage everything near a line segment (beams, dashes).
func line_damage(a: Vector3, b: Vector3, radius: float, dmg: float, heavy := true) -> int:
	var hits := 0
	var ab := b - a
	var len2 := maxf(ab.length_squared(), 0.0001)
	for e in enemies():
		var p: Vector3 = e.aim_point()
		var t := clampf((p - a).dot(ab) / len2, 0.0, 1.0)
		var closest := a + ab * t
		if p.distance_to(closest) - e.hit_radius > radius:
			continue
		var dealt: float = e.take_hit(dmg * damage_mult, ab.normalized(), heavy, closest)
		register_hit(e, dealt, p, heavy)
		hits += 1
	return hits


## Every successful hit comes through here: ult charge, combo, numbers.
func register_hit(enemy: Node, dealt: float, pos: Vector3, heavy: bool) -> void:
	if dealt <= 0.0:
		return
	ult = minf(ult + dealt * (0.1 if enemy is Boss else 0.22) * (1.0 + _style_rank * 0.12), 100.0)
	style = minf(style + dealt * 0.7 + (12.0 if heavy else 0.0), 699.0)
	ult_changed.emit(ult)
	combo += 1
	_combo_t = 2.2
	var col := Fighters.color(fighter).lerp(Color.WHITE, 0.3) if heavy else Color(1, 1, 1)
	Fx3D.damage_number(get_parent(), pos, dealt, col, heavy)
	if hud != null:
		hud.hit_marker(enemy.dead if "dead" in enemy else false)


func take_damage(amount: float, from_pos: Vector3, source: Node = null) -> String:
	if not alive or Game.is_busy():
		return "ignored"
	if invuln > 0.0:
		if _dash_iframe and not _perfect_used and amount > 0.0:
			_perfect_dodge()
		return "ignored"
	var to_src := (from_pos - aim_origin())
	to_src.y = 0
	var facing := to_src.normalized().dot(Vector3(aim_dir().x, 0, aim_dir().z).normalized()) > 0.2
	if blocking and facing:
		if _parry_t > 0.0:
			Audio.play("parry", 0.0)
			Fx3D.sparks(get_parent(), aim_origin() + aim_dir() * 0.8, Color(1, 1, 0.7), 30, 9.0, 0.08)
			Fx3D.flash_light(get_parent(), aim_origin() + aim_dir(), Color(1, 1, 0.8), 8.0, 6.0, 0.25)
			Game.hitstop(0.12)
			add_shake(0.2)
			_shield_hit = 1.6
			style = minf(style + 50.0, 699.0)
			ult = minf(ult + 8.0, 100.0)
			ult_changed.emit(ult)
			if hud != null:
				hud.callout("PARRY!", Color(1, 0.95, 0.5))
			if source is Projectile:
				(source as Projectile).reflect(self)
			elif source != null and source.has_method("stun"):
				source.stun(1.6)
			return "parried"
		amount *= 0.2
		Audio.play("block", -4.0)
		_shield_hit = 1.0
		style = maxf(style - 15.0, 0.0)
		Fx3D.sparks(get_parent(), aim_origin() + aim_dir() * 0.7, Color(0.7, 0.9, 1.0), 10, 5.0, 0.05)
	hp = maxf(hp - amount, 0.0)
	hp_changed.emit(hp, max_hp)
	combo = 0
	if not (blocking and facing):
		style *= 0.35
	add_shake(0.35 if amount > 5.0 else 0.15)
	Audio.play("hurt", -6.0)
	if overlay != null:
		overlay.damage_flash(clampf(amount / 25.0, 0.3, 1.0))
	if hp <= 0.0:
		_die()
	return "blocked" if blocking and facing else "hit"


func _perfect_dodge() -> void:
	_perfect_used = true
	Game.slowmo(0.25, 1.3)
	Audio.play("perfect_dodge", 0.0)
	ult = minf(ult + 12.0, 100.0)
	ult_changed.emit(ult)
	style = minf(style + 70.0, 699.0)
	if hud != null:
		hud.callout("PERFECT DODGE!", Color(0.6, 1.0, 1.0))
	if overlay != null:
		overlay.time_stop(0.5)
		overlay.speed_burst(1.0)


func style_rank() -> int:
	return clampi(int(style / 100.0), 0, STYLE_LETTERS.size() - 1)


func _update_style_rank() -> void:
	var r := style_rank()
	if r > _style_rank:
		Audio.play("rank_up", -6.0, 0.0, 1.0 + r * 0.06)
		if hud != null and hud.has_method("style_pop"):
			hud.style_pop()
	_style_rank = r


func heal(amount: float) -> void:
	hp = minf(hp + amount, max_hp)
	hp_changed.emit(hp, max_hp)


func _die() -> void:
	alive = false
	controls = false
	Audio.play("explosion", -2.0)
	Game.slowmo(0.2, 1.5)
	var tw := create_tween()
	tw.tween_property(head, "position:y", 0.4, 0.8)
	tw.parallel().tween_property(cam, "rotation:z", deg_to_rad(35), 0.8)
	died.emit()
