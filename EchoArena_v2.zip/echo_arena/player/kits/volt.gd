extends Kit
## VOLT - energy. Rapid bolts, charged piercing beam, radial pulse, Starfall.

var _hands: Array[Node3D] = []
var _orbs: Array[MeshInstance3D] = []
var _next_hand := 0
var _charging := false
var _charge := 0.0
var _charge_orb: MeshInstance3D
var _charge_light: OmniLight3D
var _star_t := 0.0


func build_viewmodel() -> void:
	q_cd_max = 5.0
	e_cd_max = 7.0
	var glove := Fx3D.neon_mat(Color(0.05, 0.06, 0.09), color, 0.08, 0.7, 0.35)
	for side in [-1.0, 1.0]:
		var hand := Node3D.new()
		hand.position = Vector3(0.3 * side, -0.27, -0.55)
		vm.add_child(hand)
		make_mesh(box(Vector3(0.11, 0.11, 0.26)), glove, Vector3.ZERO, hand)
		make_mesh(box(Vector3(0.12, 0.03, 0.2)), Fx3D.glow_mat(color, 1.6), Vector3(0, 0.06, 0), hand)
		var orb := make_mesh(sphere(0.05), Fx3D.glow_mat(color, 2.5), Vector3(0, 0.03, -0.17), hand)
		hand_light(hand, 0.9)
		_hands.append(hand)
		_orbs.append(orb)
	_charge_orb = make_mesh(sphere(0.1), Fx3D.glow_mat(color, 3.5), Vector3(0, -0.2, -0.75))
	_charge_orb.visible = false
	_charge_light = hand_light(_charge_orb, 0.0)


func process_kit(delta: float) -> void:
	var t := Time.get_ticks_msec() * 0.001
	for i in _orbs.size():
		_orbs[i].scale = Vector3.ONE * (1.0 + sin(t * 12.0 + i) * 0.15)
	if _charging:
		_charge = minf(_charge + delta, 1.2)
		var k := _charge / 1.2
		_charge_orb.visible = true
		_charge_orb.scale = Vector3.ONE * (0.6 + k * 2.4) * (1.0 + sin(t * 40.0) * 0.06)
		_charge_light.light_energy = 1.0 + k * 5.0
		player.add_shake(0.004 * k)
	if ult_active > 0.0:
		_star_t -= delta
		if _star_t <= 0.0:
			_star_t = 0.09
			_starfall_bolt()


func primary(held: bool, _just: bool) -> void:
	if not held or primary_cd > 0.0 or _charging:
		return
	primary_cd = 0.13 if ult_active <= 0.0 else 0.07
	var hand := _hands[_next_hand]
	_next_hand = 1 - _next_hand
	jab(hand, Vector3(0, 0.02, -0.12), 0.04, 0.1)
	var from := (hand.global_position + player.aim_dir() * 0.3)
	var target := player.aim_point(80.0)
	var p := Projectile.spawn(world(), from, (target - from).normalized() * 60.0, 0, 9.0, color, 0.11)
	p.source = player
	p.light_energy = 1.2
	Audio.play("bolt", -12.0, 0.08)


func skill1_press() -> void:
	if q_cd > 0.0:
		cooldown_denied()
		return
	_charging = true
	_charge = 0.0
	Audio.play("beam_charge", -6.0)


func skill1_release() -> void:
	if not _charging:
		return
	_charging = false
	_charge_orb.visible = false
	_charge_light.light_energy = 0.0
	q_cd = q_cd_max
	var k := clampf(_charge / 1.2, 0.15, 1.0)
	var from := player.aim_origin() + player.aim_dir() * 0.6 + Vector3(0, -0.15, 0)
	var to := player.aim_origin() + player.aim_dir() * 50.0
	Fx3D.beam(world(), from, to, color, 0.25 + 0.45 * k, 0.45)
	player.line_damage(from, to, 0.8 + k * 0.6, 30.0 + 70.0 * k, true)
	player.add_shake(0.25 + 0.35 * k)
	player.velocity -= player.aim_dir() * 6.0 * k
	Audio.play("beam_fire", -2.0)
	if k > 0.5:
		callout("NOVA LANCE!")
	for h in _hands:
		jab(h, Vector3(0, 0.05, -0.2), 0.05, 0.3)


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var c := player.global_position + Vector3(0, 0.6, 0)
	Fx3D.ring(world(), player.global_position + Vector3(0, 0.15, 0), color, 7.5, 0.4, 0.12)
	Fx3D.ring(world(), c, Color.WHITE, 5.0, 0.3, 0.06)
	Fx3D.sparks(world(), c, color, 40, 12.0, 0.08, 0.5, -4.0)
	Fx3D.flash_light(world(), c, color, 10.0, 12.0, 0.4)
	player.area_damage(c, 7.0, 28.0, true, 14.0)
	player.add_shake(0.35)
	Audio.play("explosion", -4.0)
	callout("PULSE NOVA!")


func ultimate() -> void:
	start_ult(3.5, "STARFALL!!")


func _starfall_bolt() -> void:
	var list := player.enemies()
	var target_pos: Vector3
	if list.is_empty():
		target_pos = player.global_position + Vector3(randf_range(-12, 12), 0, randf_range(-12, 12))
	else:
		var e: Node3D = list[randi() % list.size()]
		if e.global_position.distance_to(player.global_position) > 40.0:
			return
		target_pos = e.aim_point() + Vector3(randf_range(-1, 1), 0, randf_range(-1, 1))
	var from := target_pos + Vector3(randf_range(-4, 4), 18.0, randf_range(-4, 4))
	var p := Projectile.spawn(world(), from, (target_pos - from).normalized() * 45.0, 0, 20.0, color, 0.25)
	p.explode_radius = 2.2
	p.heavy = true
	p.source = player
	p.light_energy = 3.0
