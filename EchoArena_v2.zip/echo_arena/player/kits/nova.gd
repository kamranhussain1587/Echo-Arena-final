extends Kit
## NOVA - gunslinger. Twin light pistols, Scatter Blast, Flash Grenade, Solar Barrage.

var _guns: Array[Node3D] = []
var _muzzles: Array[Node3D] = []
var _next := 0
var _barrage_t := 0.0
var _barrage_i := 0


func build_viewmodel() -> void:
	q_cd_max = 4.0
	e_cd_max = 7.0
	var metal := Fx3D.neon_mat(Color(0.1, 0.1, 0.12), Color(0, 0, 0, 0), 0.0, 0.9, 0.25)
	var gold := Fx3D.neon_mat(Color(0.5, 0.4, 0.1), color, 0.15, 1.0, 0.2)
	for side in [-1.0, 1.0]:
		var g := Node3D.new()
		g.position = Vector3(0.24 * side, -0.26, -0.5)
		g.rotation = Vector3(0.05, 0.04 * -side, 0)
		vm.add_child(g)
		make_mesh(box(Vector3(0.07, 0.17, 0.09)), metal, Vector3(0, -0.07, 0.04), g, Vector3(-0.25, 0, 0))   # grip
		make_mesh(box(Vector3(0.08, 0.09, 0.32)), gold, Vector3(0, 0.03, -0.1), g)                        # slide
		make_mesh(box(Vector3(0.085, 0.015, 0.3)), Fx3D.glow_mat(color, 2.2), Vector3(0, 0.08, -0.1), g)  # light strip
		make_mesh(cyl(0.02, 0.06), Fx3D.glow_mat(color, 2.0), Vector3(0, 0.03, -0.28), g, Vector3(PI * 0.5, 0, 0))
		var muzzle := Node3D.new()
		muzzle.position = Vector3(0, 0.03, -0.32)
		g.add_child(muzzle)
		hand_light(g, 0.6)
		_guns.append(g)
		_muzzles.append(muzzle)


func process_kit(delta: float) -> void:
	if ult_active > 0.0:
		_barrage_t -= delta
		if _barrage_t <= 0.0:
			_barrage_t = 0.1
			_barrage_shot()


func _fire_from(i: int, target: Vector3, spd: float, dmg: float, size: float) -> Projectile:
	var from := _muzzles[i].global_position
	var p := Projectile.spawn(world(), from, (target - from).normalized() * spd, 0, dmg, color, size)
	p.source = player
	p.light_energy = 1.0
	Fx3D.flash_light(world(), from, color, 3.0, 3.0, 0.06)
	jab(_guns[i], Vector3(0, 0.04, 0.08), 0.03, 0.1)
	return p


func primary(held: bool, _just: bool) -> void:
	if not held or primary_cd > 0.0:
		return
	primary_cd = 0.125
	_fire_from(_next, player.aim_point(90.0), 85.0, 7.0, 0.08)
	_next = 1 - _next
	Audio.play("pistol", -9.0, 0.08)


func skill1_press() -> void:
	if q_cd > 0.0:
		cooldown_denied()
		return
	q_cd = q_cd_max
	var fwd := player.aim_dir()
	var right := fwd.cross(Vector3.UP).normalized()
	var up := right.cross(fwd).normalized()
	for k in 9:
		var spread := right * randf_range(-0.12, 0.12) + up * randf_range(-0.07, 0.07)
		var target := player.aim_origin() + (fwd + spread).normalized() * 30.0
		var p := _fire_from(k % 2, target, 70.0, 10.0, 0.07)
		p.heavy = true
		p.lifetime = 0.6
	player.velocity -= Vector3(fwd.x, 0, fwd.z).normalized() * 6.0
	player.add_shake(0.3)
	Fx3D.flash_light(world(), player.aim_origin() + fwd, color, 10.0, 8.0, 0.15)
	Audio.play("shotgun", -2.0)
	callout("SCATTER BLAST!")


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var from := player.aim_origin() + player.aim_dir() * 0.6
	var p := Projectile.spawn(world(), from, player.aim_dir() * 20.0 + Vector3.UP * 5.0, 0, 22.0, Color(1, 1, 0.85), 0.16)
	p.fall_gravity = 16.0
	p.explode_radius = 5.0
	p.stun_time = 2.2
	p.heavy = true
	p.lifetime = 1.3
	p.source = player
	Audio.play("throw", -4.0)
	callout("FLASH GRENADE!")


func ultimate() -> void:
	start_ult(3.0, "SOLAR BARRAGE!!")
	_barrage_i = 0
	_barrage_t = 0.25


func _barrage_shot() -> void:
	var list := player.enemies()
	if list.is_empty():
		return
	var e: Node3D = list[_barrage_i % list.size()]
	_barrage_i += 1
	var p := _fire_from(_barrage_i % 2, e.aim_point(), 55.0, 16.0, 0.14)
	p.homing_target = e
	p.homing_turn = 10.0
	p.heavy = true
	p.light_energy = 2.0
	Audio.play("pistol", -6.0, 0.1, 0.8)
