class_name HUD
extends CanvasLayer
## In-game HUD: health + ultimate, skill cooldowns, crosshair & hit markers,
## combo counter, big announcements, anime power callouts, boss bar,
## plus the pause menu and the game-over screen.

var arena: Node
var player: Player

var _root: Control
var _bars: Bars
var _cross: Crosshair
var _announce: VBoxContainer
var _ann_title: Label
var _ann_sub: Label
var _ann_tween: Tween
var _callout: Label
var _callout_tween: Tween
var _combo: Label
var _notice: Label
var _notice_tween: Tween
var _enemies: Label
var _boss: BossBar
var _style: StylePanel
var _pause: Control
var _over: Control


func _init() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS


func setup(p_arena: Node, p_player: Player) -> void:
	arena = p_arena
	player = p_player
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = UIKit.theme()
	add_child(_root)

	_bars = Bars.new()
	_bars.player = player
	_bars.set_anchors_preset(Control.PRESET_FULL_RECT)
	_bars.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_bars)

	_cross = Crosshair.new()
	_cross.set_anchors_preset(Control.PRESET_FULL_RECT)
	_cross.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_cross.color = Fighters.color(player.fighter)
	_root.add_child(_cross)

	_boss = BossBar.new()
	_boss.set_anchors_preset(Control.PRESET_FULL_RECT)
	_boss.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss.visible = false
	_root.add_child(_boss)

	_style = StylePanel.new()
	_style.player = player
	_style.position = Vector2(1280 - 250, 150)
	_style.size = Vector2(230, 120)
	_style.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_style)

	_enemies = UIKit.label("", 16, UIKit.DIM, true)
	_enemies.position = Vector2(1280 - 260, 22)
	_enemies.size = Vector2(236, 24)
	_enemies.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_root.add_child(_enemies)
	var lvl := UIKit.label("%02d  %s" % [Game.current_level + 1, Game.LEVELS[Game.current_level].name], 15, UIKit.DIM, true)
	lvl.position = Vector2(24, 22)
	_root.add_child(lvl)

	_combo = UIKit.label("", 30, Color.WHITE, true, Color(1, 0.3, 0.5, 0.6))
	_combo.position = Vector2(1280 - 300, 272)
	_combo.size = Vector2(270, 80)
	_combo.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_root.add_child(_combo)

	_notice = UIKit.label("", 18, UIKit.GOLD, true, Color(0, 0, 0, 0.8))
	_notice.position = Vector2(0, 470)
	_notice.size = Vector2(1280, 30)
	_notice.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_notice.modulate.a = 0.0
	_root.add_child(_notice)

	_callout = UIKit.label("", 64, Color.WHITE, true, Color(1, 1, 1, 0.5))
	_callout.position = Vector2(0, 150)
	_callout.size = Vector2(1280, 100)
	_callout.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_callout.pivot_offset = Vector2(640, 50)
	_callout.modulate.a = 0.0
	_root.add_child(_callout)

	_announce = VBoxContainer.new()
	_announce.position = Vector2(0, 250)
	_announce.size = Vector2(1280, 160)
	_announce.alignment = BoxContainer.ALIGNMENT_CENTER
	_announce.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ann_title = UIKit.label("", 72, Color.WHITE, true, Color(1, 0.3, 0.5, 0.6))
	_ann_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_ann_sub = UIKit.label("", 22, UIKit.GOLD, true)
	_ann_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_announce.add_child(_ann_sub)
	_announce.add_child(_ann_title)
	_announce.modulate.a = 0.0
	_root.add_child(_announce)

	_build_pause()
	_build_game_over()


func _process(_delta: float) -> void:
	if arena != null and arena.has_method("alive_enemies"):
		var n: int = arena.alive_enemies()
		_enemies.text = "ENEMIES  %d" % n if n > 0 else ""
	if player != null:
		_combo.text = ("%d HIT COMBO" % player.combo) if player.combo >= 3 else ""
		var k := clampf(player.combo / 30.0, 0.0, 1.0)
		_combo.add_theme_color_override("font_color", Color.WHITE.lerp(UIKit.GOLD, k))


# --- announcements ------------------------------------------------------------

func announce(title: String, sub := "") -> void:
	_ann_title.text = title
	_ann_sub.text = sub
	if _ann_tween != null and _ann_tween.is_valid():
		_ann_tween.kill()
	_announce.modulate.a = 0.0
	_announce.scale = Vector2(1.3, 1.3)
	_announce.pivot_offset = Vector2(640, 80)
	_ann_tween = create_tween().set_ignore_time_scale(true)
	_ann_tween.tween_property(_announce, "modulate:a", 1.0, 0.2)
	_ann_tween.parallel().tween_property(_announce, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK)
	_ann_tween.tween_interval(1.6)
	_ann_tween.tween_property(_announce, "modulate:a", 0.0, 0.4)


## Anime-style power name callout.
func callout(text: String, color: Color, big := false) -> void:
	_callout.text = text
	_callout.add_theme_font_size_override("font_size", 78 if big else 52)
	_callout.add_theme_color_override("font_color", Color.WHITE.lerp(color, 0.25))
	_callout.add_theme_color_override("font_shadow_color", Color(color, 0.85))
	if _callout_tween != null and _callout_tween.is_valid():
		_callout_tween.kill()
	_callout.modulate.a = 1.0
	_callout.scale = Vector2(1.8, 1.8) if big else Vector2(1.4, 1.4)
	_callout.rotation = deg_to_rad(-4.0)
	_callout_tween = create_tween().set_ignore_time_scale(true)
	_callout_tween.tween_property(_callout, "scale", Vector2.ONE, 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_callout_tween.tween_interval(0.7 if big else 0.45)
	_callout_tween.tween_property(_callout, "modulate:a", 0.0, 0.3)


func style_pop() -> void:
	_style.pop()


func notice(text: String) -> void:
	_notice.text = text
	if _notice_tween != null and _notice_tween.is_valid():
		_notice_tween.kill()
	_notice.modulate.a = 1.0
	_notice_tween = create_tween().set_ignore_time_scale(true)
	_notice_tween.tween_interval(0.9)
	_notice_tween.tween_property(_notice, "modulate:a", 0.0, 0.3)


func hit_marker(kill: bool) -> void:
	_cross.hit(kill)


func show_boss_bar(value: bool) -> void:
	_boss.visible = value


func set_boss_health(hp: float, max_hp: float, stage: int) -> void:
	_boss.set_health(hp, max_hp, stage)


# --- pause & game over ------------------------------------------------------------

func _panel(title: String, color: Color) -> Array:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.visible = false
	_root.add_child(root)
	var dim := ColorRect.new()
	dim.color = Color(0.0, 0.0, 0.02, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var box := VBoxContainer.new()
	box.position = Vector2(640 - 170, 210)
	box.custom_minimum_size = Vector2(340, 0)
	box.add_theme_constant_override("separation", 14)
	root.add_child(box)
	var t := UIKit.label(title, 56, Color.WHITE, true, Color(color, 0.7))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 16)
	box.add_child(sp)
	return [root, box]


func _build_pause() -> void:
	var r := _panel("PAUSED", UIKit.CYAN)
	_pause = r[0]
	UIKit.button(r[1], "RESUME", _on_resume, 340)
	UIKit.button(r[1], "RESTART STAGE", _on_restart, 340)
	UIKit.button(r[1], "MAIN MENU", _on_menu, 340)


func _on_resume() -> void:
	_set_paused(false)


func _on_restart() -> void:
	_set_paused(false)
	Game.retry_level()


func _on_menu() -> void:
	_set_paused(false)
	Game.go_to_menu()


func _build_game_over() -> void:
	var r := _panel("DEFEATED", UIKit.HOT)
	_over = r[0]
	var tip := UIKit.label("Tip: hold RIGHT CLICK to block. Tap it right before a hit to PARRY.", 16, UIKit.DIM)
	tip.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	r[1].add_child(tip)
	UIKit.button(r[1], "RETRY", Game.retry_level, 340)
	UIKit.button(r[1], "MAIN MENU", Game.go_to_menu, 340)


func show_game_over() -> void:
	Game.reset_time()
	_over.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	(_over.get_child(1).get_child(3) as Button).grab_focus()


func _set_paused(value: bool) -> void:
	if Game.is_busy():
		return
	get_tree().paused = value
	_pause.visible = value
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED
	if value:
		(_pause.get_child(1).get_child(2) as Button).grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and not _over.visible and player != null and player.alive:
		get_viewport().set_input_as_handled()
		_set_paused(not get_tree().paused)


# ==============================================================================

class Bars extends Control:
	var player: Player
	var _trail := 1.0
	var _t := 0.0

	func _process(delta: float) -> void:
		_t += delta
		queue_redraw()

	func _draw() -> void:
		if player == null or player.kit == null:
			return
		var title := UIKit.title_font(900)
		var mono := UIKit.mono_font()
		var col := Fighters.color(player.fighter)
		var frac := player.hp / player.max_hp
		_trail = move_toward(_trail, frac, 0.01)
		if _trail < frac:
			_trail = frac
		# Emblem + name.
		UIKit.draw_emblem(self, Vector2(64, 612), 34, player.fighter)
		draw_string(title, Vector2(110, 600), Fighters.NAMES[player.fighter], HORIZONTAL_ALIGNMENT_LEFT, -1, 30, col)
		draw_string(mono, Vector2(112, 622), Fighters.STYLES[player.fighter], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, UIKit.DIM)
		# Health.
		var hp_rect := Rect2(110, 634, 360, 16)
		draw_rect(hp_rect.grow(2), Color(0, 0, 0, 0.6))
		draw_rect(Rect2(hp_rect.position, Vector2(hp_rect.size.x * _trail, hp_rect.size.y)), Color(1, 1, 1, 0.7))
		var hp_col := Color(0.35, 1.0, 0.6) if frac > 0.35 else Color(1.0, 0.25, 0.3)
		draw_rect(Rect2(hp_rect.position, Vector2(hp_rect.size.x * frac, hp_rect.size.y)), hp_col)
		for i in range(1, 10):
			draw_line(hp_rect.position + Vector2(hp_rect.size.x * i / 10.0, 0), hp_rect.position + Vector2(hp_rect.size.x * i / 10.0, hp_rect.size.y), Color(0, 0, 0, 0.35), 1.0)
		draw_string(title, hp_rect.position + Vector2(hp_rect.size.x + 10, 14), "%d" % ceil(player.hp), HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color.WHITE)
		# Ultimate.
		var ult_rect := Rect2(110, 656, 360, 9)
		var u := player.ult / 100.0
		draw_rect(ult_rect.grow(2), Color(0, 0, 0, 0.6))
		var ready := u >= 1.0
		var pulse := 0.6 + 0.4 * sin(_t * 8.0)
		draw_rect(Rect2(ult_rect.position, Vector2(ult_rect.size.x * u, ult_rect.size.y)), col.lerp(Color.WHITE, pulse * 0.5) if ready else col)
		if ready:
			draw_rect(ult_rect.grow(4), Color(col, 0.35 * pulse), false, 2.0)
			draw_string(title, Vector2(110, 688), "ULTIMATE READY  [F]", HORIZONTAL_ALIGNMENT_LEFT, -1, 15, col.lerp(Color.WHITE, pulse))
		# Skills (bottom right).
		var kit := player.kit
		var names: Array = Fighters.MOVES[player.fighter]
		var slots := [["Q", names[1], kit.q_fraction(), kit.q_cd], ["E", names[2], kit.e_fraction(), kit.e_cd], ["F", names[3], 0.0 if ready else 1.0 - u, -1.0]]
		for i in slots.size():
			var s: Array = slots[i]
			var r := Rect2(1280 - 24 - (3 - i) * 92, 600, 80, 80)
			var fr: float = s[2]
			draw_rect(r, Color(0.03, 0.03, 0.07, 0.85))
			var avail := fr <= 0.0
			draw_rect(r, col if avail else Color(col, 0.3), false, 2.0)
			if avail:
				draw_rect(r.grow(3), Color(col, 0.18), false, 3.0)
			if fr > 0.0:
				draw_rect(Rect2(r.position, Vector2(r.size.x, r.size.y * fr)), Color(0, 0, 0, 0.6))
			draw_string(title, r.position + Vector2(0, 50), str(s[0]), HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 34, Color.WHITE if avail else UIKit.DIM)
			if float(s[3]) > 0.0:
				draw_string(title, r.position + Vector2(0, 74), "%.1f" % s[3], HORIZONTAL_ALIGNMENT_CENTER, r.size.x, 13, UIKit.DIM)
			draw_string(mono, r.position + Vector2(-10, 96), str(s[1]), HORIZONTAL_ALIGNMENT_CENTER, r.size.x + 20, 11, UIKit.DIM)
		# Controls hint.
		draw_string(mono, Vector2(1280 - 24 - 3 * 92, 590), "LMB attack   RMB block   SHIFT dash   SPACE x2 jump", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(UIKit.DIM, 0.7))


class Crosshair extends Control:
	var color := Color.WHITE
	var _hit := 0.0
	var _kill := false

	func hit(kill: bool) -> void:
		_hit = 1.0
		_kill = kill

	func _process(delta: float) -> void:
		_hit = move_toward(_hit, 0.0, delta / maxf(Engine.time_scale, 0.05) * 5.0)
		queue_redraw()

	func _draw() -> void:
		var c := size * 0.5
		var gap := 7.0 + _hit * 6.0
		draw_circle(c, 2.0, Color(1, 1, 1, 0.9))
		for d in [Vector2.RIGHT, Vector2.LEFT, Vector2.UP, Vector2.DOWN]:
			draw_line(c + d * gap, c + d * (gap + 7.0), Color(color, 0.85), 2.0)
		if _hit > 0.0:
			var hc := Color(1, 0.3, 0.3, _hit) if _kill else Color(1, 1, 1, _hit)
			for d in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
				draw_line(c + d * 8.0, c + d * 15.0, hc, 2.5)


class BossBar extends Control:
	var _hp := 1.0
	var _shown := 1.0
	var _stage := 1
	var _t := 0.0

	func set_health(hp: float, max_hp: float, stage: int) -> void:
		_hp = clampf(hp / max_hp, 0.0, 1.0)
		if stage != _stage:
			_stage = stage
			_shown = 1.0

	func _process(delta: float) -> void:
		_t += delta
		_shown = move_toward(_shown, _hp, delta * 0.5)
		if _shown < _hp:
			_shown = _hp
		queue_redraw()

	func _draw() -> void:
		var title := UIKit.title_font(900)
		var r := Rect2(290, 58, 700, 16)
		var red := Color(1, 0.18, 0.28)
		draw_string(title, Vector2(290, 50), "THE WARDEN", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color.WHITE)
		draw_string(title, Vector2(290, 50), "STAGE %d / 2" % _stage, HORIZONTAL_ALIGNMENT_RIGHT, 700, 14, red)
		draw_rect(r.grow(3), Color(0, 0, 0, 0.7))
		draw_rect(Rect2(r.position, Vector2(r.size.x * _shown, r.size.y)), Color(1, 0.85, 0.85))
		draw_rect(Rect2(r.position, Vector2(r.size.x * _hp, r.size.y)), red.lerp(Color(1, 0.5, 0.2), 0.5 + 0.5 * sin(_t * 3.0)) if _stage == 2 else red)
		draw_rect(r.grow(3), Color(red, 0.5), false, 1.5)


class StylePanel extends Control:
	var player: Player
	var _pop := 0.0
	var _t := 0.0
	const COLS: Array[Color] = [Color(0.6, 0.65, 0.75), Color(0.4, 0.9, 1.0), Color(0.4, 1.0, 0.5), Color(1.0, 0.85, 0.3), Color(1.0, 0.5, 0.2), Color(1.0, 0.25, 0.45), Color(1.0, 0.95, 0.6)]

	func pop() -> void:
		_pop = 1.0

	func _process(delta: float) -> void:
		_t += delta
		_pop = move_toward(_pop, 0.0, delta / maxf(Engine.time_scale, 0.05) * 3.0)
		queue_redraw()

	func _draw() -> void:
		if player == null or player.style < 1.0:
			return
		var r := player.style_rank()
		var frac := fmod(player.style, 100.0) / 100.0 if r < 6 else 1.0
		var col: Color = COLS[r]
		if r == 6:
			col = Color.from_hsv(fmod(_t * 0.5, 1.0), 0.5, 1.0)
		var title := UIKit.title_font(900)
		var letter: String = Player.STYLE_LETTERS[r]
		var sz := int(64 + _pop * 30)
		draw_string(title, Vector2(0, 70 + _pop * 6), letter, HORIZONTAL_ALIGNMENT_RIGHT, size.x, sz, Color(col, 0.35))
		draw_string(title, Vector2(-3, 67 + _pop * 6), letter, HORIZONTAL_ALIGNMENT_RIGHT, size.x, sz, col)
		draw_string(title, Vector2(0, 92), Player.STYLE_NAMES[r], HORIZONTAL_ALIGNMENT_RIGHT, size.x, 16, Color.WHITE.lerp(col, 0.5))
		var bar := Rect2(size.x - 160, 102, 160, 6)
		draw_rect(bar, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(bar.position, Vector2(bar.size.x * frac, bar.size.y)), col)
