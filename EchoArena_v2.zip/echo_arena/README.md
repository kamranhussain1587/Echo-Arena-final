# ECHO ARENA
*Four fighters. One tower. No mercy.*

A first-person anime brawler made in **Godot 4.7** (GDScript, Forward+ renderer). Pick one of six
original fighters, smash through waves of the Warden's robots across three stages, then climb the
tower for a two-stage boss fight. Everything is built from code: the 3D arenas, robots, effects,
UI art and the original electro soundtrack. Only external assets: two free open-licence fonts.

## Run it
1. Open **Godot 4.7.x**, click **Import**, select `project.godot` (extract the zip first), then **Import & Edit**.
2. Wait a few seconds for the first-time import (fonts + audio).
3. Press **F5**.

**Performance:** the default **GRAPHICS: ULTRA** setting uses volumetric fog, screen-space reflections and
SSAO. On a weaker laptop, switch to **PERFORMANCE** in the main menu.

## Controls
| Input | Action |
|---|---|
| W A S D | Move |
| Mouse | Look |
| Left click | Attack (hold for auto-attack) |
| Right click | Block. Tap it just before a hit to **PARRY** (stuns melee robots, reflects shots) |
| Shift | Flash Step dash (brief invincibility) |
| Space | Jump, press again in the air for a double jump |
| Q | Skill 1 (VOLT: hold to charge, release to fire) |
| E | Skill 2 |
| F | **Ultimate** (fills as you deal damage) |
| Esc | Pause |
| F11 | Fullscreen |

## Fighters
| | Style | LMB | Q | E | F (Ultimate) |
|---|---|---|---|---|---|
| **VOLT** | Energy | Energy Bolts | Nova Lance (charged piercing beam) | Pulse Nova (radial blast) | STARFALL (bolts rain from the sky) |
| **KAGE** | Sword | 3-hit Blade Combo | Rift Dash (dash-slash through enemies) | Whirlwind (spin slash) | THOUSAND CUTS (time stops, everything gets cut) |
| **RIOT** | Fists & kicks | Punch-punch-kick | Meteor Kick (leap + ground-shaking dive) | Rising Uppercut (launcher) | RUSH MODE (faster, stronger, auto-lunge) |
| **HEX** | Magic | Homing Arcane Orbs | Frost Sigil (freezing magic circle) | Blink (teleport) | METEOR RAIN (giant sky circle drops meteors) |
| **NOVA** | Gunslinger | Twin Light Pistols | Scatter Blast (point-blank shotgun) | Flash Grenade (stuns everything nearby) | SOLAR BARRAGE (homing lock-on volley) |
| **JADE** | Wind spear | Long-reach Spear Combo | Gale Javelin (piercing throw) | Cyclone Pull (drags robots in) | TEMPEST (roaming tornado) |

## Advanced combat
- **Style rank (D, C, B, A, S, SS, SSS):** chain hits to climb from DECENT up to UNSTOPPABLE. Higher ranks charge your ultimate faster. Getting hit drops your rank.
- **Perfect Dodge:** Flash Step (Shift) through an attack at the last moment and time slows down for a counterattack. You also get bonus ultimate charge.
- **Energy shield:** blocking raises a hex barrier in your fighter's colour. It ripples on every blocked hit and flashes white on a parry.
- **Feel:** physics runs at 120 Hz, there's a camera dip when you land, whooshes on every swing, and the music pitches down during slow motion.

## Stages
1. **Neon Streets:** melee drones (they flash red before attacking, so block or dodge)
2. **Rooftops:** in the rain, with gunner drones that keep their distance
3. **Reactor Core:** shield walkers that block light attacks from the front (hit them from the side, or use skills and ultimates)
4. **The Warden's Tower:** the boss.
   - **Stage 1 (Mech):** jump over the red shockwaves, jump or dash through the sweeping laser, and dodge the homing missiles.
   - **Stage 2 (Core):** dodge the bullet rings and spirals. After it dashes at you it sinks low and is **vulnerable**, so hit it hard.

Health orbs drop from destroyed robots.

## Project structure
```
autoload/   game.gd (flow, story order, hitstop, slow-mo)   audio.gd (music + SFX)
core/       fighters.gd (the 6 fighters' data)
player/     player.gd (movement, camera juice, block/parry, damage pipeline)
            kits/kit.gd base + volt, kage, riot, hex, nova, jade (moves + first-person weapons)
enemies/    enemy.gd (minion / gunner / shield)   boss.gd (the Warden, 2 stages)
combat/     projectile.gd   fx3d.gd (sparks, explosions, rings, beams, slashes, magic circles)   health_orb.gd
levels/     arena.gd (builds each themed arena + runs waves/boss)   arena.tscn
ui/         main_menu, character_select, story (cutscenes + victory), hud (incl. pause/game over),
            overlay (speed lines, aura, time-stop, damage vignette), ui_kit
audio/      generated music & SFX   tools/generate_audio.py regenerates them
```
To tweak waves, edit `LEVELS` in `autoload/game.gd`. Fighter stats and moves are in `player/kits/`.

## Credits
Design, code, procedural 3D art, generated music and SFX: made for this hackathon.
Fonts: Orbitron and Share Tech Mono (SIL Open Font License 1.1, see fonts/).
