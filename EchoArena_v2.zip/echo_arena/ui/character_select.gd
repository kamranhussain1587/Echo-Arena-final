extends Control
## Pick one of six fighters: a roster row on top, full details below.

var _index := 0
var _cards: Array[Card] = []
var _go := false
var _detail: Detail
var _blurb: Label


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	var bg: Arena = load("res://levels/arena.gd").new()
	bg.menu_mode = true
	bg.theme_index = 1
	add_child(bg)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0.03, 0.55)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	var title := UIKit.label("CHOOSE YOUR FIGHTER", 46, Color.WHITE, true, Color(1, 0.3, 0.5, 0.6))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.position = Vector2(0, 26)
	title.size = Vector2(1280, 60)
	add_child(title)
	for i in Fighters.COUNT:
		var c := Card.new()
		c.fighter = i
		c.position = Vector2(40 + i * 202, 104)
		c.size = Vector2(190, 236)
		c.gui_input.connect(_on_card_input.bind(i))
		c.mouse_entered.connect(_select.bind(i))
		add_child(c)
		_cards.append(c)
	_detail = Detail.new()
	_detail.position = Vector2(40, 362)
	_detail.size = Vector2(1200, 232)
	_detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_detail)
	_blurb = UIKit.label("", 17, UIKit.TEXT)
	_blurb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_blurb.position = Vector2(70, 452)
	_blurb.size = Vector2(520, 110)
	add_child(_blurb)
	var go := UIKit.button(self, "FIGHT!", _confirm, 300)
	go.position = Vector2(640 - 150, 618)
	var hint := UIKit.label("A / D or arrows to choose  -  ENTER to fight  -  ESC back", 14, UIKit.DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.position = Vector2(0, 690)
	hint.size = Vector2(1280, 20)
	add_child(hint)
	_select(Game.fighter, false)
	Audio.play_music("menu")


func _select(i: int, sound := true) -> void:
	if _go:
		return
	if i != _index and sound:
		Audio.play("ui_move", -8.0)
	_index = posmod(i, Fighters.COUNT)
	for c in _cards:
		c.selected = c.fighter == _index
	_detail.fighter = _index
	_detail.pop()
	_blurb.text = Fighters.BLURBS[_index]


func _confirm() -> void:
	if _go:
		return
	_go = true
	Game.fighter = _index
	Audio.play("ult", -4.0)
	_cards[_index].flash()
	await get_tree().create_timer(0.5).timeout
	Game.new_run()


func _on_card_input(event: InputEvent, i: int) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if _index == i:
			_confirm()
		else:
			_select(i)


func _unhandled_input(event: InputEvent) -> void:
	if _go:
		return
	if event.is_action_pressed("ui_left") or event.is_action_pressed("move_left"):
		_select(_index - 1)
	elif event.is_action_pressed("ui_right") or event.is_action_pressed("move_right"):
		_select(_index + 1)
	elif event.is_action_pressed("ui_accept"):
		_confirm()
	elif event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause"):
		Game.go_to_menu()
	else:
		return
	get_viewport().set_input_as_handled()


class Card extends Control:
	var fighter := 0
	var selected := false
	var _lift := 0.0
	var _flash := 0.0
	var _t := 0.0

	func _ready() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP

	func flash() -> void:
		_flash = 1.0

	func _process(delta: float) -> void:
		_t += delta
		_lift = move_toward(_lift, 1.0 if selected else 0.0, delta * 6.0)
		_flash = move_toward(_flash, 0.0, delta * 2.0)
		position.y = 104.0 - 12.0 * _lift
		modulate = Color.WHITE if selected else Color(0.6, 0.62, 0.72)
		queue_redraw()

	func _draw() -> void:
		var col := Fighters.color(fighter)
		var r := Rect2(Vector2.ZERO, size)
		if selected:
			for i in 4:
				draw_rect(r.grow(3.0 + i * 4.0), Color(col, 0.12 - i * 0.025), false, 4.0)
		draw_rect(r, Color(0.03, 0.025, 0.06, 0.92))
		draw_rect(Rect2(0, 0, size.x, 140), Color(col, 0.08 + 0.06 * sin(_t * 2.0 + fighter)))
		draw_rect(r, col if selected else Color(col, 0.35), false, 2.0)
		var spin := _t * (1.5 if selected else 0.3)
		for k in 3:
			draw_arc(Vector2(size.x * 0.5, 74), 46.0 + k * 8.0, spin + k, spin + k + PI * 1.2, 32, Color(col, 0.35 - k * 0.08), 2.0)
		UIKit.draw_emblem(self, Vector2(size.x * 0.5, 74), 38, fighter)
		var title := UIKit.title_font(900)
		draw_string(title, Vector2(0, 176), Fighters.NAMES[fighter], HORIZONTAL_ALIGNMENT_CENTER, size.x, 30, col)
		draw_string(title, Vector2(0, 202), Fighters.STYLES[fighter], HORIZONTAL_ALIGNMENT_CENTER, size.x, 12, UIKit.DIM)
		draw_string(title, Vector2(0, 226), str(fighter + 1), HORIZONTAL_ALIGNMENT_CENTER, size.x, 11, Color(col, 0.6))
		if _flash > 0.0:
			draw_rect(r, Color(1, 1, 1, _flash * 0.6))


class Detail extends Control:
	var fighter := 0
	var _pop := 0.0

	func pop() -> void:
		_pop = 1.0

	func _process(delta: float) -> void:
		_pop = move_toward(_pop, 0.0, delta * 4.0)
		queue_redraw()

	func _draw() -> void:
		var col := Fighters.color(fighter)
		var r := Rect2(Vector2.ZERO, size)
		draw_rect(r, Color(0.02, 0.02, 0.05, 0.9))
		draw_rect(Rect2(0, 0, 6, size.y), col)
		draw_rect(r, Color(col, 0.4 + _pop * 0.4), false, 2.0)
		var title := UIKit.title_font(900)
		var mono := UIKit.mono_font()
		draw_string(title, Vector2(30, 58 - _pop * 4), Fighters.NAMES[fighter], HORIZONTAL_ALIGNMENT_LEFT, -1, 46, col)
		draw_string(title, Vector2(32, 82), Fighters.STYLES[fighter], HORIZONTAL_ALIGNMENT_LEFT, -1, 15, UIKit.DIM)
		var moves: Array = Fighters.MOVES[fighter]
		var keys := ["LEFT CLICK", "Q", "E", "F  ULTIMATE"]
		for i in 4:
			var y := 44.0 + i * 44.0
			var x := 640.0
			draw_rect(Rect2(x, y - 22, 520, 36), Color(col, 0.08 if i < 3 else 0.18))
			draw_string(title, Vector2(x + 14, y + 2), keys[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 13, col)
			draw_string(title if i == 3 else mono, Vector2(x + 170, y + 2), str(moves[i]), HORIZONTAL_ALIGNMENT_LEFT, -1, 18 if i < 3 else 17, Color.WHITE)
