class_name Projectile
extends Area3D
## Glowing projectile for both teams (team 0 = player, 1 = enemies).
## Optional homing and area-of-effect explosion. Carries its own light.

var team := 0
var velocity := Vector3.ZERO
var damage := 10.0
var heavy := false
var lifetime := 3.0
var size := 0.18
var color := Color(0.3, 0.9, 1.0)
var homing_target: Node3D
var homing_turn := 0.0
var explode_radius := 0.0
var light_energy := 2.0
var source: Node
## Extra behaviours: arcing, piercing (hits each enemy once), stun on explode.
var fall_gravity := 0.0
var pierce := false
var stun_time := 0.0
var _pierced: Array = []

var _t := 0.0
var _done := false


static func spawn(parent: Node, pos: Vector3, vel: Vector3, p_team: int, p_damage: float, p_color: Color, p_size := 0.18) -> Projectile:
	var p := Projectile.new()
	p.team = p_team
	p.velocity = vel
	p.damage = p_damage
	p.color = p_color
	p.size = p_size
	parent.add_child(p)
	p.global_position = pos
	return p


func _ready() -> void:
	collision_layer = 0
	collision_mask = (1 | 4) if team == 0 else (1 | 2)
	monitoring = true
	monitorable = false
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = size
	cs.shape = sh
	add_child(cs)
	var mesh := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	sm.radial_segments = 12
	sm.rings = 6
	mesh.mesh = sm
	mesh.material_override = Fx3D.glow_mat(color, 6.0)
	add_child(mesh)
	var core := MeshInstance3D.new()
	var cm := SphereMesh.new()
	cm.radius = size * 0.55
	cm.height = size * 1.1
	core.mesh = cm
	core.material_override = Fx3D.glow_mat(Color.WHITE, 4.0)
	add_child(core)
	var light := OmniLight3D.new()
	light.light_color = color
	light.light_energy = light_energy
	light.omni_range = 3.0 + size * 8.0
	light.light_volumetric_fog_energy = 0.6
	add_child(light)
	# Trail.
	var trail := GPUParticles3D.new()
	trail.amount = 16
	trail.lifetime = 0.25
	trail.local_coords = false
	var pm := ParticleProcessMaterial.new()
	pm.gravity = Vector3.ZERO
	pm.initial_velocity_min = 0.0
	pm.initial_velocity_max = 0.3
	pm.scale_min = 0.6
	pm.scale_max = 1.0
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	trail.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(size * 1.6, size * 1.6)
	var m := Fx3D.glow_mat(color, 3.0, 0.7)
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = m
	trail.draw_pass_1 = q
	add_child(trail)
	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	if _done:
		return
	_t += delta
	if _t > lifetime:
		_explode()
		return
	if homing_turn > 0.0 and is_instance_valid(homing_target):
		var aim: Vector3 = homing_target.call("aim_point") if homing_target.has_method("aim_point") else homing_target.global_position
		var desired := (aim - global_position).normalized() * velocity.length()
		velocity = velocity.lerp(desired, clampf(homing_turn * delta, 0.0, 1.0))
	velocity.y -= fall_gravity * delta
	global_position += velocity * delta


func _on_body_entered(body: Node) -> void:
	if _done:
		return
	if team == 0 and body.has_method("take_hit"):
		if pierce:
			if not _pierced.has(body):
				_pierced.append(body)
				_hit_enemy(body)
				Fx3D.sparks(get_parent(), global_position, color, 14, 7.0, 0.07, 0.4)
			return
		_hit_enemy(body)
	elif team == 1 and body is Player:
		(body as Player).take_damage(damage, global_position, self)
	_explode()


func _hit_enemy(body: Node) -> void:
	var dealt: float = body.take_hit(damage, velocity.normalized(), heavy, global_position)
	if source != null and is_instance_valid(source) and source.has_method("register_hit"):
		source.register_hit(body, dealt, global_position, heavy)


func _explode() -> void:
	if _done:
		return
	_done = true
	var parent := get_parent()
	if explode_radius > 0.0:
		Fx3D.explosion(parent, global_position, color, explode_radius)
		Audio.play("explosion", -6.0)
		if team == 0:
			for e in get_tree().get_nodes_in_group("enemies"):
				if e.dead:
					continue
				var d: float = e.aim_point().distance_to(global_position) - e.hit_radius
				if d < explode_radius:
					var dir: Vector3 = (e.aim_point() - global_position).normalized()
					_hit_enemy_direct(e, dir)
					if stun_time > 0.0 and e.has_method("stun"):
						e.stun(stun_time)
		else:
			var pl := get_tree().get_first_node_in_group("player") as Player
			if pl != null and pl.global_position.distance_to(global_position) < explode_radius + 0.5:
				pl.take_damage(damage, global_position, self)
	else:
		Fx3D.sparks(parent, global_position, color, 12, 5.0, 0.06, 0.35)
	queue_free()


func _hit_enemy_direct(e: Node, dir: Vector3) -> void:
	var dealt: float = e.take_hit(damage, dir, heavy, global_position)
	if source != null and is_instance_valid(source) and source.has_method("register_hit"):
		source.register_hit(e, dealt, e.aim_point(), heavy)


## Parry support: enemy shots can be deflected back.
func reflect(by: Node) -> void:
	team = 0
	collision_mask = 1 | 4
	velocity = -velocity * 1.4
	damage *= 2.0
	source = by
	color = Color(1, 1, 1)
