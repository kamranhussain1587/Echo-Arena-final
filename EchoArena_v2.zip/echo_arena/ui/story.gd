extends Control
## Story cards between stages (cinematic letterbox + dialogue), and the
## victory screen after the final battle.

var _lines: Array = []
var _i := -1
var _speaker: Label
var _text: Label
var _tween: Tween
var _victory := false
var _done := false


func _story() -> Array:
	var me := Fighters.NAMES[Game.fighter]
	match Game.story_index:
		0:
			return [
				["", "NEO-KAIRO.  2089."],
				["", "At midnight, the arena district went dark."],
				["THE WARDEN", "Citizens. The games are over. I am the games now."],
				["", "Every screen in the city showed the same red eye."],
				[me, "Not on my watch. I'm going up that tower."],
			]
		1:
			return [
				["THE WARDEN", "You broke my street drones. Adorable."],
				["THE WARDEN", "Let's see how you fight in the rain. My gunners never miss twice."],
				[me, "Then they'd better not miss once."],
			]
		2:
			return [
				["THE WARDEN", "Persistent. My reactor powers the entire tower."],
				["THE WARDEN", "Touch it and you burn."],
				[me, Fighters.RETORTS[Game.fighter]],
			]
		3:
			return [
				["", "The reactor collapsed. The tower's shields flickered and died."],
				["THE WARDEN", "Enough. Come to the top. Face me yourself."],
				[me, "That was always the plan."],
			]
		_:
			return [
				["", "The Warden's core shattered into a billion lines of dead code."],
				["", "One by one, the lights of Neo-Kairo flickered back on."],
				[me, "The games are back. And this time, the people run them."],
				["???", "...see you next season, champion."],
			]


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	_victory = Game.story_index >= Game.LEVELS.size()
	var bg: Arena = load("res://levels/arena.gd").new()
	bg.menu_mode = true
	bg.theme_index = clampi(Game.story_index, 0, 3) if not _victory else 0
	add_child(bg)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0.02, 0.35)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)
	for y in [0.0, 620.0]:
		var bar := ColorRect.new()
		bar.color = Color(0, 0, 0, 1)
		bar.position = Vector2(0, y)
		bar.size = Vector2(1280, 100)
		bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(bar)
	if not _victory:
		var chapter := UIKit.label("STAGE %d  -  %s" % [Game.story_index + 1, Game.LEVELS[Game.story_index].name], 18, UIKit.GOLD, true)
		chapter.position = Vector2(60, 40)
		add_child(chapter)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UIKit.style(Color(0.02, 0.02, 0.05, 0.88), Color(1, 0.3, 0.5, 0.6), 2, 4))
	panel.position = Vector2(140, 440)
	panel.size = Vector2(1000, 150)
	panel.custom_minimum_size = Vector2(1000, 150)
	add_child(panel)
	var vb := VBoxContainer.new()
	panel.add_child(vb)
	_speaker = UIKit.label("", 20, UIKit.HOT, true)
	vb.add_child(_speaker)
	_text = UIKit.label("", 26, UIKit.TEXT)
	_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_text.custom_minimum_size = Vector2(960, 70)
	vb.add_child(_text)
	var hint := UIKit.label("SPACE / CLICK to continue", 13, UIKit.DIM)
	hint.position = Vector2(1280 - 280, 660)
	add_child(hint)
	_lines = _story()
	Audio.play_music("victory" if _victory else "menu")
	_next()


func _next() -> void:
	if _done:
		return
	if _tween != null and _tween.is_valid() and _text.visible_ratio < 1.0:
		_tween.kill()
		_text.visible_ratio = 1.0
		return
	_i += 1
	if _i >= _lines.size():
		_finish()
		return
	var line: Array = _lines[_i]
	_speaker.text = str(line[0])
	var who := str(line[0])
	var col := UIKit.HOT if who == "THE WARDEN" else (Fighters.color(Game.fighter) if who == Fighters.NAMES[Game.fighter] else UIKit.DIM)
	_speaker.add_theme_color_override("font_color", col)
	_text.text = str(line[1])
	_text.visible_ratio = 0.0
	_tween = create_tween()
	_tween.tween_property(_text, "visible_ratio", 1.0, 0.025 * str(line[1]).length())
	Audio.play("ui_move", -10.0)


func _finish() -> void:
	_done = true
	if not _victory:
		Game.story_finished()
		return
	_show_victory()


func _show_victory() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0.02, 0.75)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var box := VBoxContainer.new()
	box.position = Vector2(0, 150)
	box.custom_minimum_size = Vector2(1280, 0)
	box.add_theme_constant_override("separation", 14)
	add_child(box)
	var t := UIKit.label("VICTORY", 110, Color.WHITE, true, Color(Fighters.color(Game.fighter), 0.8))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var s := UIKit.label("%s  CLEARED  THE  WARDEN'S  TOWER" % Fighters.NAMES[Game.fighter], 22, UIKit.GOLD, true)
	s.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(s)
	var secs := int(Game.stats.time)
	var st := UIKit.label("time  %02d:%02d      robots destroyed  %d      retries  %d" % [secs / 60, secs % 60, int(Game.stats.kills), int(Game.stats.deaths)], 20, UIKit.TEXT)
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(st)
	var hb := HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 20)
	box.add_child(hb)
	var again := UIKit.button(hb, "PLAY AGAIN", _on_again, 280)
	UIKit.button(hb, "MAIN MENU", Game.go_to_menu, 280)
	again.grab_focus()
	Game.run_active = false
	Audio.play("clear", 0.0)


func _on_again() -> void:
	Game.change_scene(Game.SELECT)


func _unhandled_input(event: InputEvent) -> void:
	if _done:
		return
	var advance := event.is_action_pressed("ui_accept") or event.is_action_pressed("jump")
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		advance = true
	if advance:
		get_viewport().set_input_as_handled()
		_next()
