class_name Enemy
extends CharacterBody3D
## The Warden's robots, built from primitives with glowing parts.
##  MINION - fast melee drone that lunges after a red windup.
##  GUNNER - keeps its distance and fires 3-shot bursts.
##  SHIELD - slow heavy walker; its front shield blocks light attacks.
## Every attack has a bright windup "tell" so it can be blocked or parried.

signal died(enemy: Enemy)

enum Type { MINION, GUNNER, SHIELD }

var type: Type = Type.MINION
var max_hp := 40.0
var hp := 40.0
var speed := 6.0
var hit_radius := 0.6
var damage := 10.0
var attack_range := 2.4
var windup_time := 0.6
var dead := false
var accent := Color(1.0, 0.2, 0.35)

var _state := 0          # 0 approach, 1 windup, 2 recover
var _state_t := 0.0
var _attack_cd := 1.0
var _stun := 0.0
var _freeze := 0.0
var _knock := Vector3.ZERO
var _flash := 0.0
var _t := 0.0
var _hover := 1.4
var _strafe_dir := 1.0
var _player: Player
var _body_root: Node3D
var _eye_mat: StandardMaterial3D
var _body_mat: StandardMaterial3D
var _accent_mats: Array[StandardMaterial3D] = []
var _arms: Array[Node3D] = []
var _eye_light: OmniLight3D
var _shield: Node3D


func setup(p_type: Type) -> void:
	type = p_type


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1 | 2 | 4
	_t = randf() * 10.0
	_strafe_dir = 1.0 if randf() < 0.5 else -1.0
	_player = get_tree().get_first_node_in_group("player") as Player
	match type:
		Type.MINION:
			max_hp = 42.0
			speed = 6.5
			damage = 9.0
			attack_range = 2.3
			windup_time = 0.55
			hit_radius = 0.6
			_hover = 1.3
			accent = Color(1.0, 0.18, 0.3)
		Type.GUNNER:
			max_hp = 36.0
			speed = 5.0
			damage = 7.0
			attack_range = 30.0
			windup_time = 0.5
			hit_radius = 0.6
			_hover = 2.6
			accent = Color(1.0, 0.6, 0.1)
		Type.SHIELD:
			max_hp = 100.0
			speed = 3.2
			damage = 17.0
			attack_range = 2.8
			windup_time = 0.9
			hit_radius = 0.9
			_hover = 0.0
			accent = Color(0.3, 0.6, 1.0)
	hp = max_hp
	_build_visuals()


func _build_visuals() -> void:
	var cs := CollisionShape3D.new()
	if type == Type.SHIELD:
		var cap := CapsuleShape3D.new()
		cap.radius = 0.7
		cap.height = 2.2
		cs.shape = cap
		cs.position.y = 1.1
	else:
		var sh := SphereShape3D.new()
		sh.radius = 0.55
		cs.shape = sh
	add_child(cs)

	_body_root = Node3D.new()
	add_child(_body_root)
	_body_mat = Fx3D.neon_mat(Color(0.07, 0.07, 0.1), Color(0, 0, 0, 0), 0.0, 0.85, 0.25)
	_eye_mat = Fx3D.neon_mat(Color(0.1, 0.0, 0.0), accent, 5.0)
	var accent_mat := Fx3D.neon_mat(Color(0.05, 0.05, 0.05), accent, 2.5)
	_accent_mats.append(accent_mat)

	match type:
		Type.MINION:
			_mesh(_sphere(0.45), _body_mat, Vector3.ZERO)
			_mesh(_box(Vector3(0.95, 0.08, 0.3)), accent_mat, Vector3(0, 0.0, 0.0))
			_mesh(_sphere(0.15), _eye_mat, Vector3(0, 0.05, -0.38))
			for side in [-1.0, 1.0]:
				var arm := Node3D.new()
				arm.position = Vector3(0.5 * side, 0, 0)
				_body_root.add_child(arm)
				_mesh(_box(Vector3(0.08, 0.08, 0.7)), _body_mat, Vector3(0, 0, -0.25), arm)
				_mesh(_box(Vector3(0.1, 0.02, 0.6)), accent_mat, Vector3(0, 0.05, -0.3), arm)
				_arms.append(arm)
			var ring := TorusMesh.new()
			ring.inner_radius = 0.42
			ring.outer_radius = 0.5
			_mesh(ring, Fx3D.glow_mat(accent, 3.0, 0.8), Vector3(0, -0.45, 0))
		Type.GUNNER:
			_mesh(_box(Vector3(0.75, 0.5, 0.75)), _body_mat, Vector3.ZERO)
			_mesh(_box(Vector3(0.8, 0.06, 0.8)), accent_mat, Vector3(0, 0.2, 0))
			_mesh(_cyl(0.11, 0.7), _body_mat, Vector3(0, -0.05, -0.55), null, Vector3(PI * 0.5, 0, 0))
			_mesh(_cyl(0.07, 0.05), _eye_mat, Vector3(0, -0.05, -0.92), null, Vector3(PI * 0.5, 0, 0))
			_mesh(_sphere(0.12), _eye_mat, Vector3(0, 0.12, -0.38))
			_mesh(_cyl(0.015, 0.5), accent_mat, Vector3(0.25, 0.45, 0.2))
			for side in [-1.0, 1.0]:
				_mesh(_box(Vector3(0.12, 0.3, 0.5)), _body_mat, Vector3(0.48 * side, -0.1, 0))
		Type.SHIELD:
			_mesh(_cyl(0.55, 1.4, 0.45), _body_mat, Vector3(0, 1.0, 0))
			_mesh(_sphere(0.4), _body_mat, Vector3(0, 1.95, 0))
			_mesh(_box(Vector3(0.5, 0.1, 0.1)), _eye_mat, Vector3(0, 1.98, -0.36))
			_mesh(_box(Vector3(1.2, 0.08, 1.2)), accent_mat, Vector3(0, 0.4, 0))
			for side in [-1.0, 1.0]:
				_mesh(_box(Vector3(0.3, 0.8, 0.35)), _body_mat, Vector3(0.3 * side, 0.4, 0))
			_shield = Node3D.new()
			_shield.position = Vector3(0, 1.1, -0.85)
			_body_root.add_child(_shield)
			_mesh(_box(Vector3(1.5, 1.7, 0.12)), Fx3D.neon_mat(Color(0.05, 0.1, 0.2), Color(0.2, 0.5, 1.0), 0.8, 0.9, 0.2), Vector3.ZERO, _shield)
			_mesh(_box(Vector3(1.55, 0.05, 0.14)), Fx3D.glow_mat(accent, 4.0), Vector3(0, 0.85, 0), _shield)
			_mesh(_box(Vector3(1.55, 0.05, 0.14)), Fx3D.glow_mat(accent, 4.0), Vector3(0, -0.85, 0), _shield)
			_mesh(_box(Vector3(0.05, 1.7, 0.14)), Fx3D.glow_mat(accent, 3.0), Vector3(0, 0, 0), _shield)
	_eye_light = OmniLight3D.new()
	_eye_light.light_color = accent
	_eye_light.light_energy = 1.0
	_eye_light.omni_range = 3.0
	_eye_light.position = Vector3(0, 0.1 if type != Type.SHIELD else 2.0, -0.6)
	_body_root.add_child(_eye_light)
	# Spawn-in effect.
	_body_root.scale = Vector3.ONE * 0.01
	var tw := create_tween()
	tw.tween_property(_body_root, "scale", Vector3.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _mesh(m: Mesh, mat: Material, pos: Vector3, parent: Node3D = null, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	(parent if parent != null else _body_root).add_child(mi)
	return mi


func _box(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func _sphere(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 20
	s.rings = 10
	return s


func _cyl(r: float, h: float, top := -1.0) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.bottom_radius = r
	c.top_radius = r if top < 0.0 else top
	c.height = h
	return c


func aim_point() -> Vector3:
	return global_position + Vector3(0, 1.1 if type == Type.SHIELD else 0.0, 0)


# --- AI ---------------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if dead:
		return
	_t += delta
	_flash = move_toward(_flash, 0.0, delta * 6.0)
	_attack_cd -= delta
	_knock = _knock.move_toward(Vector3.ZERO, delta * 25.0)
	var frozen := _freeze > 0.0
	if frozen:
		_freeze -= delta
	if _stun > 0.0:
		_stun -= delta
	_update_look(frozen)
	if frozen or _player == null or not _player.alive:
		velocity = _knock
		if type == Type.SHIELD:
			velocity.y -= 20.0 * delta
		move_and_slide()
		return

	var to_player := _player.global_position - global_position
	var flat := Vector3(to_player.x, 0, to_player.z)
	var dist := flat.length()
	var dir := flat.normalized() if dist > 0.01 else Vector3.FORWARD
	var move := Vector3.ZERO

	if _stun > 0.0:
		_state = 2
		_state_t = maxf(_state_t, 0.2)
	match _state:
		0:
			move = _approach(dir, dist)
			if _attack_cd <= 0.0 and dist < attack_range and _stun <= 0.0:
				_state = 1
				_state_t = windup_time
				Audio.play("windup", -14.0, 0.1)
		1:
			_state_t -= delta
			move = -dir * 0.6 if type == Type.MINION else Vector3.ZERO
			if _state_t <= 0.0:
				_attack(dir, dist)
				_state = 2
				_state_t = 0.8 if type != Type.SHIELD else 1.1
		2:
			_state_t -= delta
			move = _approach(dir, dist) * 0.35
			if _state_t <= 0.0 and _stun <= 0.0:
				_state = 0
				_attack_cd = randf_range(0.4, 1.2) if type == Type.MINION else randf_range(1.6, 2.8)

	move += _separation() * 3.0
	velocity.x = move.x + _knock.x
	velocity.z = move.z + _knock.z
	if type == Type.SHIELD:
		velocity.y -= 20.0 * delta
		if is_on_floor() and velocity.y < 0.0:
			velocity.y = 0.0
		velocity.y += _knock.y
	else:
		var target_y := _hover + sin(_t * 2.0) * 0.15
		velocity.y = (target_y - global_position.y) * 4.0 + _knock.y
	move_and_slide()
	# Face the player.
	var look := Vector3(_player.global_position.x, global_position.y, _player.global_position.z)
	if global_position.distance_to(look) > 0.1:
		var target_basis := Basis.looking_at((look - global_position).normalized(), Vector3.UP)
		basis = basis.slerp(target_basis, clampf(delta * 8.0, 0.0, 1.0)).orthonormalized()


func _approach(dir: Vector3, dist: float) -> Vector3:
	match type:
		Type.GUNNER:
			var side := dir.cross(Vector3.UP) * _strafe_dir
			if dist < 9.0:
				return (-dir + side * 0.6).normalized() * speed
			elif dist > 15.0:
				return (dir + side * 0.3).normalized() * speed
			if randf() < 0.005:
				_strafe_dir *= -1.0
			return side * speed * 0.6
		_:
			if dist > attack_range * 0.7:
				return dir * speed
			return Vector3.ZERO


func _separation() -> Vector3:
	var push := Vector3.ZERO
	for e in get_tree().get_nodes_in_group("enemies"):
		if e == self or not e is Enemy:
			continue
		var d: Vector3 = global_position - e.global_position
		d.y = 0
		var l := d.length()
		if l < 1.6 and l > 0.01:
			push += d / l * (1.6 - l)
	return push


func _attack(dir: Vector3, dist: float) -> void:
	match type:
		Type.MINION:
			_knock = dir * 14.0
			if dist < attack_range + 0.9:
				_player.take_damage(damage, global_position, self)
			Audio.play("enemy_swipe", -8.0, 0.1)
		Type.GUNNER:
			_fire_burst()
		Type.SHIELD:
			Fx3D.ring(get_parent(), global_position + Vector3(0, 0.1, 0) + dir * 1.2, accent, 3.2, 0.35, 0.15)
			Fx3D.sparks(get_parent(), global_position + dir * 1.4, accent, 20, 7.0, 0.07)
			Audio.play("slam", -4.0)
			if dist < attack_range + 0.9:
				_player.take_damage(damage, global_position, self)


func _fire_burst() -> void:
	for i in 3:
		if dead or not is_inside_tree() or _player == null:
			return
		var from := global_position + (-global_transform.basis.z) * 0.95 + Vector3(0, -0.05, 0)
		var target := _player.global_position + Vector3(0, 1.2, 0) + _player.velocity * 0.15
		var p := Projectile.spawn(get_parent(), from, (target - from).normalized() * 17.0, 1, damage, accent, 0.16)
		p.lifetime = 4.0
		Audio.play("enemy_shoot", -12.0, 0.1)
		await get_tree().create_timer(0.14, false).timeout


func _update_look(frozen: bool) -> void:
	var windup := _state == 1
	var k := 0.0
	if windup:
		k = 1.0 - _state_t / windup_time
	var eye_energy := 5.0 + k * 20.0 + _flash * 25.0
	_eye_mat.emission_energy_multiplier = eye_energy
	_eye_mat.emission = Color(1, 1, 1).lerp(accent, 0.3) if windup and fmod(_t, 0.12) < 0.06 else accent
	_eye_light.light_energy = 1.0 + k * 4.0
	_body_mat.emission_enabled = _flash > 0.01 or frozen
	if frozen:
		_body_mat.emission = Color(0.5, 0.85, 1.0)
		_body_mat.emission_energy_multiplier = 1.5
	elif _flash > 0.01:
		_body_mat.emission = Color(1, 1, 1)
		_body_mat.emission_energy_multiplier = _flash * 3.0
	for i in _arms.size():
		_arms[i].rotation.y = (0.9 * k if i == 0 else -0.9 * k) + sin(_t * 6.0) * 0.1
	if type == Type.SHIELD and _shield != null:
		_shield.position.y = 1.1 + (0.4 * k)
	_body_root.rotation.z = sin(_t * 1.7) * 0.06 if type != Type.SHIELD else 0.0


# --- damage ---------------------------------------------------------------

func take_hit(amount: float, dir: Vector3, heavy: bool, from_pos: Vector3) -> float:
	if dead:
		return 0.0
	if type == Type.SHIELD and not heavy and _freeze <= 0.0:
		var to_src := from_pos - global_position
		to_src.y = 0
		if to_src.normalized().dot(-global_transform.basis.z) > 0.35:
			amount *= 0.15
			Fx3D.sparks(get_parent(), global_position + Vector3(0, 1.2, 0) - global_transform.basis.z * 0.9, Color(0.4, 0.7, 1.0), 10, 5.0, 0.05)
			Audio.play("block", -10.0, 0.1)
	hp -= amount
	_flash = 1.0
	var knock_strength := (5.0 if heavy else 2.0) * (0.4 if type == Type.SHIELD else 1.0)
	_knock += Vector3(dir.x, maxf(dir.y, 0.0), dir.z) * knock_strength * 3.0
	if type == Type.MINION and heavy:
		_stun = maxf(_stun, 0.35)
		_state = 2
		_state_t = 0.35
	if hp <= 0.0:
		_die()
	return amount


func stun(duration: float) -> void:
	_stun = maxf(_stun, duration)
	_state = 2
	_state_t = duration
	Fx3D.ring(get_parent(), aim_point() + Vector3(0, 0.8, 0), Color(1, 1, 0.5), 0.6, 0.4, 0.15)


func freeze(duration: float) -> void:
	_freeze = maxf(_freeze, duration)
	_state = 0


## Drag toward a point (Jade's Cyclone / Tempest).
func pull(to_pos: Vector3, strength: float) -> void:
	var d := to_pos - global_position
	d.y = 0.0
	if d.length() > 0.3:
		_knock += d.normalized() * strength
	_stun = maxf(_stun, 0.25)


func launch(up: float) -> void:
	_knock.y += up
	_stun = maxf(_stun, 0.8)


func _die() -> void:
	dead = true
	remove_from_group("enemies")
	collision_layer = 0
	collision_mask = 0
	Game.stats.kills += 1
	var pos := aim_point()
	Fx3D.explosion(get_parent(), pos, accent, 1.6 if type != Type.SHIELD else 2.4)
	Fx3D.sparks(get_parent(), pos, Color(1, 0.8, 0.5), 18, 9.0, 0.05, 0.8)
	Audio.play("enemy_die", -4.0, 0.12)
	if randf() < 0.22 and get_parent() != null:
		var orb := HealthOrb.new()
		get_parent().add_child(orb)
		orb.global_position = pos
	died.emit(self)
	queue_free()
