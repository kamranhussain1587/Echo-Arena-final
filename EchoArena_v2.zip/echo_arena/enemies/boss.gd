class_name Boss
extends CharacterBody3D
## THE WARDEN - two-stage boss.
## Stage 1, WARDEN MECH: ground slam shockwaves (jump them), a sweeping laser
## fence (jump or dash through), homing missiles, minion reinforcements.
## Stage 2, WARDEN CORE: the core breaks free and flies - bullet rings,
## spirals and dash attacks. After each dash it sinks low and is vulnerable.

signal health_changed(hp: float, max_hp: float, stage: int)
signal stage_changed(stage: int)
signal defeated
signal request_spawn(type: int, count: int)

const RED := Color(1.0, 0.15, 0.25)
const HOT := Color(1.0, 0.45, 0.2)

var dead := false
var stage := 1
var max_hp := 1800.0
var hp := 1800.0
var hit_radius := 3.0

var _player: Player
var _t := 0.0
var _attack_t := 3.5
var _busy := false
var _transition := false
var _flash := 0.0
var _freeze := 0.0
var _summon_marks := [0.7, 0.4]
var _rage := false

var _mech: Node3D
var _arms: Array[Node3D] = []
var _eye_mat: StandardMaterial3D
var _hull_mat: StandardMaterial3D
var _core: Node3D
var _core_mat: StandardMaterial3D
var _rings: Array[Node3D] = []
var _core_light: OmniLight3D
var _shape: CollisionShape3D

var _waves: Array = []        # shockwave rings: {r, node, hit}
var _laser: Node3D
var _laser_t := 0.0
var _laser_from := 0.0
var _laser_span := 0.0
var _laser_hit_cd := 0.0
var _core_target := Vector3.ZERO
var _vulnerable := 0.0
var _dash_t := 0.0
var _dash_dir := Vector3.ZERO


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1
	_player = get_tree().get_first_node_in_group("player") as Player
	_shape = CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 2.0
	cap.height = 7.0
	_shape.shape = cap
	_shape.position.y = 3.5
	add_child(_shape)
	_build_mech()
	_build_core()
	health_changed.emit(hp, max_hp, stage)


# --- visuals --------------------------------------------------------------

func _m(mesh: Mesh, mat: Material, pos: Vector3, parent: Node3D, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	parent.add_child(mi)
	return mi


func _box(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func _build_mech() -> void:
	_mech = Node3D.new()
	add_child(_mech)
	_hull_mat = Fx3D.neon_mat(Color(0.08, 0.08, 0.11), Color(0, 0, 0, 0), 0.0, 0.9, 0.3)
	_eye_mat = Fx3D.neon_mat(Color(0.2, 0, 0), RED, 8.0)
	var stripe := Fx3D.glow_mat(RED, 4.0)
	for side in [-1.0, 1.0]:
		_m(_box(Vector3(1.1, 3.0, 1.3)), _hull_mat, Vector3(1.3 * side, 1.5, 0), _mech)
		_m(_box(Vector3(1.15, 0.12, 1.35)), stripe, Vector3(1.3 * side, 2.2, 0), _mech)
		_m(_box(Vector3(1.5, 0.5, 2.0)), _hull_mat, Vector3(1.3 * side, 0.25, -0.2), _mech)
	_m(_box(Vector3(3.6, 1.0, 2.0)), _hull_mat, Vector3(0, 3.3, 0), _mech)
	_m(_box(Vector3(4.4, 2.8, 2.6)), _hull_mat, Vector3(0, 5.0, 0), _mech)
	_m(_box(Vector3(4.5, 0.15, 2.7)), stripe, Vector3(0, 4.0, 0), _mech)
	_m(_box(Vector3(0.15, 2.6, 2.7)), stripe, Vector3(1.6, 5.0, 0), _mech)
	_m(_box(Vector3(0.15, 2.6, 2.7)), stripe, Vector3(-1.6, 5.0, 0), _mech)
	_m(_box(Vector3(1.8, 1.3, 1.6)), _hull_mat, Vector3(0, 7.0, 0), _mech)
	var eye := SphereMesh.new()
	eye.radius = 0.42
	eye.height = 0.84
	_m(eye, _eye_mat, Vector3(0, 7.05, -0.75), _mech)
	_m(_box(Vector3(1.9, 0.1, 0.1)), stripe, Vector3(0, 7.55, -0.8), _mech)
	for side in [-1.0, 1.0]:
		_m(_box(Vector3(1.6, 0.9, 1.8)), _hull_mat, Vector3(2.7 * side, 6.1, 0), _mech)
		var arm := Node3D.new()
		arm.position = Vector3(2.8 * side, 5.9, 0)
		_mech.add_child(arm)
		_m(_box(Vector3(0.9, 3.2, 0.9)), _hull_mat, Vector3(0, -1.6, 0), arm)
		var cannon := CylinderMesh.new()
		cannon.top_radius = 0.35
		cannon.bottom_radius = 0.45
		cannon.height = 0.9
		_m(cannon, _hull_mat, Vector3(0, -3.4, 0), arm)
		_m(_box(Vector3(0.95, 0.12, 0.95)), stripe, Vector3(0, -2.8, 0), arm)
		_arms.append(arm)
	var l := OmniLight3D.new()
	l.light_color = RED
	l.light_energy = 3.0
	l.omni_range = 10.0
	l.position = Vector3(0, 7.0, -1.5)
	_mech.add_child(l)


func _build_core() -> void:
	_core = Node3D.new()
	_core.position = Vector3(0, 5.0, -1.35)
	add_child(_core)
	_core_mat = Fx3D.neon_mat(Color(0.3, 0.05, 0.05), Color(1, 0.4, 0.4), 6.0, 0.2, 0.2)
	var s := SphereMesh.new()
	s.radius = 0.7
	s.height = 1.4
	_m(s, _core_mat, Vector3.ZERO, _core)
	for i in 3:
		var holder := Node3D.new()
		holder.rotation = Vector3(randf() * PI, randf() * PI, 0)
		_core.add_child(holder)
		var t := TorusMesh.new()
		t.inner_radius = 1.05 + i * 0.25
		t.outer_radius = 1.12 + i * 0.25
		_m(t, Fx3D.glow_mat(RED.lerp(HOT, i * 0.4), 4.0), Vector3.ZERO, holder)
		_rings.append(holder)
	_core_light = OmniLight3D.new()
	_core_light.light_color = RED
	_core_light.light_energy = 2.0
	_core_light.omni_range = 8.0
	_core_light.light_volumetric_fog_energy = 3.0
	_core.add_child(_core_light)
	for h in _rings:
		h.visible = false


func aim_point() -> Vector3:
	if stage == 1:
		return global_position + Vector3(0, 4.6, 0)
	return _core.global_position


# --- update -----------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if dead or _player == null:
		return
	_t += delta
	_flash = move_toward(_flash, 0.0, delta * 5.0)
	_core_mat.emission_energy_multiplier = 6.0 + _flash * 20.0 + (sin(_t * 8.0) * 2.0 if _rage else 0.0)
	_hull_mat.emission_enabled = _flash > 0.01
	_hull_mat.emission = Color.WHITE
	_hull_mat.emission_energy_multiplier = _flash * 2.0
	for i in _rings.size():
		_rings[i].rotate_object_local(Vector3(1, 0.3 * i, 0).normalized(), delta * (1.5 + i))
	_update_waves(delta)
	_update_laser(delta)
	if _transition:
		return
	if _freeze > 0.0:
		_freeze -= delta
		return
	if stage == 1:
		_mech_move(delta)
	else:
		_core_move(delta)
	if not _busy:
		_attack_t -= delta
		if _attack_t <= 0.0:
			_choose_attack()


func _face_player(delta: float) -> void:
	var look := Vector3(_player.global_position.x, global_position.y, _player.global_position.z)
	if global_position.distance_to(look) > 0.5:
		var target := Basis.looking_at((look - global_position).normalized(), Vector3.UP)
		basis = basis.slerp(target, clampf(delta * 2.0, 0.0, 1.0)).orthonormalized()


func _mech_move(delta: float) -> void:
	_face_player(delta)
	var to := _player.global_position - global_position
	to.y = 0
	var v := Vector3.ZERO
	if not _busy and to.length() > 10.0:
		v = to.normalized() * 2.2
	velocity = Vector3(v.x, velocity.y - 30.0 * delta, v.z)
	move_and_slide()
	if is_on_floor():
		velocity.y = 0.0
	_mech.position.y = absf(sin(_t * 2.2)) * 0.08 * (1.0 if v.length() > 0.1 else 0.0)


func _core_move(delta: float) -> void:
	if _dash_t > 0.0:
		_dash_t -= delta
		global_position += _dash_dir * 28.0 * delta
		if _player.global_position.distance_to(_core.global_position) < 2.4:
			_player.take_damage(18.0, _core.global_position, self)
			_dash_t = 0.0
		if _dash_t <= 0.0:
			_vulnerable = 1.8
			Fx3D.ring(get_parent(), Vector3(global_position.x, 0.1, global_position.z), RED, 4.0, 0.4, 0.1)
		return
	var height := 2.6 if _vulnerable > 0.0 else 4.2 + sin(_t * 1.3) * 0.6
	if _vulnerable > 0.0:
		_vulnerable -= delta
		_core_target = Vector3(global_position.x, height, global_position.z)
	elif not _busy:
		var ang := _t * (0.35 if not _rage else 0.55)
		_core_target = Vector3(cos(ang) * 10.0, height, sin(ang) * 10.0)
	_core_target.y = height
	global_position = global_position.lerp(_core_target, clampf(delta * 1.5, 0.0, 1.0))


func _choose_attack() -> void:
	if stage == 1:
		var r := randf()
		if r < 0.38:
			_slam()
		elif r < 0.7:
			_laser_sweep()
		else:
			_missiles()
		_attack_t = randf_range(1.8, 2.6)
	else:
		var r := randf()
		if r < 0.36:
			_bullet_ring()
		elif r < 0.66:
			_spiral()
		else:
			_core_dash()
		_attack_t = randf_range(1.3, 2.0) if _rage else randf_range(1.8, 2.6)


# --- stage 1 attacks ----------------------------------------------------------

func _slam() -> void:
	_busy = true
	Audio.play("boss_charge", -4.0)
	var tw := create_tween().set_parallel(true)
	for a in _arms:
		tw.tween_property(a, "rotation:x", -2.6, 0.75).set_trans(Tween.TRANS_BACK)
	_eye_mat.emission_energy_multiplier = 20.0
	await get_tree().create_timer(0.85, false).timeout
	if dead or _transition:
		_busy = false
		return
	var tw2 := create_tween().set_parallel(true)
	for a in _arms:
		tw2.tween_property(a, "rotation:x", 0.3, 0.12)
	await get_tree().create_timer(0.12, false).timeout
	_eye_mat.emission_energy_multiplier = 8.0
	var front := global_position - global_transform.basis.z * 2.5
	front.y = 0.15
	Fx3D.explosion(get_parent(), front + Vector3(0, 0.5, 0), RED, 3.0)
	Audio.play("slam", 2.0)
	_player.add_shake(0.6 if _player.global_position.distance_to(front) < 15.0 else 0.25)
	_spawn_wave(front)
	var tw3 := create_tween().set_parallel(true)
	for a in _arms:
		tw3.tween_property(a, "rotation:x", 0.0, 0.5)
	await get_tree().create_timer(0.4, false).timeout
	_busy = false


func _spawn_wave(center: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var t := TorusMesh.new()
	t.inner_radius = 0.93
	t.outer_radius = 1.0
	t.rings = 64
	mi.mesh = t
	mi.material_override = Fx3D.glow_mat(RED, 5.0)
	get_parent().add_child(mi)
	mi.global_position = center
	mi.scale = Vector3(1, 0.6, 1)
	var l := OmniLight3D.new()
	l.light_color = RED
	l.light_energy = 2.0
	l.omni_range = 6.0
	mi.add_child(l)
	_waves.append({"r": 1.0, "node": mi, "hit": false, "c": center})


func _update_waves(delta: float) -> void:
	for w in _waves.duplicate():
		w.r += 16.0 * delta
		var node: MeshInstance3D = w.node
		if not is_instance_valid(node):
			_waves.erase(w)
			continue
		node.scale = Vector3(w.r, 0.6 + 0.2 * sin(w.r), w.r)
		var c: Vector3 = w.c
		var pd := Vector2(_player.global_position.x - c.x, _player.global_position.z - c.z).length()
		if not w.hit and absf(pd - w.r) < 0.9 and _player.global_position.y < 0.7:
			w.hit = true
			_player.take_damage(16.0, c, null)
		if w.r > 30.0:
			node.queue_free()
			_waves.erase(w)


func _laser_sweep() -> void:
	_busy = true
	Audio.play("boss_charge", -2.0, 0.0, 1.3)
	_eye_mat.emission_energy_multiplier = 30.0
	Fx3D.flash_light(get_parent(), global_position + Vector3(0, 7, 0), RED, 6.0, 12.0, 0.9)
	await get_tree().create_timer(0.9, false).timeout
	if dead or _transition:
		_busy = false
		return
	_eye_mat.emission_energy_multiplier = 8.0
	_laser = Node3D.new()
	add_child(_laser)
	_laser.position = Vector3(0, 1.0, 0)
	for layer in 2:
		var mi := MeshInstance3D.new()
		var c := CylinderMesh.new()
		c.top_radius = 0.22 if layer == 0 else 0.09
		c.bottom_radius = c.top_radius
		c.height = 34.0
		mi.mesh = c
		mi.material_override = Fx3D.glow_mat(RED if layer == 0 else Color(1, 0.8, 0.8), 5.0, 0.9)
		mi.rotation.x = PI * 0.5
		mi.position = Vector3(0, 0, -17.0)
		_laser.add_child(mi)
	var ll := OmniLight3D.new()
	ll.light_color = RED
	ll.light_energy = 4.0
	ll.omni_range = 12.0
	ll.position = Vector3(0, 0, -8)
	_laser.add_child(ll)
	_laser_span = deg_to_rad(220.0)
	_laser_from = -_laser_span * 0.5 * (1.0 if randf() < 0.5 else -1.0)
	_laser.rotation.y = _laser_from
	_laser_t = 2.4
	Audio.play("laser", 0.0)


func _update_laser(delta: float) -> void:
	if _laser == null:
		return
	_laser_hit_cd -= delta
	_laser_t -= delta
	var k := 1.0 - _laser_t / 2.4
	_laser.rotation.y = _laser_from - signf(_laser_from) * _laser_span * k
	# Hit test: player inside the beam's angular width and low enough.
	var to := _player.global_position - global_position
	to.y = 0
	var beam_dir := -_laser.global_transform.basis.z
	beam_dir.y = 0
	var dist := to.length()
	if dist < 34.0 and dist > 0.5:
		var ang := beam_dir.normalized().angle_to(to.normalized())
		var feet := _player.global_position.y
		if ang < atan(0.7 / dist) + 0.02 and feet < 1.15 and _laser_hit_cd <= 0.0:
			_laser_hit_cd = 0.5
			_player.take_damage(18.0, global_position, null)
	if _laser_t <= 0.0:
		_laser.queue_free()
		_laser = null
		_busy = false


func _missiles() -> void:
	_busy = true
	for i in 6:
		if dead or _transition:
			break
		var arm := _arms[i % 2]
		var from := arm.global_position + arm.global_transform.basis.y * -3.6
		var dir := (Vector3.UP * 1.5 + (-global_transform.basis.z) + Vector3(randf_range(-0.8, 0.8), 0, randf_range(-0.8, 0.8))).normalized()
		var p := Projectile.spawn(get_parent(), from, dir * 11.0, 1, 12.0, HOT, 0.28)
		p.homing_target = _player
		p.homing_turn = 1.6
		p.explode_radius = 2.2
		p.lifetime = 6.0
		p.light_energy = 3.0
		Audio.play("enemy_shoot", -6.0, 0.1, 0.7)
		await get_tree().create_timer(0.18, false).timeout
	await get_tree().create_timer(0.4, false).timeout
	_busy = false


# --- stage 2 attacks ----------------------------------------------------------

func _bullet_ring() -> void:
	_busy = true
	var count := 26 if _rage else 18
	for wave in (2 if _rage else 1):
		Fx3D.flash_light(get_parent(), _core.global_position, RED, 6.0, 10.0, 0.3)
		for i in count:
			var a := TAU * float(i) / count + wave * 0.12
			var dir := Vector3(cos(a), 0, sin(a))
			var p := Projectile.spawn(get_parent(), _core.global_position + dir, Vector3(dir.x, -0.12, dir.z).normalized() * 9.0, 1, 8.0, RED, 0.22)
			p.lifetime = 5.0
			p.light_energy = 0.8
		Audio.play("enemy_shoot", -2.0, 0.0, 0.6)
		await get_tree().create_timer(0.35, false).timeout
	_busy = false


func _spiral() -> void:
	_busy = true
	var steps := 26 if _rage else 20
	for i in steps:
		if dead:
			break
		for arm in 3:
			var a := _t * 3.0 + arm * TAU / 3.0
			var dir := Vector3(cos(a), -0.15, sin(a)).normalized()
			var p := Projectile.spawn(get_parent(), _core.global_position + dir, dir * 10.0, 1, 7.0, HOT, 0.2)
			p.lifetime = 4.0
			p.light_energy = 0.6
		if i % 3 == 0:
			Audio.play("enemy_shoot", -10.0, 0.1, 0.8)
		await get_tree().create_timer(0.08, false).timeout
	_busy = false


func _core_dash() -> void:
	_busy = true
	var target := _player.global_position + Vector3(0, 1.2, 0)
	var from := _core.global_position
	Fx3D.beam(get_parent(), from, target, RED, 0.05, 0.7)
	Audio.play("boss_charge", -4.0, 0.0, 1.5)
	await get_tree().create_timer(0.7, false).timeout
	if dead:
		return
	_dash_dir = (target - _core.global_position).normalized()
	_dash_t = minf(_core.global_position.distance_to(target) / 28.0, 0.8)
	Audio.play("dash", 0.0, 0.0, 0.6)
	await get_tree().create_timer(_dash_t + 0.2, false).timeout
	_busy = false


# --- damage & stages -----------------------------------------------------------

func take_hit(amount: float, _dir: Vector3, heavy: bool, _from: Vector3) -> float:
	if dead or _transition:
		return 0.0
	if stage == 2 and _vulnerable > 0.0:
		amount *= 1.5
	hp -= amount
	_flash = 1.0 if heavy else 0.6
	health_changed.emit(maxf(hp, 0.0), max_hp, stage)
	if stage == 1 and not _summon_marks.is_empty() and hp / max_hp < _summon_marks[0]:
		_summon_marks.pop_front()
		request_spawn.emit(Enemy.Type.MINION, 3)
		Audio.play("boss_roar", -2.0)
	if stage == 2 and not _rage and hp / max_hp < 0.35:
		_rage = true
		request_spawn.emit(Enemy.Type.GUNNER, 2)
		Audio.play("boss_roar", 0.0)
		if _player.hud != null:
			_player.hud.callout("WARDEN ENRAGED", RED, true)
	if hp <= 0.0:
		if stage == 1:
			_to_stage_two()
		else:
			_die()
	return amount


func stun(duration: float) -> void:
	_attack_t += duration * 0.3


func freeze(duration: float) -> void:
	_freeze = maxf(_freeze, duration * 0.35)


func launch(_up: float) -> void:
	pass


func _to_stage_two() -> void:
	_transition = true
	if _laser != null:
		_laser.queue_free()
		_laser = null
	Game.slowmo(0.25, 2.2)
	Audio.play("boss_roar", 2.0)
	for i in 5:
		var p := global_position + Vector3(randf_range(-2.5, 2.5), randf_range(1.0, 7.0), randf_range(-1.5, 1.5))
		Fx3D.explosion(get_parent(), p, HOT if i % 2 else RED, 3.0)
		Audio.play("explosion", 0.0, 0.1)
		_player.add_shake(0.5)
		await get_tree().create_timer(0.25, true, false, true).timeout
	Game.flash_white(0.8)
	_mech.visible = false
	var core_global := _core.global_position
	global_position = core_global
	_core.position = Vector3.ZERO
	(_shape.shape as CapsuleShape3D).radius = 1.4
	(_shape.shape as CapsuleShape3D).height = 2.8
	_shape.position = Vector3.ZERO
	collision_mask = 0
	for h in _rings:
		h.visible = true
	_core_light.light_energy = 6.0
	_core_light.omni_range = 16.0
	var tw := create_tween()
	tw.tween_property(_core, "scale", Vector3.ONE * 1.6, 0.6).set_trans(Tween.TRANS_BACK)
	stage = 2
	max_hp = 1300.0
	hp = max_hp
	hit_radius = 1.7
	_attack_t = 2.0
	_busy = false
	stage_changed.emit(2)
	health_changed.emit(hp, max_hp, stage)
	await get_tree().create_timer(0.8, true, false, true).timeout
	_transition = false


func _die() -> void:
	dead = true
	remove_from_group("enemies")
	Game.stats.kills += 1
	Game.slowmo(0.15, 3.0)
	for i in 7:
		var p := _core.global_position + Vector3(randf_range(-2, 2), randf_range(-1.5, 1.5), randf_range(-2, 2))
		Fx3D.explosion(get_parent(), p, RED if i % 2 else Color(1, 0.9, 0.7), 2.5 + i * 0.4)
		Audio.play("explosion", 2.0, 0.15)
		_player.add_shake(0.6)
		await get_tree().create_timer(0.22, true, false, true).timeout
	Fx3D.explosion(get_parent(), _core.global_position, Color.WHITE, 9.0)
	Game.flash_white(1.2)
	_core.visible = false
	defeated.emit()
