extends Kit
## RIOT - fists & kicks. Punch-punch-kick, Meteor Kick, Rising Uppercut, Rush Mode.

var _fists: Array[Node3D] = []
var _leg: Node3D
var _combo := 0
var _combo_t := 0.0
var _diving := false
var _dive_delay := 0.0


func build_viewmodel() -> void:
	q_cd_max = 6.0
	e_cd_max = 5.0
	var glove := Fx3D.neon_mat(Color(0.09, 0.05, 0.04), color, 0.1, 0.4, 0.45)
	for side in [-1.0, 1.0]:
		var f := Node3D.new()
		f.position = Vector3(0.28 * side, -0.3, -0.5)
		f.rotation = Vector3(0, 0, -0.2 * side)
		vm.add_child(f)
		make_mesh(box(Vector3(0.16, 0.15, 0.22)), glove, Vector3.ZERO, f)
		make_mesh(box(Vector3(0.17, 0.05, 0.05)), Fx3D.glow_mat(color, 2.0), Vector3(0, 0.03, -0.1), f)
		make_mesh(cyl(0.06, 0.3), Fx3D.neon_mat(Color(0.1, 0.1, 0.12), Color(0, 0, 0, 0), 0.0), Vector3(0, -0.02, 0.22), f, Vector3(PI * 0.5, 0, 0))
		hand_light(f, 0.7)
		_fists.append(f)
	_leg = Node3D.new()
	_leg.position = Vector3(0.1, -1.4, -0.4)
	vm.add_child(_leg)
	make_mesh(box(Vector3(0.2, 0.6, 0.22)), Fx3D.neon_mat(Color(0.1, 0.08, 0.08), Color(0, 0, 0, 0), 0.0), Vector3(0, 0.3, 0), _leg)
	make_mesh(box(Vector3(0.22, 0.14, 0.34)), glove, Vector3(0, 0.66, -0.05), _leg)
	make_mesh(box(Vector3(0.23, 0.04, 0.35)), Fx3D.glow_mat(color, 2.0), Vector3(0, 0.6, -0.05), _leg)
	_leg.visible = false


func process_kit(delta: float) -> void:
	_combo_t -= delta
	if _combo_t <= 0.0:
		_combo = 0
	if _dive_delay > 0.0:
		_dive_delay -= delta
		if _dive_delay <= 0.0:
			player.velocity = Vector3(0, -42.0, 0) + Vector3(player.aim_dir().x, 0, player.aim_dir().z) * 6.0
	if ult_active > 0.0:
		var t := Time.get_ticks_msec() * 0.001
		for f in _fists:
			f.scale = Vector3.ONE * (1.1 + sin(t * 30.0) * 0.05)


func primary(held: bool, just: bool) -> void:
	if primary_cd > 0.0 or not (just or held):
		return
	var rush := ult_active > 0.0
	primary_cd = 0.21 if not rush else 0.09
	if rush:
		var target := player.nearest_enemy(9.0, true)
		if target != null:
			var to: Vector3 = target.global_position - player.global_position
			to.y = 0
			if to.length() > 2.2:
				player.velocity += to.normalized() * 9.0
	var heavy := _combo == 2
	if heavy:
		_kick()
	else:
		var f := _fists[_combo]
		jab(f, Vector3(-0.12 * (1 if _combo == 1 else -1), 0.08, -0.38), 0.05, 0.12)
	var hits := player.melee(2.9, 120.0, 26.0 if heavy else 12.0, heavy, 9.0 if heavy else 2.0)
	if hits > 0:
		var p := player.aim_origin() + player.aim_dir() * 1.6
		Fx3D.ring(world(), p, color, 0.9 if heavy else 0.6, 0.18, 0.15, false)
		Fx3D.sparks(world(), p, color, 14 if heavy else 8, 7.0, 0.06, 0.3)
	Audio.play("swing", -9.0, 0.15, 1.3)
	if hits > 0:
		Audio.play("punch_heavy" if heavy else "punch", -3.0, 0.1)
	_combo = (_combo + 1) % 3
	_combo_t = 0.75


func _kick() -> void:
	_leg.visible = true
	_leg.rotation = Vector3(-0.2, 0, 0)
	var tw := _leg.create_tween()
	tw.tween_property(_leg, "rotation:x", 1.25, 0.07).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_leg, "rotation:x", -0.2, 0.15)
	tw.tween_callback(func() -> void: _leg.visible = false)


func skill1_press() -> void:
	if q_cd > 0.0 or _diving:
		cooldown_denied()
		return
	q_cd = q_cd_max
	_diving = true
	if player.is_on_floor():
		player.velocity.y = 11.0
		player.velocity += Vector3(player.aim_dir().x, 0, player.aim_dir().z).normalized() * 5.0
		_dive_delay = 0.3
	else:
		_dive_delay = 0.01
	callout("METEOR KICK!")
	Audio.play("dash", -2.0, 0.0, 0.7)


func on_landed() -> void:
	if not _diving or _dive_delay > 0.0:
		return
	_diving = false
	var c := player.global_position + Vector3(0, 0.3, 0)
	player.area_damage(c + Vector3(0, 0.8, 0), 5.5, 48.0, true, 8.0)
	for e in player.enemies():
		if e.global_position.distance_to(c) < 5.5 and e.has_method("launch"):
			e.launch(7.0)
	Fx3D.ring(world(), c, color, 7.0, 0.45, 0.12)
	Fx3D.ring(world(), c, Color(1, 0.9, 0.6), 4.5, 0.35, 0.08)
	Fx3D.sparks(world(), c, color, 50, 11.0, 0.1, 0.7)
	Fx3D.flash_light(world(), c + Vector3(0, 1, 0), color, 12.0, 14.0, 0.5)
	player.add_shake(0.7)
	Game.hitstop(0.08)
	Audio.play("explosion", 0.0)
	_kick()


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var f := _fists[1]
	jab(f, Vector3(-0.1, 0.45, -0.25), 0.06, 0.2)
	var fwd := player.aim_dir()
	var hits := 0
	for e in player.enemies():
		var to: Vector3 = e.aim_point() - player.aim_origin()
		if to.length() - e.hit_radius < 3.2 and to.normalized().dot(fwd) > 0.5:
			var dealt: float = e.take_hit(30.0 * player.damage_mult, Vector3.UP, true, player.aim_origin())
			player.register_hit(e, dealt, e.aim_point(), true)
			if e.has_method("launch"):
				e.launch(10.0)
			hits += 1
	var p := player.aim_origin() + fwd * 1.5
	Fx3D.ring(world(), p, color, 1.6, 0.25, 0.1, false)
	Fx3D.sparks(world(), p, color, 24, 9.0, 0.07, 0.4)
	if hits > 0:
		Game.hitstop(0.08)
		player.add_shake(0.3)
	Audio.play("punch_heavy", 0.0)
	callout("RISING UPPERCUT!")


func ultimate() -> void:
	start_ult(7.0, "RUSH MODE!!")
	player.speed_mult = 1.35
	player.damage_mult = 1.6


func end_ultimate() -> void:
	super.end_ultimate()
	player.speed_mult = 1.0
	player.damage_mult = 1.0
	for f in _fists:
		f.scale = Vector3.ONE
