#!/usr/bin/env python3
"""Generates ECHO ARENA's original soundtrack and sound effects.

Pure synthesis (numpy + scipy): no samples, no licences to worry about.
Output: ../audio/music/*.ogg and ../audio/sfx/*.ogg
(requires ffmpeg with libvorbis).

Run:  python3 tools/generate_audio.py
"""
import os
import subprocess
import tempfile
import wave

import numpy as np
from scipy.signal import butter, fftconvolve, sosfilt

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUSIC_DIR = os.path.join(ROOT, "audio", "music")
SFX_DIR = os.path.join(ROOT, "audio", "sfx")
rng = np.random.default_rng(42)


# ----------------------------------------------------------------- basics
def mtof(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def tt(dur):
    return np.arange(int(SR * dur)) / SR


def lp(x, cutoff, order=2):
    sos = butter(order, min(cutoff, SR * 0.45), btype="low", fs=SR, output="sos")
    return sosfilt(sos, x)


def hp(x, cutoff, order=2):
    sos = butter(order, cutoff, btype="high", fs=SR, output="sos")
    return sosfilt(sos, x)


def bp(x, lo, hi, order=2):
    sos = butter(order, [lo, hi], btype="band", fs=SR, output="sos")
    return sosfilt(sos, x)


def saw(f, t, phase=0.0):
    return 2.0 * ((f * t + phase) % 1.0) - 1.0


def square(f, t, duty=0.5):
    return np.where((f * t) % 1.0 < duty, 1.0, -1.0)


def tri(f, t):
    return 2.0 * np.abs(saw(f, t)) - 1.0


def adsr(n, a=0.01, d=0.1, s=0.7, r=0.2):
    env = np.ones(n) * s
    na, nd, nr = int(a * SR), int(d * SR), int(r * SR)
    na = min(na, n)
    env[:na] = np.linspace(0, 1, na, endpoint=False) if na else env[:na]
    nd = min(nd, n - na)
    env[na:na + nd] = np.linspace(1, s, nd, endpoint=False) if nd else env[na:na + nd]
    nr = min(nr, n)
    if nr:
        env[n - nr:] *= np.linspace(1, 0, nr)
    return env


def place(buf, x, start, gain=1.0):
    i = int(start * SR)
    if i >= len(buf):
        return
    j = min(len(buf), i + len(x))
    buf[i:j] += x[: j - i] * gain


def reverb_ir(decay=2.2, seconds=2.6, seed=1):
    r = np.random.default_rng(seed)
    t = tt(seconds)
    ir = r.standard_normal(len(t)) * np.exp(-t * (6.9 / decay))
    ir = lp(ir, 5000)
    ir[0] = 0
    return ir / np.sqrt(np.sum(ir ** 2))


IR_L = reverb_ir(seed=3)
IR_R = reverb_ir(seed=4)


def stereo_reverb(mono, wet=0.25):
    l = fftconvolve(mono, IR_L)[: len(mono)]
    r = fftconvolve(mono, IR_R)[: len(mono)]
    return np.stack([mono + l * wet, mono + r * wet], axis=1)


def delay(x, seconds, feedback=0.35, taps=4):
    out = x.copy()
    d = int(seconds * SR)
    g = 1.0
    for k in range(1, taps + 1):
        g *= feedback
        if d * k >= len(x):
            break
        out[d * k:] += x[: len(x) - d * k] * g
    return out


def loopify(stereo, loop_len):
    """Wrap the reverb tail back onto the start so the loop is seamless."""
    n = int(loop_len * SR)
    out = stereo[:n].copy()
    tail = stereo[n:]
    m = min(len(tail), n)
    out[:m] += tail[:m]
    return out


def write_ogg(path, data, quality=5):
    data = np.asarray(data, dtype=np.float64)
    if data.ndim == 1:
        data = data[:, None]
    peak = np.max(np.abs(data)) if data.size else 0
    if peak > 0.98:
        data = data / peak * 0.98
    pcm = (np.clip(data, -1, 1) * 32767).astype(np.int16)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        wav_path = tmp.name
    with wave.open(wav_path, "wb") as w:
        w.setnchannels(pcm.shape[1])
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav_path, "-c:a", "libvorbis",
                    "-q:a", str(quality), path], check=True)
    os.remove(wav_path)


# ------------------------------------------------------------- instruments
def pad(notes, dur, cutoff=1400, detune=0.006, gain=0.12):
    t = tt(dur)
    x = np.zeros(len(t))
    for m in notes:
        f = mtof(m)
        for k, d in enumerate((-detune, 0.0, detune)):
            x += saw(f * (1 + d), t, phase=k * 0.31)
    x = lp(x, cutoff, 2) * adsr(len(t), a=0.5, d=0.3, s=0.85, r=0.7)
    return x * gain / max(1, len(notes))


def sub(m, dur, gain=0.35):
    t = tt(dur)
    return np.sin(2 * np.pi * mtof(m) * t) * adsr(len(t), 0.01, 0.1, 0.8, 0.08) * gain


def pluck(m, dur=0.25, gain=0.18, cutoff=3200, wave_kind="square"):
    t = tt(dur)
    f = mtof(m)
    osc = square(f, t, 0.3) if wave_kind == "square" else saw(f, t)
    return lp(osc, cutoff) * np.exp(-t * 11) * gain


def bell(m, dur=1.6, gain=0.2):
    t = tt(dur)
    f = mtof(m)
    x = np.sin(2 * np.pi * f * t + 1.8 * np.exp(-t * 3) * np.sin(2 * np.pi * f * 3.5 * t))
    return x * np.exp(-t * 2.4) * adsr(len(t), 0.003, 0.05, 1.0, 0.05) * gain


def lead(m, dur, gain=0.11):
    t = tt(dur)
    f = mtof(m) * (1 + 0.004 * np.sin(2 * np.pi * 5.2 * t) * np.clip(t * 2, 0, 1))
    phase = np.cumsum(f) / SR
    x = 0.6 * (2 * (phase % 1) - 1) + 0.6 * (2 * np.abs(2 * (phase % 1) - 1) - 1)
    return lp(x, 2600) * adsr(len(t), 0.04, 0.15, 0.7, 0.18) * gain


def kick(gain=0.9):
    t = tt(0.35)
    f = 45 + 95 * np.exp(-t * 28)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t * 9)
    x[:120] += rng.standard_normal(120) * 0.3 * np.linspace(1, 0, 120)
    return np.tanh(x * 1.6) * gain


def snare(gain=0.45):
    t = tt(0.25)
    noise = bp(rng.standard_normal(len(t)), 1200, 6000) * np.exp(-t * 16)
    tone = np.sin(2 * np.pi * 185 * t) * np.exp(-t * 25)
    return (noise * 1.4 + tone * 0.6) * gain


def hat(gain=0.12, open_=False):
    t = tt(0.25 if open_ else 0.06)
    x = hp(rng.standard_normal(len(t)), 7500) * np.exp(-t * (14 if open_ else 60))
    return x * gain


def shaker(gain=0.06):
    t = tt(0.09)
    x = bp(rng.standard_normal(len(t)), 4000, 9000) * adsr(len(t), 0.02, 0.02, 0.6, 0.05)
    return x * gain


# -------------------------------------------------------------------- music
def supersaw(notes, dur, cutoff=3000, gain=0.1, voices=5, detune=0.012):
    t = tt(dur)
    x = np.zeros(len(t))
    for m in notes:
        f = mtof(m)
        for v in range(voices):
            d = (v - (voices - 1) / 2) / ((voices - 1) / 2) * detune
            x += saw(f * (1 + d), t, phase=v * 0.137)
    return lp(x, cutoff) * gain / (len(notes) * voices) * 3.0


def pump_env(n, beat, depth=0.75, speed=7.0):
    t = np.arange(n) / SR
    phase = np.mod(t, beat)
    return 1.0 - depth * np.exp(-phase * speed)


def bass_note(m, dur, gain=0.3, cutoff=900, drive=1.0):
    t = tt(dur)
    f = mtof(m)
    x = saw(f, t) * 0.7 + np.sign(np.sin(2 * np.pi * f * 0.5 * t)) * 0.3
    x = lp(x, cutoff) * adsr(len(t), 0.004, 0.08, 0.6, 0.03)
    return np.tanh(x * drive * 2.0) * gain


def clap(gain=0.35):
    x = np.zeros(int(SR * 0.3))
    for k in range(3):
        place(x, bp(rng.standard_normal(int(SR * 0.02)), 900, 5000) * 0.7, k * 0.011)
    tail = bp(rng.standard_normal(int(SR * 0.25)), 900, 5000) * env_exp(int(SR * 0.25), 18)
    place(x, tail, 0.03)
    return x * gain


def riser(dur, gain=0.2):
    t = tt(dur)
    n = rng.standard_normal(len(t))
    out = np.zeros(len(t))
    seg = int(SR * 0.05)
    for i in range(0, len(t), seg):
        k = i / len(t)
        out[i:i + seg] = bp(n[i:i + seg], 300 + 6000 * k, 600 + 9000 * k)
    return out * (t / dur) ** 2 * gain


def env_exp(n, k):
    return np.exp(-np.arange(n) / SR * k)


def edm_track(name, bpm, prog, lead_notes, minor=True, drive=1.0, intensity=1.0, bars=16, lead_from=8, out_gain=0.9):
    beat = 60.0 / bpm
    bar = beat * 4
    loop = bar * bars
    n = int((loop + 3.0) * SR)
    drums = np.zeros(n)
    bass = np.zeros(n)
    pads = np.zeros(n)
    arp = np.zeros(n)
    lead_buf = np.zeros(n)
    for b in range(bars):
        root, is_minor = prog[b % len(prog)]
        tones = [root, root + (3 if is_minor else 4), root + 7]
        t0 = b * bar
        for k in range(4):
            place(drums, kick(0.95), t0 + k * beat)
            if k in (1, 3):
                place(drums, clap(0.4), t0 + k * beat)
        for k in range(8):
            place(drums, hat(0.07 if k % 2 == 0 else 0.11, open_=(k % 2 == 1 and intensity > 1.1)), t0 + k * beat / 2 + (beat / 2 if False else 0))
        for k in range(16):
            if k % 2 == 1:
                place(drums, hat(0.05), t0 + k * beat / 4)
        if b % 4 == 3:
            for k in range(8):
                place(drums, snare(0.15 + k * 0.04), t0 + 2 * beat + k * beat / 4)
        # Offbeat bass (classic pumping electro).
        for k in range(8):
            if k % 2 == 1 or intensity > 1.15:
                place(bass, bass_note(tones[0] - 12, beat * 0.45, 0.32, 700 + 500 * intensity, drive), t0 + k * beat / 2)
        place(pads, supersaw([tones[0] + 12, tones[1] + 12, tones[2] + 12, tones[0] + 24], bar, 2500 + 1500 * intensity, 0.16), t0)
        pattern = [0, 1, 2, 1, 2, 0, 1, 2]
        for k in range(16):
            m = tones[pattern[k % 8]] + 24 + (12 if k % 8 >= 6 else 0)
            place(arp, pluck(m, beat * 0.35, 0.1, 4000), t0 + k * beat / 4)
        if b % 8 == 7:
            place(drums, riser(bar, 0.25), t0)
    for (b, off, m, length) in lead_notes:
        if b >= lead_from or lead_from == 0:
            place(lead_buf, supersaw([m], length * beat, 4500, 0.35, voices=3, detune=0.008) * adsr(int(length * beat * SR), 0.01, 0.1, 0.8, 0.05), b * bar + off * beat)
    pump = pump_env(n, beat, 0.7, 8.0)
    arp = delay(arp, beat * 0.75, 0.35)
    lead_buf = delay(lead_buf, beat * 0.5, 0.25)
    mix = stereo_reverb(drums, 0.08) + stereo_reverb(bass * pump, 0.05) + stereo_reverb(pads * pump, 0.35) * 0.9 \
        + stereo_reverb(arp * pump, 0.25) * 0.7 + stereo_reverb(lead_buf, 0.3) * 0.8
    out = loopify(mix, loop)
    out = np.tanh(out / np.max(np.abs(out)) * 1.4) * out_gain
    write_ogg(os.path.join(MUSIC_DIR, f"{name}.ogg"), out)
    print(f"  {name}: {bpm} BPM, {loop:.1f}s loop")


def hook(bars_list, motif):
    notes = []
    for b in bars_list:
        for (off, m, l) in motif[b % len(motif)]:
            notes.append((b, off, m, l))
    return notes


def build_music():
    os.makedirs(MUSIC_DIR, exist_ok=True)
    A, F, C, G, E, D, Bb = 45, 41, 48, 43, 40, 50, 46
    battle_prog = [(A, True), (F, False), (C, False), (G, False)]
    battle_motif = [
        [(0, 81, 0.5), (0.5, 84, 0.5), (1, 88, 1), (2.5, 86, 0.5), (3, 84, 1)],
        [(0, 84, 0.5), (0.5, 81, 0.5), (1, 77, 1.5), (3, 79, 1)],
        [(0, 79, 0.5), (0.5, 84, 0.5), (1, 88, 1), (2, 91, 1), (3, 88, 1)],
        [(0, 86, 1.5), (1.5, 83, 0.5), (2, 79, 2)],
    ]
    edm_track("battle", 140, battle_prog, hook(range(32), battle_motif), intensity=1.15, bars=32, lead_from=8)
    boss1_prog = [(D - 12 + 12, True), (Bb, False), (G - 12 + 12, True), (45, False)]
    boss_motif = [
        [(0, 74, 0.5), (0.5, 74, 0.5), (1, 77, 0.5), (1.5, 74, 0.5), (2, 81, 1), (3, 80, 1)],
        [(0, 77, 0.5), (0.5, 74, 0.5), (1, 70, 1), (2, 72, 2)],
        [(0, 79, 0.5), (0.5, 77, 0.5), (1, 74, 1), (2, 70, 1), (3, 74, 1)],
        [(0, 73, 1), (1, 76, 1), (2, 81, 2)],
    ]
    edm_track("boss1", 150, boss1_prog, hook(range(16), boss_motif), drive=2.0, intensity=1.25, lead_from=0)
    boss2_prog = [(E, True), (C - 12 + 12, False), (43, False), (47, False)]
    boss2_motif = [
        [(0, 88, 0.25), (0.25, 91, 0.25), (0.5, 95, 0.5), (1, 93, 0.5), (1.5, 91, 0.5), (2, 88, 1), (3, 86, 1)],
        [(0, 84, 0.5), (0.5, 88, 0.5), (1, 91, 1), (2, 84, 2)],
        [(0, 86, 0.5), (0.5, 91, 0.5), (1, 95, 1), (2, 93, 1), (3, 90, 1)],
        [(0, 91, 1), (1, 90, 1), (2, 86, 2)],
    ]
    edm_track("boss2", 165, boss2_prog, hook(range(16), boss2_motif), drive=2.5, intensity=1.4, lead_from=0)
    menu_prog = [(A, True), (F, False), (C, False), (E, False)]
    menu_motif = [
        [(0, 76, 2), (2, 79, 2)], [(0, 77, 3), (3, 76, 1)], [(0, 72, 2), (2, 74, 2)], [(0, 76, 4)],
    ]
    edm_track("menu", 110, menu_prog, hook(range(16), menu_motif), intensity=0.85, lead_from=8, out_gain=0.75)
    vic_prog = [(48, False), (43, False), (45, True), (41, False)]
    vic_motif = [
        [(0, 84, 0.5), (0.5, 88, 0.5), (1, 91, 1), (2, 88, 1), (3, 91, 1)],
        [(0, 86, 1), (1, 83, 1), (2, 79, 2)],
        [(0, 81, 0.5), (0.5, 84, 0.5), (1, 88, 1), (2, 84, 2)],
        [(0, 89, 1.5), (1.5, 88, 0.5), (2, 84, 2)],
    ]
    edm_track("victory", 124, vic_prog, hook(range(8), vic_motif), minor=False, intensity=1.0, bars=8, lead_from=0, out_gain=0.8)


# ---------------------------------------------------------------------- sfx
def noise(dur):
    return rng.standard_normal(int(SR * dur))


def sweep(f0, f1, dur, kind="sine"):
    t = tt(dur)
    f = f0 * (f1 / f0) ** (t / dur)
    ph = 2 * np.pi * np.cumsum(f) / SR
    if kind == "square":
        return np.sign(np.sin(ph))
    if kind == "saw":
        return 2 * ((ph / (2 * np.pi)) % 1) - 1
    return np.sin(ph)


def sfx(name, x, wet=0.1):
    x = np.asarray(x, dtype=np.float64)
    if wet > 0:
        padded = np.concatenate([x, np.zeros(int(SR * 0.6))])
        rev = fftconvolve(padded, IR_L)[: len(padded)]
        x = padded + rev * wet
        idx = np.where(np.abs(x) > 1e-3)[0]
        x = x[: idx[-1] + 1] if len(idx) else x
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.9
    write_ogg(os.path.join(SFX_DIR, f"{name}.ogg"), x, quality=4)


def thump(f0=120, f1=45, dur=0.25, k=12):
    t = tt(dur)
    f = f1 + (f0 - f1) * np.exp(-t * 25)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env_exp(len(t), k)


def build_sfx():
    os.makedirs(SFX_DIR, exist_ok=True)
    E = env_exp
    d = 0.18
    sfx("punch", np.tanh((thump(160, 60, d, 18) + lp(noise(d), 2500) * E(int(SR * d), 35) * 0.8) * 2.0), 0.05)
    d = 0.35
    sfx("punch_heavy", np.tanh((thump(140, 40, d, 9) * 1.2 + lp(noise(d), 3000) * E(int(SR * d), 20)) * 2.5), 0.15)
    d = 0.2
    sfx("slash", bp(noise(d), 2000, 9000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2 + 0.2 * sweep(3000, 1200, d, "saw") * E(int(SR * d), 15))
    d = 0.32
    x = bp(noise(d), 1200, 9000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 1.5
    x += 0.4 * sweep(2500, 600, d, "saw") * E(int(SR * d), 8)
    sfx("slash_heavy", x, 0.2)
    d = 0.5
    x = np.zeros(int(SR * d))
    place(x, hp(noise(0.04), 4000) * E(int(SR * 0.04), 80), 0.0)
    place(x, bell(96, 0.4, 0.6), 0.02)
    place(x, thump(200, 60, 0.3, 10) * 0.6, 0.02)
    sfx("sheathe", x, 0.4)
    d = 0.12
    sfx("bolt", lp(sweep(1800, 500, d, "square"), 5000) * E(int(SR * d), 25) * 0.6 + bp(noise(d), 3000, 9000) * E(int(SR * d), 40) * 0.3, 0.05)
    d = 1.2
    t = tt(d)
    x = sweep(120, 900, d, "saw") * (t / d) * 0.5 + bp(noise(d), 500, 6000) * (t / d) ** 2 * 0.5
    sfx("beam_charge", lp(x, 6000), 0.1)
    d = 0.8
    x = np.tanh((lp(sweep(900, 80, d, "saw"), 3000) * E(int(SR * d), 3) + lp(noise(d), 6000) * E(int(SR * d), 6) + thump(100, 35, d, 5)) * 2.0)
    sfx("beam_fire", x, 0.3)
    d = 0.9
    x = np.tanh((thump(90, 30, d, 5) * 1.3 + lp(noise(d), 2500) * E(int(SR * d), 6)) * 2.0)
    sfx("explosion", x, 0.35)
    d = 0.25
    sfx("dash", bp(noise(d), 600, 7000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2 + 0.25 * sweep(1500, 300, d, "saw") * E(int(SR * d), 10))
    d = 0.14
    sfx("jump", lp(sweep(200, 520, d, "square"), 2500) * E(int(SR * d), 16) * 0.5, 0.05)
    d = 0.16
    sfx("land", lp(noise(d), 500) * E(int(SR * d), 28) + thump(90, 50, d, 22) * 0.6, 0.03)
    d = 0.25
    sfx("block", bp(noise(d), 1500, 6000) * E(int(SR * d), 25) + square(600, tt(d)) * E(int(SR * d), 30) * 0.2, 0.1)
    d = 0.8
    x = np.zeros(int(SR * d))
    for k, m in enumerate([96, 103, 108]):
        place(x, bell(m, 0.6, 0.5), k * 0.03)
    place(x, hp(noise(0.05), 3000) * E(int(SR * 0.05), 60), 0.0)
    sfx("parry", x, 0.4)
    d = 0.3
    sfx("hurt", np.tanh(lp(sweep(300, 120, d, "saw"), 1500) * E(int(SR * d), 9) * 2 + lp(noise(d), 1200) * E(int(SR * d), 20)), 0.05)
    d = 0.7
    x = np.tanh((thump(140, 40, d, 7) + bp(noise(d), 400, 6000) * E(int(SR * d), 7) * 0.8) * 1.8)
    for k in range(4):
        place(x, bp(noise(0.05), 3000, 9000) * E(int(SR * 0.05), 50) * 0.5, 0.05 + k * 0.06)
    sfx("enemy_die", x, 0.25)
    d = 0.15
    sfx("enemy_shoot", lp(sweep(1200, 300, d, "square"), 4000) * E(int(SR * d), 20) * 0.5, 0.05)
    d = 0.2
    sfx("enemy_swipe", bp(noise(d), 1000, 5000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2, 0.05)
    d = 0.6
    sfx("slam", np.tanh((thump(100, 30, d, 6) * 1.4 + lp(noise(d), 1500) * E(int(SR * d), 9)) * 2.2), 0.3)
    d = 0.4
    sfx("windup", lp(sweep(300, 1400, d, "square"), 3000) * np.linspace(0.2, 1, int(SR * d)) * 0.3, 0.05)
    d = 0.6
    x = sweep(2000, 200, d, "sine") * E(int(SR * d), 5) * 0.5 + bp(noise(d), 2000, 8000) * E(int(SR * d), 8) * 0.3
    sfx("spawn", x, 0.3)
    d = 1.4
    t = tt(d)
    x = supersaw([57, 64, 69, 76], d, 5000, 0.8) * adsr(len(t), 0.01, 0.3, 0.6, 0.6)
    x += riser(0.5, 0.8)[: len(x)] if False else 0
    x += thump(80, 30, d, 3) * 0.8
    sfx("ult", np.tanh(x * 1.5), 0.4)
    d = 0.3
    sfx("callout", bp(noise(d), 2000, 10000) * np.sin(np.linspace(0, np.pi, int(SR * d))) * 0.6, 0.2)
    d = 0.9
    x = np.zeros(int(SR * d))
    for k, m in enumerate([100, 105, 108, 112]):
        place(x, bell(m, 0.7, 0.3), k * 0.05)
    x += hp(noise(d), 5000) * E(int(SR * d), 4) * 0.2
    sfx("freeze", x, 0.4)
    d = 0.3
    sfx("blink", sweep(400, 3000, d, "sine") * E(int(SR * d), 8) * 0.6 + bp(noise(d), 4000, 10000) * E(int(SR * d), 15) * 0.3, 0.2)
    d = 0.4
    sfx("orb", sweep(700, 1100, d, "sine") * E(int(SR * d), 7) * 0.5 + bell(88, d, 0.3)[: int(SR * d)], 0.2)
    d = 0.6
    sfx("meteor", bp(noise(d), 200, 3000) * (tt(d) / d) * 0.8 + sweep(800, 150, d, "saw") * 0.2, 0.2)
    d = 0.4
    x = np.zeros(int(SR * d))
    for k, m in enumerate([84, 88, 91]):
        place(x, bell(m, 0.3, 0.4), k * 0.05)
    sfx("pickup", x, 0.2)
    d = 1.0
    x = np.zeros(int(SR * d))
    place(x, square(440, tt(0.15)) * adsr(int(SR * 0.15), 0.005, 0.05, 0.7, 0.05) * 0.4, 0.0)
    place(x, square(660, tt(0.15)) * adsr(int(SR * 0.15), 0.005, 0.05, 0.7, 0.05) * 0.4, 0.18)
    place(x, square(880, tt(0.35)) * adsr(int(SR * 0.35), 0.005, 0.05, 0.7, 0.1) * 0.4, 0.36)
    sfx("wave", lp(x, 4000), 0.2)
    d = 2.2
    x = np.zeros(int(SR * d))
    for k, m in enumerate([69, 72, 76, 81, 84, 88]):
        place(x, bell(m, 1.4, 0.3), k * 0.07)
    place(x, supersaw([57, 64, 69, 73], 1.6, 4000, 0.6) * adsr(int(SR * 1.6), 0.02, 0.3, 0.7, 0.6), 0.45)
    sfx("clear", x, 0.4)
    sfx("ui_move", square(1100, tt(0.035)) * E(int(SR * 0.035), 70) * 0.4, 0.0)
    d = 0.2
    x = np.zeros(int(SR * d))
    place(x, square(900, tt(0.05)) * E(int(SR * 0.05), 40) * 0.4, 0)
    place(x, square(1350, tt(0.09)) * E(int(SR * 0.09), 30) * 0.4, 0.05)
    sfx("ui_select", x, 0.05)
    d = 0.2
    sfx("denied", lp(square(120, tt(d)) + square(127, tt(d)), 1200) * adsr(int(SR * d), 0.005, 0.05, 0.8, 0.05) * 0.3, 0.0)
    d = 0.9
    t = tt(d)
    sfx("boss_charge", lp(sweep(80, 600, d, "saw"), 3000) * (t / d) * 0.6 + bp(noise(d), 300, 4000) * (t / d) ** 2 * 0.4, 0.2)
    d = 1.6
    t = tt(d)
    x = np.tanh((lp(sweep(160, 50, d, "saw") + sweep(163, 52, d, "saw"), 1200) * adsr(len(t), 0.05, 0.3, 0.8, 0.6) + lp(noise(d), 800) * 0.4) * 2.5)
    sfx("boss_roar", x, 0.4)
    d = 2.4
    t = tt(d)
    x = np.tanh((lp(saw(110, t) + saw(111.5, t), 2500) * 0.6 + bp(noise(d), 1000, 6000) * 0.3) * 1.5) * adsr(len(t), 0.02, 0.1, 0.9, 0.3)
    sfx("laser", x, 0.2)
    d = 2.5
    t = tt(d)
    x = lp(noise(d), 600) * np.exp(-t * 1.5) + lp(noise(d), 200) * np.exp(-t * 0.8) * 0.8
    sfx("thunder", x, 0.5)
    print("  sfx: done")


def build_sfx_v2():
    """Punchier layered impacts + sounds for NOVA, JADE, style rank and perfect dodge."""
    E = env_exp

    def crack(d=0.03):
        return hp(noise(d), 2500) * E(int(SR * d), 90)

    def layered(sub_f0, sub_f1, sub_k, body_lo, body_hi, d, drive=2.2):
        x = thump(sub_f0, sub_f1, d, sub_k) * 1.1
        x += bp(noise(d), body_lo, body_hi) * E(int(SR * d), 22) * 0.9
        place(x, crack(), 0.0)
        return np.tanh(x * drive)

    sfx("punch", layered(170, 55, 16, 600, 4000, 0.22), 0.06)
    sfx("punch_heavy", layered(150, 38, 8, 400, 3500, 0.45, 2.8), 0.18)
    d = 0.24
    x = bp(noise(d), 2500, 10000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2 * 0.9
    place(x, crack(0.02) * 0.8, 0.02)
    x += sweep(4000, 1500, d, "saw") * E(int(SR * d), 18) * 0.25
    sfx("slash", x, 0.15)
    d = 0.4
    x = bp(noise(d), 1500, 10000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 1.5
    x += sweep(3000, 500, d, "saw") * E(int(SR * d), 7) * 0.4 + thump(140, 50, d, 10) * 0.6
    sfx("slash_heavy", np.tanh(x * 1.6), 0.25)
    d = 1.0
    x = thump(90, 28, d, 4.5) * 1.4 + lp(noise(d), 2500) * E(int(SR * d), 5) * 0.9
    place(x, crack(0.05), 0.0)
    sfx("explosion", np.tanh(x * 2.2), 0.4)
    d = 0.3
    t = tt(d)
    zap = np.sin(2 * np.pi * np.cumsum(900 + 1400 * np.exp(-t * 30)) / SR) * E(len(t), 14)
    sfx("block", zap * 0.6 + bp(noise(d), 2000, 9000) * E(len(t), 30) * 0.5 + thump(160, 80, d, 25) * 0.4, 0.2)
    d = 0.22
    sfx("swing", bp(noise(d), 700, 5000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2 * 0.8, 0.05)
    d = 0.32
    sfx("swing_heavy", bp(noise(d), 400, 4000) * np.sin(np.linspace(0, np.pi, int(SR * d))) ** 2 + sweep(600, 200, d, "sine") * 0.2, 0.08)
    d = 0.16
    sfx("pistol", np.tanh((thump(220, 90, d, 28) * 0.7 + bp(noise(d), 1500, 9000) * E(int(SR * d), 40)) * 2.5) * 0.9, 0.12)
    d = 0.6
    sfx("shotgun", np.tanh((thump(130, 40, d, 9) * 1.2 + bp(noise(d), 600, 7000) * E(int(SR * d), 12)) * 3.0), 0.3)
    d = 0.3
    sfx("throw", bp(noise(d), 800, 5000) * np.sin(np.linspace(0, np.pi, int(SR * d))) * 0.6 + bell(96, d, 0.3)[: int(SR * d)], 0.1)
    d = 0.9
    t = tt(d)
    w = np.zeros(len(t))
    nn = noise(d)
    seg = int(SR * 0.03)
    for i in range(0, len(t), seg):
        k = i / len(t)
        w[i:i + seg] = bp(nn[i:i + seg], 400 + 2500 * np.sin(k * np.pi), 900 + 5000 * np.sin(k * np.pi))
    sfx("wind", w * np.sin(np.linspace(0, np.pi, len(t))) * 1.2, 0.2)
    d = 2.0
    t = tt(d)
    tor = bp(noise(d), 200, 2500) * (0.6 + 0.4 * np.sin(2 * np.pi * 6 * t)) * adsr(len(t), 0.2, 0.3, 0.8, 0.6)
    sfx("tornado", tor + thump(70, 30, d, 2) * 0.5, 0.3)
    d = 0.2
    sfx("spear_hit", layered(200, 70, 20, 1500, 7000, d, 2.0), 0.08)
    d = 1.3
    t = tt(d)
    rev = bp(noise(d), 1500, 9000) * (t / d) ** 3
    x = rev[::-1].copy() * 0.6
    for k, m_ in enumerate([100, 107, 112]):
        place(x, bell(m_, 0.8, 0.35), 0.05 + k * 0.05)
    x += sweep(1200, 250, d, "sine") * E(len(t), 2.5) * 0.3
    sfx("perfect_dodge", x, 0.45)
    d = 0.5
    x = np.zeros(int(SR * d))
    for k, m_ in enumerate([84, 91, 96]):
        place(x, bell(m_, 0.35, 0.35), k * 0.045)
    sfx("rank_up", x, 0.25)
    print("  sfx v2: done")


if __name__ == "__main__":
    print("Generating ECHO ARENA audio...")
    build_music()
    build_sfx()
    build_sfx_v2()
    print("Done.")
