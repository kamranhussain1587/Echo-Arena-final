class_name Arena
extends Node3D
## Builds a whole neon arena from code (sky, reflective grid floor, force-field
## wall, pillars, an endless city skyline, weather, lights, volumetric fog),
## then runs the level: waves of robots or the Warden boss fight.
## With menu_mode = true it is just a slowly orbiting backdrop for menus.

const THEMES: Array[Dictionary] = [
	{   # NEON STREETS
		"top": Color(0.01, 0.005, 0.04), "horizon": Color(0.28, 0.04, 0.32), "glow": Color(1.0, 0.25, 0.65),
		"fog": Color(0.35, 0.12, 0.5), "a": Color(0.15, 0.85, 1.0), "b": Color(1.0, 0.2, 0.6),
		"floor": Color(0.025, 0.025, 0.04), "weather": "motes", "music": "battle", "sun": Color(0.6, 0.5, 1.0),
	},
	{   # ROOFTOPS
		"top": Color(0.01, 0.01, 0.03), "horizon": Color(0.1, 0.12, 0.3), "glow": Color(0.45, 0.4, 1.0),
		"fog": Color(0.25, 0.3, 0.55), "a": Color(0.55, 0.4, 1.0), "b": Color(0.2, 0.85, 1.0),
		"floor": Color(0.02, 0.025, 0.035), "weather": "rain", "music": "battle", "sun": Color(0.6, 0.7, 1.0),
	},
	{   # REACTOR CORE
		"top": Color(0.03, 0.005, 0.005), "horizon": Color(0.45, 0.1, 0.02), "glow": Color(1.0, 0.45, 0.1),
		"fog": Color(0.6, 0.22, 0.06), "a": Color(1.0, 0.5, 0.1), "b": Color(1.0, 0.15, 0.1),
		"floor": Color(0.035, 0.025, 0.02), "weather": "embers", "music": "battle", "sun": Color(1.0, 0.6, 0.3),
	},
	{   # THE WARDEN'S TOWER
		"top": Color(0.02, 0.0, 0.01), "horizon": Color(0.3, 0.02, 0.05), "glow": Color(1.0, 0.15, 0.25),
		"fog": Color(0.45, 0.08, 0.12), "a": Color(1.0, 0.18, 0.28), "b": Color(0.85, 0.9, 1.0),
		"floor": Color(0.03, 0.02, 0.025), "weather": "storm", "music": "boss1", "sun": Color(1.0, 0.5, 0.55),
	},
]
const ARENA_RADIUS := 23.0

var menu_mode := false
var theme_index := 0
var theme: Dictionary
var player: Player
var hud: HUD
var overlay: Overlay
var boss: Boss
var level_done := false

var _env: Environment
var _sun: DirectionalLight3D
var _orbit_cam: Camera3D
var _t := 0.0
var _lightning_t := 4.0
var _sky_mat: ShaderMaterial
var _spin_nodes: Array[Node3D] = []


func _ready() -> void:
	if not menu_mode:
		theme_index = int(Game.LEVELS[Game.current_level].theme)
	theme = THEMES[clampi(theme_index, 0, THEMES.size() - 1)]
	_build_environment()
	_build_floor()
	_build_wall()
	_build_pillars()
	_build_skyline()
	_build_set_piece()
	_build_weather()
	if menu_mode:
		_orbit_cam = Camera3D.new()
		_orbit_cam.fov = 70
		add_child(_orbit_cam)
		_orbit_cam.current = true
		for i in 4:
			var e := Enemy.new()
			e.setup(Enemy.Type.MINION if i < 3 else Enemy.Type.GUNNER)
			add_child(e)
			e.global_position = Vector3(cos(i * 1.6) * 6.0, 1.6 + i * 0.4, sin(i * 1.6) * 6.0)
		return
	_start_level()


func _process(delta: float) -> void:
	_t += delta
	for n in _spin_nodes:
		n.rotate_y(delta * float(n.get_meta("spin", 0.5)))
	if _orbit_cam != null:
		var a := _t * 0.08
		_orbit_cam.global_position = Vector3(cos(a) * 17.0, 4.5 + sin(_t * 0.2) * 1.0, sin(a) * 17.0)
		_orbit_cam.look_at(Vector3(0, 2.5, 0))
	if theme.weather == "rain" or theme.weather == "storm":
		_lightning_t -= delta
		if _lightning_t <= 0.0:
			_lightning_t = randf_range(4.0, 9.0)
			_lightning()


# =============================================================================
# World building
# =============================================================================

const SKY_SHADER := """
shader_type sky;
uniform vec3 top_color;
uniform vec3 horizon_color;
uniform vec3 glow_color;
uniform float flash = 0.0;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void sky() {
	float y = EYEDIR.y;
	vec3 col = mix(horizon_color, top_color, smoothstep(-0.1, 0.55, y));
	col += glow_color * pow(1.0 - clamp(abs(y), 0.0, 1.0), 10.0) * 1.6;
	vec2 uv = EYEDIR.xz / (abs(EYEDIR.y) + 0.25) * 70.0;
	float h = hash(floor(uv));
	float star = step(0.9965, h) * smoothstep(0.08, 0.45, y);
	col += vec3(star) * (0.7 + 0.3 * sin(TIME * 2.5 + h * 40.0)) * 1.5;
	vec3 moon_dir = normalize(vec3(0.45, 0.32, -0.83));
	float md = dot(EYEDIR, moon_dir);
	col += mix(glow_color, vec3(1.0), 0.6) * smoothstep(0.9978, 0.9988, md) * 4.0;
	col += glow_color * pow(max(md, 0.0), 300.0) * 1.5;
	col += vec3(0.7, 0.75, 1.0) * flash * (0.6 + 0.4 * y);
	COLOR = col;
}
"""

const FLOOR_SHADER := """
shader_type spatial;
uniform vec3 base_color;
uniform vec3 line_a;
uniform vec3 line_b;
varying vec3 wpos;
void vertex() { wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec2 gp = wpos.xz / 2.0;
	vec2 g = abs(fract(gp - 0.5) - 0.5) / fwidth(gp);
	float grid = 1.0 - min(min(g.x, g.y), 1.0);
	float r = length(wpos.xz);
	float rr = r / 5.0;
	float rings = 1.0 - min(abs(fract(rr - 0.5) - 0.5) / fwidth(rr), 1.0);
	float pulse = pow(0.5 + 0.5 * sin(r * 0.5 - TIME * 2.2), 4.0);
	float edge = smoothstep(21.8, 22.8, r) * (1.0 - smoothstep(23.2, 24.0, r));
	float hexes = step(0.97, fract(sin(dot(floor(gp), vec2(12.9898, 78.233))) * 43758.5453));
	ALBEDO = base_color;
	METALLIC = 0.85;
	ROUGHNESS = 0.08 + grid * 0.25;
	vec3 lines = mix(line_a, line_b, 0.5 + 0.5 * sin(r * 0.15 + TIME * 0.4));
	EMISSION = lines * (grid * 0.25 + rings * (0.15 + 1.6 * pulse) + edge * 3.0) + line_a * hexes * 0.35;
}
"""

const WALL_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, shadows_disabled;
uniform vec3 color;
void fragment() {
	float v = UV.y;
	float fade = pow(1.0 - v, 2.5);
	float lines = step(0.92, fract(UV.x * 80.0)) * 0.6 + step(0.95, fract(v * 12.0 - TIME * 0.8)) * 0.8;
	float a = fade * (0.18 + lines * 0.5);
	ALBEDO = color * 3.0 * a;
	ALPHA = clamp(a, 0.0, 1.0);
}
"""

const BUILDING_SHADER := """
shader_type spatial;
uniform vec3 window_a;
uniform vec3 window_b;
varying vec3 wpos;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void vertex() { wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz; }
void fragment() {
	vec3 wn = normalize((INV_VIEW_MATRIX * vec4(NORMAL, 0.0)).xyz);
	float u = abs(wn.x) > 0.5 ? wpos.z : wpos.x;
	vec2 c = vec2(u * 0.9, wpos.y * 0.7);
	vec2 cell = floor(c);
	vec2 f = fract(c);
	float win = step(0.2, f.x) * step(f.x, 0.8) * step(0.25, f.y) * step(f.y, 0.7);
	float lit = step(0.58, hash(cell + floor(wpos.xz * 0.02) * 17.0));
	vec3 wc = mix(window_a, window_b, step(0.8, hash(cell * 1.31)));
	ALBEDO = vec3(0.015, 0.015, 0.025);
	METALLIC = 0.6;
	ROUGHNESS = 0.35;
	float roof = step(0.5, wn.y);
	EMISSION = wc * win * lit * 1.6 * (1.0 - roof) * COLOR.r + window_b * roof * 0.05;
}
"""


func _build_environment() -> void:
	var high: bool = Game.settings.quality_high
	_env = Environment.new()
	_env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	_sky_mat = ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = SKY_SHADER
	_sky_mat.shader = sh
	_sky_mat.set_shader_parameter("top_color", theme.top)
	_sky_mat.set_shader_parameter("horizon_color", theme.horizon)
	_sky_mat.set_shader_parameter("glow_color", theme.glow)
	sky.sky_material = _sky_mat
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.ambient_light_color = Color(theme.fog).lerp(Color(0.5, 0.5, 0.6), 0.3)
	_env.ambient_light_energy = 0.5
	_env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	_env.tonemap_exposure = 0.95
	_env.tonemap_white = 6.0
	_env.glow_enabled = true
	_env.glow_intensity = 0.5
	_env.glow_strength = 0.95
	_env.glow_bloom = 0.015
	_env.glow_hdr_threshold = 1.05
	_env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
	for i in 7:
		_env.set_glow_level(i, 1.0 if i >= 1 and i <= 5 else 0.0)
	_env.fog_enabled = true
	_env.fog_light_color = theme.fog
	_env.fog_light_energy = 0.6
	_env.fog_density = 0.004
	_env.fog_sky_affect = 0.25
	_env.fog_height = -5.0
	_env.fog_height_density = 0.04
	if high:
		_env.volumetric_fog_enabled = true
		_env.volumetric_fog_density = 0.009
		_env.volumetric_fog_albedo = Color(theme.fog).lerp(Color.WHITE, 0.2)
		_env.volumetric_fog_emission = Color(theme.fog) * 0.015
		_env.volumetric_fog_anisotropy = 0.55
		_env.volumetric_fog_length = 80.0
		_env.ssr_enabled = true
		_env.ssr_max_steps = 56
		_env.ssr_fade_in = 0.1
		_env.ssr_fade_out = 2.5
		_env.ssao_enabled = true
		_env.ssao_intensity = 1.6
	_env.adjustment_enabled = true
	_env.adjustment_saturation = 1.2
	_env.adjustment_contrast = 1.06
	var we := WorldEnvironment.new()
	we.environment = _env
	add_child(we)

	_sun = DirectionalLight3D.new()
	_sun.light_color = theme.sun
	_sun.light_energy = 0.35
	_sun.rotation = Vector3(deg_to_rad(-40), deg_to_rad(30), 0)
	_sun.shadow_enabled = high
	_sun.light_volumetric_fog_energy = 0.3
	add_child(_sun)


func _build_floor() -> void:
	var floor_body := StaticBody3D.new()
	floor_body.collision_layer = 1
	add_child(floor_body)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = ARENA_RADIUS + 3.0
	shape.height = 1.0
	cs.shape = shape
	cs.position.y = -0.5
	floor_body.add_child(cs)
	var mi := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = ARENA_RADIUS + 3.0
	cyl.bottom_radius = ARENA_RADIUS + 1.0
	cyl.height = 1.6
	cyl.radial_segments = 96
	mi.mesh = cyl
	mi.position.y = -0.8
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = FLOOR_SHADER
	mat.shader = sh
	mat.set_shader_parameter("base_color", theme.floor)
	mat.set_shader_parameter("line_a", theme.a)
	mat.set_shader_parameter("line_b", theme.b)
	mi.material_override = mat
	add_child(mi)
	# Glowing underside rim so the platform reads as floating above the city.
	var rim := MeshInstance3D.new()
	var t := TorusMesh.new()
	t.inner_radius = ARENA_RADIUS + 2.6
	t.outer_radius = ARENA_RADIUS + 3.1
	t.rings = 96
	rim.mesh = t
	rim.material_override = Fx3D.glow_mat(theme.a, 3.0)
	rim.position.y = -0.05
	add_child(rim)
	# City streets far below.
	var ground := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(900, 900)
	ground.mesh = plane
	ground.position.y = -70.0
	var gmat := ShaderMaterial.new()
	var gsh := Shader.new()
	gsh.code = FLOOR_SHADER.replace("wpos.xz / 2.0", "wpos.xz / 24.0").replace("r / 5.0", "r / 60.0")
	gmat.shader = gsh
	gmat.set_shader_parameter("base_color", Color(0.01, 0.01, 0.02))
	gmat.set_shader_parameter("line_a", Color(theme.a) * 0.6)
	gmat.set_shader_parameter("line_b", Color(theme.b) * 0.6)
	ground.material_override = gmat
	add_child(ground)


func _build_wall() -> void:
	var segments := 36
	var wall := StaticBody3D.new()
	wall.collision_layer = 1
	add_child(wall)
	for i in segments:
		var a := TAU * float(i) / segments
		var cs := CollisionShape3D.new()
		var b := BoxShape3D.new()
		b.size = Vector3(TAU * (ARENA_RADIUS + 0.5) / segments + 0.6, 12.0, 1.0)
		cs.shape = b
		cs.position = Vector3(cos(a) * (ARENA_RADIUS + 0.5), 5.0, sin(a) * (ARENA_RADIUS + 0.5))
		cs.rotation.y = -a + PI * 0.5
		wall.add_child(cs)
	var field := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = ARENA_RADIUS + 0.4
	cyl.bottom_radius = ARENA_RADIUS + 0.4
	cyl.height = 5.0
	cyl.cap_top = false
	cyl.cap_bottom = false
	cyl.radial_segments = 96
	field.mesh = cyl
	field.position.y = 2.5
	var m := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = WALL_SHADER
	m.shader = sh
	m.set_shader_parameter("color", theme.a)
	field.material_override = m
	field.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(field)


func _build_pillars() -> void:
	var dark := Fx3D.neon_mat(Color(0.04, 0.04, 0.06), Color(0, 0, 0, 0), 0.0, 0.9, 0.25)
	for i in 6:
		var a := TAU * float(i) / 6.0
		var pos := Vector3(cos(a) * 15.0, 0, sin(a) * 15.0)
		var col: Color = theme.a if i % 2 == 0 else theme.b
		var body := StaticBody3D.new()
		body.collision_layer = 1
		add_child(body)
		body.position = pos
		var cs := CollisionShape3D.new()
		var b := BoxShape3D.new()
		b.size = Vector3(1.6, 9.0, 1.6)
		cs.shape = b
		cs.position.y = 4.5
		body.add_child(cs)
		_add_mesh(body, _boxm(Vector3(1.6, 9.0, 1.6)), dark, Vector3(0, 4.5, 0))
		_add_mesh(body, _boxm(Vector3(2.0, 0.5, 2.0)), dark, Vector3(0, 0.25, 0))
		_add_mesh(body, _boxm(Vector3(2.0, 0.4, 2.0)), dark, Vector3(0, 9.0, 0))
		for side in [Vector3(0.81, 0, 0), Vector3(-0.81, 0, 0), Vector3(0, 0, 0.81), Vector3(0, 0, -0.81)]:
			var strip := _boxm(Vector3(0.06 if side.x != 0.0 else 0.4, 7.0, 0.4 if side.x != 0.0 else 0.06))
			_add_mesh(body, strip, Fx3D.glow_mat(col, 1.8), side + Vector3(0, 4.6, 0))
		_add_mesh(body, _boxm(Vector3(2.05, 0.08, 2.05)), Fx3D.glow_mat(col, 2.5), Vector3(0, 8.8, 0))
		var l := OmniLight3D.new()
		l.light_color = col
		l.light_energy = 2.5
		l.omni_range = 14.0
		l.light_volumetric_fog_energy = 0.7
		l.position = Vector3(0, 7.5, 0)
		body.add_child(l)
		var ground_light := OmniLight3D.new()
		ground_light.light_color = col
		ground_light.light_energy = 1.0
		ground_light.light_volumetric_fog_energy = 0.2
		ground_light.omni_range = 6.0
		ground_light.position = Vector3(0, 0.8, 0)
		body.add_child(ground_light)


func _build_skyline() -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	var count := 260
	mm.instance_count = count
	var box := BoxMesh.new()
	box.size = Vector3(1, 1, 1)
	mm.mesh = box
	var rng := RandomNumberGenerator.new()
	rng.seed = 1000 + theme_index
	for i in count:
		var a := rng.randf() * TAU
		var r := rng.randf_range(45.0, 190.0)
		var w := rng.randf_range(7.0, 18.0)
		var d := rng.randf_range(7.0, 18.0)
		var h := rng.randf_range(30.0, 130.0) * (1.0 - r / 400.0)
		var base_y := -70.0
		var xf := Transform3D(Basis().scaled(Vector3(w, h, d)).rotated(Vector3.UP, rng.randf() * PI), Vector3(cos(a) * r, base_y + h * 0.5, sin(a) * r))
		mm.set_instance_transform(i, xf)
		mm.set_instance_color(i, Color(rng.randf_range(0.5, 1.2), 1, 1))
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	var mat := ShaderMaterial.new()
	var sh := Shader.new()
	sh.code = BUILDING_SHADER
	mat.shader = sh
	mat.set_shader_parameter("window_a", Color(theme.a).lerp(Color(1, 0.9, 0.7), 0.3))
	mat.set_shader_parameter("window_b", theme.b)
	mmi.material_override = mat
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)
	# Flying traffic: streaks of light crossing the city.
	for lane in 3:
		var p := GPUParticles3D.new()
		p.amount = 40
		p.lifetime = 10.0
		p.preprocess = 10.0
		p.visibility_aabb = AABB(Vector3(-300, -60, -300), Vector3(600, 120, 600))
		var pm := ParticleProcessMaterial.new()
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		pm.emission_box_extents = Vector3(5, 3, 150)
		pm.direction = Vector3(0, 0, 1) if lane % 2 == 0 else Vector3(0, 0, -1)
		pm.spread = 0.0
		pm.gravity = Vector3.ZERO
		pm.initial_velocity_min = 25.0
		pm.initial_velocity_max = 40.0
		p.process_material = pm
		var q := QuadMesh.new()
		q.size = Vector2(0.5, 2.5)
		var qm := Fx3D.glow_mat(theme.b if lane == 1 else Color(1, 0.85, 0.6), 4.0)
		qm.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		q.material = qm
		p.draw_pass_1 = q
		p.position = Vector3(-60.0 + lane * 55.0, 8.0 + lane * 6.0, 0)
		p.rotation.y = 0.4 * lane
		add_child(p)


func _build_set_piece() -> void:
	match theme_index:
		0:
			_holo_sign(Vector3(-34, 14, -30), "NEO-KAIRO", theme.b, 0.6)
			_holo_sign(Vector3(36, 18, -20), "ARENA", theme.a, -0.9)
			_holo_sign(Vector3(10, 24, 42), "ECHO", Color(1, 0.85, 0.3), PI)
		1:
			_holo_sign(Vector3(-30, 10, 34), "THE WARDEN IS WATCHING", theme.a, 2.4)
			_holo_sign(Vector3(38, 12, 10), "NO EXIT", theme.b, -1.6)
		2:
			_reactor(Vector3(0, 0, -48))
		3:
			_warden_eye(Vector3(0, 30, -70))
			_holo_sign(Vector3(-40, 20, -20), "SUBMIT", theme.a, 1.0)


func _holo_sign(pos: Vector3, text: String, col: Color, yaw: float) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 256
	l.pixel_size = 0.02
	l.modulate = Color(col.r * 1.5, col.g * 1.5, col.b * 1.5)
	l.outline_size = 0
	l.shaded = false
	l.double_sided = true
	l.no_depth_test = false
	if ResourceLoader.exists("res://fonts/Orbitron.ttf"):
		var fv := FontVariation.new()
		fv.base_font = load("res://fonts/Orbitron.ttf")
		fv.variation_opentype = {"wght": 900}
		l.font = fv
	add_child(l)
	l.global_position = pos
	l.look_at(Vector3(0, pos.y, 0), Vector3.UP)
	l.rotate_y(PI)
	var light := OmniLight3D.new()
	light.light_color = col
	light.light_energy = 4.0
	light.omni_range = 20.0
	l.add_child(light)
	light.position = Vector3(0, 0, 2)


func _reactor(pos: Vector3) -> void:
	var root := Node3D.new()
	add_child(root)
	root.position = pos
	var dark := Fx3D.neon_mat(Color(0.05, 0.04, 0.04), Color(0, 0, 0, 0), 0.0, 0.9, 0.3)
	_add_mesh(root, _cylm(7.0, 8.0, 5.0), dark, Vector3(0, -30, 0))
	_add_mesh(root, _cylm(4.0, 70.0, 4.0), dark, Vector3(0, 5, 0))
	_add_mesh(root, _cylm(1.6, 140.0, 1.6), Fx3D.glow_mat(theme.a, 4.0, 0.9), Vector3(0, 40, 0))
	for i in 4:
		var holder := Node3D.new()
		holder.position = Vector3(0, -5.0 + i * 9.0, 0)
		holder.set_meta("spin", 0.3 + i * 0.25 * (1 if i % 2 == 0 else -1))
		root.add_child(holder)
		var t := TorusMesh.new()
		t.inner_radius = 7.0 + i * 1.5
		t.outer_radius = 7.6 + i * 1.5
		var tm := _add_mesh(holder, t, Fx3D.glow_mat(theme.a if i % 2 == 0 else theme.b, 3.0), Vector3.ZERO)
		tm.rotation.x = 0.25 * (i - 1.5)
		_spin_nodes.append(holder)
	var l := OmniLight3D.new()
	l.light_color = theme.a
	l.light_energy = 12.0
	l.omni_range = 60.0
	l.light_volumetric_fog_energy = 2.0
	l.position = Vector3(0, 10, 10)
	root.add_child(l)


func _warden_eye(pos: Vector3) -> void:
	var root := Node3D.new()
	add_child(root)
	root.position = pos
	root.look_at(Vector3(0, 5, 0), Vector3.UP)
	var s := SphereMesh.new()
	s.radius = 5.0
	s.height = 10.0
	_add_mesh(root, s, Fx3D.glow_mat(theme.a, 3.0, 0.9), Vector3.ZERO)
	var p := SphereMesh.new()
	p.radius = 2.0
	p.height = 4.0
	_add_mesh(root, p, Fx3D.glow_mat(Color.WHITE, 5.0), Vector3(0, 0, -4.0))
	for i in 3:
		var holder := Node3D.new()
		holder.set_meta("spin", 0.15 * (i + 1) * (1 if i % 2 == 0 else -1))
		root.add_child(holder)
		var t := TorusMesh.new()
		t.inner_radius = 8.0 + i * 3.0
		t.outer_radius = 8.4 + i * 3.0
		var tm := _add_mesh(holder, t, Fx3D.glow_mat(theme.a, 3.0, 0.8), Vector3.ZERO)
		tm.rotation.x = PI * 0.5
		_spin_nodes.append(holder)
	var l := OmniLight3D.new()
	l.light_color = theme.a
	l.light_energy = 10.0
	l.omni_range = 90.0
	l.light_volumetric_fog_energy = 2.5
	root.add_child(l)


func _build_weather() -> void:
	match theme.weather:
		"rain", "storm":
			_rain()
			_motes(Color(theme.b), 80)
		"embers":
			_embers()
		_:
			_motes(Color(theme.a), 220)


func _particles_base(amount: int, lifetime: float, extents: Vector3, pos: Vector3) -> GPUParticles3D:
	var p := GPUParticles3D.new()
	p.amount = amount
	p.lifetime = lifetime
	p.preprocess = lifetime
	p.visibility_aabb = AABB(-extents - Vector3(5, 20, 5), extents * 2.0 + Vector3(10, 40, 10))
	p.position = pos
	add_child(p)
	return p


func _rain() -> void:
	var p := _particles_base(2500, 0.9, Vector3(30, 1, 30), Vector3(0, 26, 0))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(30, 1, 30)
	pm.direction = Vector3(0.1, -1, 0)
	pm.spread = 2.0
	pm.gravity = Vector3.ZERO
	pm.initial_velocity_min = 30.0
	pm.initial_velocity_max = 36.0
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.025, 0.9)
	var m := Fx3D.glow_mat(Color(0.6, 0.75, 1.0), 1.2, 0.5)
	m.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	q.material = m
	p.draw_pass_1 = q


func _motes(col: Color, amount: int) -> void:
	var p := _particles_base(amount, 12.0, Vector3(24, 6, 24), Vector3(0, 6, 0))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(24, 6, 24)
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 180.0
	pm.gravity = Vector3(0, 0.05, 0)
	pm.initial_velocity_min = 0.1
	pm.initial_velocity_max = 0.5
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.5
	var curve := Curve.new()
	curve.add_point(Vector2(0, 0))
	curve.add_point(Vector2(0.5, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.06, 0.06)
	var m := Fx3D.glow_mat(col, 4.0, 0.8)
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = m
	p.draw_pass_1 = q


func _embers() -> void:
	var p := _particles_base(500, 7.0, Vector3(26, 1, 26), Vector3(0, -1, 0))
	var pm := ParticleProcessMaterial.new()
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(26, 1, 26)
	pm.direction = Vector3(0, 1, 0)
	pm.spread = 15.0
	pm.gravity = Vector3(0, 0.4, 0)
	pm.initial_velocity_min = 1.0
	pm.initial_velocity_max = 3.0
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 1.5
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(0.08, 0.08)
	var m := Fx3D.glow_mat(Color(1.0, 0.5, 0.15), 6.0)
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = m
	p.draw_pass_1 = q


func _lightning() -> void:
	Audio.play("thunder", -6.0, 0.2)
	var tw := create_tween()
	tw.tween_method(func(v: float) -> void: _sky_mat.set_shader_parameter("flash", v), 1.0, 0.0, 0.5)
	var old := _sun.light_energy
	_sun.light_energy = 3.0
	var tw2 := create_tween()
	tw2.tween_property(_sun, "light_energy", old, 0.4)


func _add_mesh(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _boxm(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func _cylm(r_bottom: float, h: float, r_top: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.bottom_radius = r_bottom
	c.top_radius = r_top
	c.height = h
	c.radial_segments = 32
	return c


# =============================================================================
# Gameplay
# =============================================================================

func _start_level() -> void:
	player = Player.new()
	add_child(player)
	player.global_position = Vector3(0, 0.1, 18)
	overlay = Overlay.new()
	add_child(overlay)
	hud = HUD.new()
	add_child(hud)
	hud.setup(self, player)
	player.hud = hud
	player.overlay = overlay
	player.died.connect(_on_player_died)
	var level: Dictionary = Game.LEVELS[Game.current_level]
	Audio.play_music(theme.music)
	if level.get("boss", false):
		_run_boss()
	else:
		_run_waves(level.waves)


func spawn_enemy(type: int, pos: Vector3) -> Enemy:
	var e := Enemy.new()
	e.setup(type)
	add_child(e)
	e.global_position = pos
	Fx3D.ring(self, Vector3(pos.x, 0.08, pos.z), Color(1, 0.2, 0.35), 2.2, 0.5, 0.15)
	Fx3D.sparks(self, pos, Color(1, 0.3, 0.4), 16, 5.0, 0.06, 0.5, 4.0)
	Fx3D.flash_light(self, pos, Color(1, 0.2, 0.3), 5.0, 6.0, 0.5)
	Audio.play("spawn", -12.0, 0.1)
	return e


func _spawn_point() -> Vector3:
	for attempt in 12:
		var a := randf() * TAU
		var r := randf_range(9.0, 19.0)
		var p := Vector3(cos(a) * r, 1.4, sin(a) * r)
		if player == null or p.distance_to(player.global_position) > 9.0:
			return p
	return Vector3(0, 1.4, -15)


func alive_enemies() -> int:
	var n := 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if not e.dead:
			n += 1
	return n


func _run_waves(waves: Array) -> void:
	await get_tree().create_timer(1.2, false).timeout
	hud.announce(Game.LEVELS[Game.current_level].name, "STAGE %d" % (Game.current_level + 1))
	await get_tree().create_timer(2.4, false).timeout
	for wi in waves.size():
		if not is_inside_tree() or not player.alive:
			return
		hud.announce("WAVE %d / %d" % [wi + 1, waves.size()], "")
		Audio.play("wave", -4.0)
		await get_tree().create_timer(1.2, false).timeout
		var wave: Dictionary = waves[wi]
		var list := []
		for key in wave.keys():
			var t: int = {"minion": Enemy.Type.MINION, "gunner": Enemy.Type.GUNNER, "shield": Enemy.Type.SHIELD}[key]
			for i in int(wave[key]):
				list.append(t)
		list.shuffle()
		for t in list:
			if not is_inside_tree():
				return
			spawn_enemy(t, _spawn_point())
			await get_tree().create_timer(0.3, false).timeout
		while is_inside_tree() and alive_enemies() > 0:
			await get_tree().create_timer(0.25, false).timeout
		if not is_inside_tree() or not player.alive:
			return
	_level_clear()


func _run_boss() -> void:
	await get_tree().create_timer(1.0, false).timeout
	hud.announce("THE WARDEN", "FINAL BATTLE")
	Audio.play("boss_roar", 0.0)
	await get_tree().create_timer(1.6, false).timeout
	if not is_inside_tree():
		return
	boss = Boss.new()
	add_child(boss)
	boss.global_position = Vector3(0, 0.1, -9)
	Fx3D.explosion(self, Vector3(0, 3, -9), Color(1, 0.2, 0.3), 6.0)
	player.add_shake(0.6)
	hud.show_boss_bar(true)
	boss.health_changed.connect(hud.set_boss_health)
	boss.stage_changed.connect(_on_boss_stage)
	boss.request_spawn.connect(_on_boss_spawn)
	boss.defeated.connect(_on_boss_defeated)


func _on_boss_spawn(type: int, count: int) -> void:
	for i in count:
		spawn_enemy(type, _spawn_point())


func _on_boss_stage(stage: int) -> void:
	Audio.play_music("boss2", 0.6)
	hud.announce("STAGE 2", "THE CORE AWAKENS")


func _on_boss_defeated() -> void:
	hud.show_boss_bar(false)
	for e in get_tree().get_nodes_in_group("enemies"):
		if e.has_method("take_hit"):
			e.take_hit(9999.0, Vector3.UP, true, e.global_position)
	_level_clear(true)


func _level_clear(final := false) -> void:
	if level_done:
		return
	level_done = true
	player.invuln = 999.0
	Game.slowmo(0.3, 1.4)
	Audio.play("clear", 0.0)
	hud.announce("WARDEN DEFEATED" if final else "STAGE CLEAR", "K.O." if final else "")
	await get_tree().create_timer(3.2, true, false, true).timeout
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Game.level_complete()


func _on_player_died() -> void:
	await get_tree().create_timer(1.8, true, false, true).timeout
	if is_inside_tree():
		hud.show_game_over()
