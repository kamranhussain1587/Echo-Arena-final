class_name Fighters
extends RefCounted
## The four playable fighters (all original characters).

enum Id { VOLT, KAGE, RIOT, HEX, NOVA, JADE }

const COUNT := 6
const NAMES: Array[String] = ["VOLT", "KAGE", "RIOT", "HEX", "NOVA", "JADE"]
const STYLES: Array[String] = ["ENERGY", "SWORD", "FISTS & KICKS", "MAGIC", "GUNSLINGER", "WIND SPEAR"]
const COLORS: Array[Color] = [
	Color(0.2, 0.9, 1.0),    # Volt - electric cyan
	Color(1.0, 0.18, 0.32),  # Kage - crimson
	Color(1.0, 0.55, 0.12),  # Riot - blazing orange
	Color(0.68, 0.38, 1.0),  # Hex - arcane violet
	Color(1.0, 0.9, 0.25),   # Nova - sunlight gold
	Color(0.25, 1.0, 0.55),  # Jade - emerald wind
]
const BLURBS: Array[String] = [
	"Living storm. Fires rapid energy bolts and charges a beam that pierces everything in its path.",
	"Silent blade. Fast sword combos, a dash that cuts through crowds, and an ultimate that stops time.",
	"Street legend. Punch-punch-kick combos, launcher uppercuts and a meteor dive that shakes the ground.",
	"Arcane prodigy. Homing orbs, freezing sigils, short-range blinks and a sky full of meteors.",
	"Twin-pistol sharpshooter. Rapid fire, a point-blank scatter blast, stun grenades and a lock-on barrage.",
	"Wind-spear dancer. Long-reach combos, a piercing javelin, a cyclone that drags robots in, and a roaming tornado.",
]
## [primary, Q, E, F]
const MOVES: Array = [
	["Energy Bolts", "Nova Lance (hold)", "Pulse Nova", "STARFALL"],
	["Blade Combo", "Rift Dash", "Whirlwind", "THOUSAND CUTS"],
	["Combo Strikes", "Meteor Kick", "Rising Uppercut", "RUSH MODE"],
	["Arcane Orbs", "Frost Sigil", "Blink", "METEOR RAIN"],
	["Twin Pistols", "Scatter Blast", "Flash Grenade", "SOLAR BARRAGE"],
	["Spear Combo", "Gale Javelin", "Cyclone Pull", "TEMPEST"],
]
const KIT_SCRIPTS: Array[String] = [
	"res://player/kits/volt.gd",
	"res://player/kits/kage.gd",
	"res://player/kits/riot.gd",
	"res://player/kits/hex.gd",
	"res://player/kits/nova.gd",
	"res://player/kits/jade.gd",
]
## Story line each fighter says before the reactor level.
const RETORTS: Array[String] = [
	"Then I'll short it out.",
	"Then I'll cut straight through it.",
	"Then I'll punch a hole in it.",
	"Then I'll freeze it solid.",
	"Then I'll shoot the lights out.",
	"Then I'll blow it away.",
]


static func clamp_id(id: int) -> int:
	return clampi(id, 0, COUNT - 1)


static func color(id: int) -> Color:
	return COLORS[clamp_id(id)]
