extends Kit
## KAGE - sword. 3-hit blade combo, Rift Dash, Whirlwind, Thousand Cuts.

var _sword: Node3D
var _combo := 0
var _combo_t := 0.0
var _dash_from := Vector3.ZERO
var _dashing := false
var _cut_t := 0.0
var _cut_targets: Array = []
var _cuts_done := false

const SWINGS := [
	{"rot": Vector3(-0.3, 0.9, -1.2), "roll": -20.0, "flip": false},
	{"rot": Vector3(-0.3, -0.9, 1.2), "roll": 200.0, "flip": true},
	{"rot": Vector3(-1.5, 0.0, 0.0), "roll": 90.0, "flip": false},
]


func build_viewmodel() -> void:
	q_cd_max = 4.5
	e_cd_max = 6.0
	_sword = Node3D.new()
	_sword.position = Vector3(0.32, -0.34, -0.55)
	_sword.rotation = Vector3(0.5, -0.25, -0.35)
	vm.add_child(_sword)
	var dark := Fx3D.neon_mat(Color(0.05, 0.05, 0.07), Color(0, 0, 0, 0), 0.0, 0.5, 0.4)
	var steel := Fx3D.neon_mat(Color(0.75, 0.78, 0.85), Color(0, 0, 0, 0), 0.0, 1.0, 0.12)
	make_mesh(cyl(0.025, 0.26), dark, Vector3(0, -0.1, 0), _sword)                       # grip
	make_mesh(box(Vector3(0.12, 0.02, 0.07)), Fx3D.neon_mat(Color(0.2, 0.05, 0.08), color, 2.0), Vector3(0, 0.04, 0), _sword)  # guard
	make_mesh(box(Vector3(0.035, 1.05, 0.012)), steel, Vector3(0, 0.58, 0), _sword)      # blade
	make_mesh(box(Vector3(0.008, 1.02, 0.014)), Fx3D.glow_mat(color, 2.2), Vector3(0.02, 0.58, 0), _sword)  # glowing edge
	make_mesh(box(Vector3(0.03, 0.06, 0.013)), steel, Vector3(0.004, 1.12, 0), _sword, Vector3(0, 0, 0.6))  # tip
	hand_light(_sword, 0.8).position = Vector3(0, 0.6, 0)


func process_kit(delta: float) -> void:
	_combo_t -= delta
	if _combo_t <= 0.0:
		_combo = 0
	if _dashing and not player.is_dashing():
		_dashing = false
		var to := player.global_position + Vector3(0, 1.0, 0)
		player.line_damage(_dash_from, to, 1.8, 42.0, true)
		Fx3D.beam(world(), _dash_from, to, color, 0.08, 0.5)
		Fx3D.sparks(world(), to, color, 30, 8.0, 0.07)
	if _cut_t > 0.0:
		_cut_t -= delta
		if randf() < 0.6:
			for e in _cut_targets:
				if is_instance_valid(e) and not e.dead and randf() < 0.4:
					var p: Vector3 = e.aim_point() + Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * e.hit_radius
					Fx3D.sparks(world(), p, color, 6, 6.0, 0.05, 0.25, 0.0)
					Fx3D.ring(world(), p, Color.WHITE, e.hit_radius * 1.5, 0.15, 0.03, false)
		if _cut_t <= 0.0 and not _cuts_done:
			_finish_cuts()


func primary(held: bool, just: bool) -> void:
	if primary_cd > 0.0 or not (just or held):
		return
	primary_cd = 0.28
	var s: Dictionary = SWINGS[_combo]
	var heavy := _combo == 2
	_swing_anim(s.rot)
	Fx3D.slash(player.cam, color, s.roll, 2.0 if not heavy else 2.4, 0.2, s.flip)
	var hits := player.melee(3.4, 150.0, 30.0 if heavy else 16.0, heavy, 7.0 if heavy else 2.5)
	Audio.play("swing_heavy" if heavy else "swing", -7.0, 0.1)
	if hits > 0:
		Audio.play("slash_heavy" if heavy else "slash", -3.0, 0.08)
	if heavy:
		player.velocity += Vector3(player.aim_dir().x, 0, player.aim_dir().z).normalized() * 6.0
	_combo = (_combo + 1) % 3
	_combo_t = 0.8


func _swing_anim(target_rot: Vector3) -> void:
	var base := Vector3(0.5, -0.25, -0.35)
	var tw := _sword.create_tween()
	tw.tween_property(_sword, "rotation", base + target_rot, 0.07).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(_sword, "rotation", base, 0.18).set_trans(Tween.TRANS_QUAD)


func skill1_press() -> void:
	if q_cd > 0.0:
		cooldown_denied()
		return
	q_cd = q_cd_max
	_dash_from = player.global_position + Vector3(0, 1.0, 0)
	var dir := Vector3(player.aim_dir().x, 0, player.aim_dir().z).normalized()
	player.start_dash(dir, 55.0, 0.17)
	_dashing = true
	_swing_anim(Vector3(-0.3, 1.2, -1.4))
	Fx3D.slash(player.cam, color, 0.0, 2.6, 0.25)
	Audio.play("slash_heavy", -2.0)
	callout("RIFT DASH!")


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var c := player.global_position + Vector3(0, 1.0, 0)
	player.area_damage(c, 4.4, 32.0, true, 10.0)
	Fx3D.ring(world(), player.global_position + Vector3(0, 1.0, 0), color, 5.0, 0.35, 0.05)
	Fx3D.ring(world(), player.global_position + Vector3(0, 0.6, 0), Color.WHITE, 4.0, 0.3, 0.03)
	Fx3D.slash(player.cam, color, 0.0, 2.6, 0.3)
	Fx3D.slash(player.cam, color, 180.0, 2.6, 0.3, true)
	var tw := _sword.create_tween()
	tw.tween_property(_sword, "rotation:y", _sword.rotation.y + TAU, 0.3)
	player.add_shake(0.3)
	Audio.play("slash_heavy", 0.0)
	callout("WHIRLWIND!")


func ultimate() -> void:
	start_ult(2.0, "THOUSAND CUTS!!!")
	_cut_targets = []
	for e in player.enemies():
		if e.global_position.distance_to(player.global_position) < 30.0:
			e.freeze(2.2)
			_cut_targets.append(e)
	_cut_t = 1.6
	_cuts_done = false
	if player.overlay != null:
		player.overlay.time_stop(1.6)
	var tw := _sword.create_tween()
	tw.tween_property(_sword, "rotation", Vector3(0.5, -0.25, -0.35) + Vector3(-0.2, 1.5, -1.5), 0.15)
	tw.tween_interval(1.3)
	tw.tween_property(_sword, "rotation", Vector3(0.5, -0.25, -0.35), 0.2)


func _finish_cuts() -> void:
	_cuts_done = true
	Audio.play("sheathe", 0.0)
	Game.flash_white(0.5)
	player.add_shake(0.6)
	for e in _cut_targets:
		if is_instance_valid(e) and not e.dead:
			var dealt: float = e.take_hit(130.0 * player.damage_mult, Vector3.UP, true, e.aim_point())
			player.register_hit(e, dealt, e.aim_point(), true)
			Fx3D.explosion(world(), e.aim_point(), color, 1.6)
	_cut_targets = []
