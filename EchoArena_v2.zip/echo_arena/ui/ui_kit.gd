class_name UIKit
extends RefCounted
## Fonts, colours and widget styles shared by every screen.

const TITLE_FONT := "res://fonts/Orbitron.ttf"
const MONO_FONT := "res://fonts/ShareTechMono.ttf"
const TEXT := Color(0.9, 0.93, 1.0)
const DIM := Color(0.55, 0.6, 0.75)
const PANEL := Color(0.03, 0.03, 0.07, 0.82)
const HOT := Color(1.0, 0.25, 0.45)
const CYAN := Color(0.25, 0.95, 1.0)
const GOLD := Color(1.0, 0.82, 0.3)

static var _fonts := {}


static func title_font(weight := 900) -> Font:
	var key := "t%d" % weight
	if not _fonts.has(key):
		var f: Font = ThemeDB.fallback_font
		if ResourceLoader.exists(TITLE_FONT):
			var fv := FontVariation.new()
			fv.base_font = load(TITLE_FONT)
			fv.variation_opentype = {"wght": weight}
			f = fv
		_fonts[key] = f
	return _fonts[key]


static func mono_font() -> Font:
	if not _fonts.has("m"):
		_fonts["m"] = load(MONO_FONT) if ResourceLoader.exists(MONO_FONT) else ThemeDB.fallback_font
	return _fonts["m"]


static func clear_cache() -> void:
	_fonts.clear()


static func label(text: String, size: int, color := TEXT, title := false, glow := Color(0, 0, 0, 0)) -> Label:
	var l := Label.new()
	l.text = text
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_override("font", title_font() if title else mono_font())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if glow.a > 0.0:
		l.add_theme_color_override("font_shadow_color", glow)
		l.add_theme_constant_override("shadow_offset_x", 0)
		l.add_theme_constant_override("shadow_offset_y", 0)
		l.add_theme_constant_override("shadow_outline_size", maxi(6, size / 4))
	return l


static func style(bg: Color, border: Color, width := 2, radius := 3) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(width)
	s.set_corner_radius_all(radius)
	s.content_margin_left = 20
	s.content_margin_right = 20
	s.content_margin_top = 10
	s.content_margin_bottom = 10
	return s


static func theme() -> Theme:
	var t := Theme.new()
	t.default_font = mono_font()
	t.default_font_size = 20
	var normal := style(Color(0.05, 0.04, 0.1, 0.85), Color(HOT, 0.5), 2)
	var hover := style(Color(0.18, 0.04, 0.12, 0.95), HOT, 2)
	hover.shadow_color = Color(HOT, 0.45)
	hover.shadow_size = 14
	var pressed := style(Color(0.35, 0.05, 0.18, 1.0), Color.WHITE, 2)
	t.set_stylebox("normal", "Button", normal)
	t.set_stylebox("hover", "Button", hover)
	t.set_stylebox("focus", "Button", hover)
	t.set_stylebox("pressed", "Button", pressed)
	t.set_font("font", "Button", title_font(800))
	t.set_font_size("font_size", "Button", 22)
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_focus_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", GOLD)
	return t


static func button(parent: Node, text: String, callback: Callable, width := 320.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(width, 54)
	b.pressed.connect(func() -> void:
		Audio.play("ui_select", -4.0)
		callback.call())
	b.mouse_entered.connect(b.grab_focus)
	b.focus_entered.connect(func() -> void: Audio.play("ui_move", -12.0))
	parent.add_child(b)
	return b


## Procedural emblem for each fighter (used on select screen and HUD).
static func draw_emblem(ci: CanvasItem, center: Vector2, r: float, id: int, alpha := 1.0) -> void:
	var c := Fighters.color(id)
	c.a = alpha
	ci.draw_circle(center, r, Color(c, 0.12 * alpha))
	ci.draw_arc(center, r, 0, TAU, 48, c, 3.0)
	ci.draw_arc(center, r * 0.82, 0, TAU, 48, Color(c, 0.4 * alpha), 1.5)
	var s := r / 40.0
	match id:
		0:
			var bolt := PackedVector2Array([Vector2(6, -30), Vector2(-14, 4), Vector2(0, 4), Vector2(-6, 30), Vector2(16, -6), Vector2(2, -6)])
			for i in bolt.size():
				bolt[i] = center + bolt[i] * s
			ci.draw_colored_polygon(bolt, c)
		1:
			ci.draw_line(center + Vector2(-22, 22) * s, center + Vector2(22, -22) * s, c, 6.0 * s)
			ci.draw_line(center + Vector2(-20, 6) * s, center + Vector2(-6, 20) * s, c, 6.0 * s)
			ci.draw_line(center + Vector2(-26, 26) * s, center + Vector2(-18, 18) * s, Color.WHITE * Color(1, 1, 1, alpha), 5.0 * s)
		2:
			ci.draw_rect(Rect2(center + Vector2(-18, -10) * s, Vector2(36, 28) * s), c)
			for k in 4:
				ci.draw_rect(Rect2(center + Vector2(-18 + k * 9.5, -20) * s, Vector2(8, 12) * s), c)
			ci.draw_rect(Rect2(center + Vector2(-26, -4) * s, Vector2(9, 16) * s), c)
		3:
			for k in 2:
				var pts := PackedVector2Array()
				for j in 3:
					var a := -PI * 0.5 + TAU * j / 3.0 + k * PI
					pts.append(center + Vector2(cos(a), sin(a)) * 26.0 * s)
				pts.append(pts[0])
				ci.draw_polyline(pts, c, 3.0 * s)
			ci.draw_circle(center, 6.0 * s, c)
		4:
			ci.draw_circle(center, 11.0 * s, c)
			for k in 8:
				var ang := TAU * k / 8.0
				ci.draw_line(center + Vector2(cos(ang), sin(ang)) * 16.0 * s, center + Vector2(cos(ang), sin(ang)) * (27.0 if k % 2 == 0 else 22.0) * s, c, 4.0 * s)
		5:
			ci.draw_line(center + Vector2(-24, 24) * s, center + Vector2(20, -20) * s, c, 4.0 * s)
			var tip := PackedVector2Array([center + Vector2(28, -28) * s, center + Vector2(14, -20) * s, center + Vector2(20, -14) * s])
			ci.draw_colored_polygon(tip, c)
			ci.draw_arc(center, 18.0 * s, PI * 0.1, PI * 1.1, 20, Color(c, 0.8 * alpha), 2.5 * s)
			ci.draw_arc(center, 25.0 * s, PI * 1.2, PI * 1.9, 16, Color(c, 0.6 * alpha), 2.0 * s)
