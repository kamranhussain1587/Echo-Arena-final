extends Node
## Audio (autoload): music with crossfades + pooled sound effects.
## Missing files are skipped silently.

const VOICES := 20

var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _current := ""
var _sfx: Array[AudioStreamPlayer] = []
var _cache := {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_music_a = AudioStreamPlayer.new()
	_music_b = AudioStreamPlayer.new()
	for p in [_music_a, _music_b]:
		p.volume_db = -60.0
		add_child(p)
	for i in VOICES:
		var s := AudioStreamPlayer.new()
		add_child(s)
		_sfx.append(s)


func play_music(track: String, fade := 1.2, volume_db := -4.0) -> void:
	if track == _current:
		return
	_current = track
	var stream := _load("res://audio/music/%s" % track)
	var old := _music_a
	var new := _music_b
	_music_a = new
	_music_b = old
	if stream is AudioStreamOggVorbis:
		(stream as AudioStreamOggVorbis).loop = true
	new.stream = stream
	new.pitch_scale = 1.0
	if stream != null:
		new.volume_db = -50.0
		new.play()
	var tw := create_tween().set_parallel(true)
	tw.tween_property(new, "volume_db", volume_db, fade)
	tw.tween_property(old, "volume_db", -60.0, fade)
	tw.chain().tween_callback(old.stop)


func stop_music(fade := 1.0) -> void:
	_current = ""
	var tw := create_tween()
	tw.tween_property(_music_a, "volume_db", -60.0, fade)


## Pitch the music down during slow-motion moments.
func set_music_pitch(p: float) -> void:
	_music_a.pitch_scale = clampf(p, 0.3, 2.0)


func _process(delta: float) -> void:
	# Music bends down during slow motion, then snaps back.
	var target := 1.0 if Engine.time_scale > 0.95 else lerpf(0.72, 1.0, Engine.time_scale)
	_music_a.pitch_scale = lerpf(_music_a.pitch_scale, target, clampf(delta / maxf(Engine.time_scale, 0.05) * 6.0, 0.0, 1.0))


func play(sfx_name: String, volume_db := 0.0, pitch_var := 0.05, pitch := 1.0) -> void:
	var stream := _load("res://audio/sfx/%s" % sfx_name)
	if stream == null:
		return
	var voice: AudioStreamPlayer = null
	for s in _sfx:
		if not s.playing:
			voice = s
			break
	if voice == null:
		voice = _sfx[randi() % _sfx.size()]
	voice.stream = stream
	voice.volume_db = volume_db
	voice.pitch_scale = pitch * (1.0 + randf_range(-pitch_var, pitch_var))
	voice.play()


func _load(base: String) -> AudioStream:
	if _cache.has(base):
		return _cache[base]
	var s: AudioStream = null
	for ext in [".ogg", ".wav"]:
		if ResourceLoader.exists(base + ext):
			s = load(base + ext)
			break
	_cache[base] = s
	return s


func _exit_tree() -> void:
	for p in _sfx + [_music_a, _music_b]:
		p.stop()
		p.stream = null
