extends Node
## Game (autoload): level flow, story, transitions, settings, hitstop & slow-mo.

const MAIN_MENU := "res://ui/main_menu.tscn"
const SELECT := "res://ui/character_select.tscn"
const STORY := "res://ui/story.tscn"
const ARENA := "res://levels/arena.tscn"

## Waves: each wave is a dictionary of enemy type -> count.
const LEVELS: Array[Dictionary] = [
	{
		"name": "NEON STREETS", "theme": 0,
		"waves": [{"minion": 4}, {"minion": 6}, {"minion": 7, "gunner": 1}],
	},
	{
		"name": "ROOFTOPS", "theme": 1,
		"waves": [{"minion": 4, "gunner": 2}, {"minion": 5, "gunner": 3}, {"minion": 5, "gunner": 4}],
	},
	{
		"name": "REACTOR CORE", "theme": 2,
		"waves": [{"minion": 4, "shield": 2}, {"minion": 4, "gunner": 3, "shield": 2}, {"minion": 6, "gunner": 3, "shield": 3}],
	},
	{
		"name": "THE WARDEN'S TOWER", "theme": 3, "boss": true, "waves": [],
	},
]

var fighter: int = Fighters.Id.VOLT
var current_level := 0
## Which story card to show next (see ui/story.gd).
var story_index := 0
var settings := {"sensitivity": 0.0025, "quality_high": true, "volume": 0.8}
var stats := {"kills": 0, "time": 0.0, "deaths": 0}
var run_active := false

var _fade: ColorRect
var _busy := false
var _slowmo_tween: Tween


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(_fade)
	_load_settings()


func _process(delta: float) -> void:
	if run_active and not get_tree().paused:
		stats.time += delta / maxf(Engine.time_scale, 0.05)


# --- flow ------------------------------------------------------------------

func new_run() -> void:
	stats = {"kills": 0, "time": 0.0, "deaths": 0}
	current_level = 0
	story_index = 0
	run_active = true
	change_scene(STORY)


## Story card finished -> go to the matching level (or the credits).
func story_finished() -> void:
	if story_index >= LEVELS.size():
		run_active = false
		change_scene(MAIN_MENU)
		return
	current_level = story_index
	change_scene(ARENA)


func level_complete() -> void:
	story_index = current_level + 1
	change_scene(STORY, 0.8)


func retry_level() -> void:
	stats.deaths += 1
	change_scene(ARENA, 0.4)


func go_to_menu() -> void:
	run_active = false
	change_scene(MAIN_MENU)


func change_scene(path: String, fade := 0.5) -> void:
	if _busy:
		return
	_busy = true
	reset_time()
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 1.0, fade)
	await tw.finished
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
	await get_tree().process_frame
	await get_tree().process_frame
	var tw2 := create_tween()
	tw2.tween_property(_fade, "color:a", 0.0, fade)
	await tw2.finished
	_busy = false


func is_busy() -> bool:
	return _busy


func flash_white(duration := 0.6) -> void:
	_fade.color = Color(1, 1, 1, 0.9)
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 0.0, duration)
	tw.tween_callback(func() -> void: _fade.color = Color(0, 0, 0, 0))


# --- time effects -------------------------------------------------------------

## Brief freeze on impact - the secret sauce of "crunchy" hits.
func hitstop(duration := 0.05) -> void:
	if _slowmo_tween != null and _slowmo_tween.is_valid():
		return
	Engine.time_scale = 0.05
	await get_tree().create_timer(duration, true, false, true).timeout
	if _slowmo_tween == null or not _slowmo_tween.is_valid():
		Engine.time_scale = 1.0


## Dramatic slow motion that eases back to normal.
func slowmo(scale := 0.25, duration := 1.0) -> void:
	if _slowmo_tween != null and _slowmo_tween.is_valid():
		_slowmo_tween.kill()
	Engine.time_scale = scale
	_slowmo_tween = create_tween().set_ignore_time_scale(true)
	_slowmo_tween.tween_interval(duration * 0.6)
	_slowmo_tween.tween_property(Engine, "time_scale", 1.0, duration * 0.4)


func reset_time() -> void:
	if _slowmo_tween != null and _slowmo_tween.is_valid():
		_slowmo_tween.kill()
	Engine.time_scale = 1.0


# --- settings -------------------------------------------------------------

func _load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://settings.cfg") == OK:
		for k in settings.keys():
			settings[k] = cfg.get_value("s", k, settings[k])
	_apply_volume()


func save_settings() -> void:
	var cfg := ConfigFile.new()
	for k in settings.keys():
		cfg.set_value("s", k, settings[k])
	cfg.save("user://settings.cfg")
	_apply_volume()


func _apply_volume() -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(float(settings.volume), 0.001)))


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F11:
		var full := DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if full else DisplayServer.WINDOW_MODE_FULLSCREEN)
