extends Kit
## JADE - wind spear. Long-reach spear combo, Gale Javelin, Cyclone Pull, Tempest.

var _spear: Node3D
var _combo := 0
var _combo_t := 0.0
const BASE_POS := Vector3(0.3, -0.36, -0.45)
const BASE_ROT := Vector3(0.12, 0.12, -0.5)


func build_viewmodel() -> void:
	q_cd_max = 5.0
	e_cd_max = 7.0
	_spear = Node3D.new()
	_spear.position = BASE_POS
	_spear.rotation = BASE_ROT
	vm.add_child(_spear)
	var shaft := Fx3D.neon_mat(Color(0.12, 0.1, 0.08), Color(0, 0, 0, 0), 0.0, 0.3, 0.5)
	var jade := Fx3D.neon_mat(Color(0.05, 0.3, 0.15), color, 0.6, 0.9, 0.15)
	make_mesh(cyl(0.022, 1.6), shaft, Vector3(0, 0, -0.35), _spear, Vector3(PI * 0.5, 0, 0))
	var tip := PrismMesh.new()
	tip.size = Vector3(0.09, 0.3, 0.025)
	make_mesh(tip, jade, Vector3(0, 0, -1.3), _spear, Vector3(-PI * 0.5, 0, 0))
	make_mesh(box(Vector3(0.006, 0.004, 0.28)), Fx3D.glow_mat(color, 3.0), Vector3(0, 0.016, -1.26), _spear)
	make_mesh(box(Vector3(0.12, 0.03, 0.04)), jade, Vector3(0, 0, -1.12), _spear)
	for k in 3:
		make_mesh(box(Vector3(0.012, 0.25 - k * 0.05, 0.012)), Fx3D.glow_mat(color, 2.0, 0.8), Vector3(0.03 * (k - 1), -0.13, -1.08), _spear)
	hand_light(_spear, 0.9).position = Vector3(0, 0, -1.2)


func process_kit(delta: float) -> void:
	_combo_t -= delta
	if _combo_t <= 0.0:
		_combo = 0
	var t := Time.get_ticks_msec() * 0.001
	if _spear.get_meta("idle", true):
		_spear.position.y = BASE_POS.y + sin(t * 2.0) * 0.008


func _thrust(dist: float, time: float) -> void:
	_spear.set_meta("idle", false)
	var tw := _spear.create_tween()
	tw.tween_property(_spear, "position", BASE_POS + Vector3(-0.15, 0.08, -dist), time * 0.35).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(_spear, "rotation", Vector3(0.05, 0.0, -0.1), time * 0.35)
	tw.tween_property(_spear, "position", BASE_POS, time * 0.65).set_trans(Tween.TRANS_QUAD)
	tw.parallel().tween_property(_spear, "rotation", BASE_ROT, time * 0.65)
	tw.tween_callback(func() -> void: _spear.set_meta("idle", true))


func primary(held: bool, just: bool) -> void:
	if primary_cd > 0.0 or not (just or held):
		return
	primary_cd = 0.27
	var sweep := _combo == 2
	var hits := 0
	if sweep:
		_spear.set_meta("idle", false)
		var tw := _spear.create_tween()
		tw.tween_property(_spear, "rotation", BASE_ROT + Vector3(0, 1.4, 0.6), 0.06)
		tw.tween_property(_spear, "rotation", BASE_ROT + Vector3(0, -1.2, -0.4), 0.12)
		tw.tween_property(_spear, "rotation", BASE_ROT, 0.15)
		tw.tween_callback(func() -> void: _spear.set_meta("idle", true))
		Fx3D.slash(player.cam, color, 10.0, 2.8, 0.22, true)
		hits = player.melee(4.6, 170.0, 30.0, true, 8.0)
		Audio.play("swing_heavy", -4.0, 0.08)
	else:
		_thrust(0.45, 0.22)
		hits = player.melee(4.6, 75.0, 17.0, false, 3.0)
		var tip := player.aim_origin() + player.aim_dir() * 2.5
		Fx3D.ring(world(), tip, color, 0.5, 0.15, 0.2, false)
		Audio.play("swing", -6.0, 0.1)
	if hits > 0:
		Audio.play("spear_hit", -4.0, 0.1)
	_combo = (_combo + 1) % 3
	_combo_t = 0.8


func skill1_press() -> void:
	if q_cd > 0.0:
		cooldown_denied()
		return
	q_cd = q_cd_max
	_thrust(0.6, 0.3)
	var from := player.aim_origin() + player.aim_dir() * 0.8
	var target := player.aim_point(60.0)
	var p := Projectile.spawn(world(), from, (target - from).normalized() * 48.0, 0, 38.0, color, 0.28)
	p.pierce = true
	p.heavy = true
	p.lifetime = 1.4
	p.light_energy = 3.0
	p.source = player
	Audio.play("wind", -2.0)
	callout("GALE JAVELIN!")


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var c := player.global_position
	for e in player.enemies():
		if e.global_position.distance_to(c) < 10.0:
			if e.has_method("pull"):
				e.pull(c + player.aim_dir() * 2.0, 16.0)
			var dealt: float = e.take_hit(20.0 * player.damage_mult, Vector3.ZERO, false, c)
			player.register_hit(e, dealt, e.aim_point(), false)
	Fx3D.ring(world(), c + Vector3(0, 0.2, 0), color, 10.0, 0.5, 0.06)
	Fx3D.ring(world(), c + Vector3(0, 1.0, 0), Color(0.8, 1.0, 0.9), 7.0, 0.4, 0.04)
	Fx3D.sparks(world(), c + Vector3(0, 1, 0), color, 50, 10.0, 0.08, 0.6, 2.0)
	player.add_shake(0.25)
	Audio.play("wind", 0.0, 0.0, 0.8)
	callout("CYCLONE PULL!")


func ultimate() -> void:
	start_ult(5.0, "TEMPEST!!")
	var t := Tornado.new()
	t.player = player
	t.color = color
	t.direction = Vector3(player.aim_dir().x, 0, player.aim_dir().z).normalized()
	world().add_child(t)
	t.global_position = player.global_position + t.direction * 6.5
	Audio.play("tornado", 0.0)


## A roaming tornado that drags robots into its eye and shreds them.
class Tornado extends Node3D:
	var player: Player
	var color := Color.GREEN
	var direction := Vector3.FORWARD
	var _life := 5.0
	var _tick := 0.0
	var _rings: Array[MeshInstance3D] = []

	func _ready() -> void:
		for k in 6:
			var mi := MeshInstance3D.new()
			var t := TorusMesh.new()
			t.inner_radius = 0.6 + k * 0.45
			t.outer_radius = 0.75 + k * 0.5
			mi.mesh = t
			mi.material_override = Fx3D.glow_mat(color.lerp(Color.WHITE, k * 0.08), 0.9, 0.35)
			mi.position.y = 0.3 + k * 0.9
			add_child(mi)
			_rings.append(mi)
		var p := GPUParticles3D.new()
		p.amount = 160
		p.lifetime = 1.2
		var pm := ParticleProcessMaterial.new()
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_RING
		pm.emission_ring_axis = Vector3.UP
		pm.emission_ring_radius = 1.6
		pm.emission_ring_inner_radius = 0.4
		pm.emission_ring_height = 0.5
		pm.direction = Vector3.UP
		pm.spread = 10.0
		pm.initial_velocity_min = 3.0
		pm.initial_velocity_max = 6.0
		pm.orbit_velocity_min = 0.8
		pm.orbit_velocity_max = 1.4
		pm.gravity = Vector3.ZERO
		p.process_material = pm
		var q := QuadMesh.new()
		q.size = Vector2(0.12, 0.12)
		var m := Fx3D.glow_mat(color, 1.8)
		m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
		q.material = m
		p.draw_pass_1 = q
		add_child(p)
		var l := OmniLight3D.new()
		l.light_color = color
		l.light_energy = 2.5
		l.omni_range = 9.0
		l.light_volumetric_fog_energy = 0.2
		l.position.y = 2.0
		add_child(l)

	func _physics_process(delta: float) -> void:
		_life -= delta
		if _life <= 0.0 or player == null or not is_instance_valid(player):
			queue_free()
			return
		global_position += direction * 5.0 * delta
		var r := Vector2(global_position.x, global_position.z)
		if r.length() > 20.0:
			direction = (-Vector3(r.x, 0, r.y)).normalized().rotated(Vector3.UP, 0.6)
		for i in _rings.size():
			_rings[i].rotate_y(delta * (6.0 + i * 1.5))
			_rings[i].position.x = sin(Time.get_ticks_msec() * 0.003 + i) * 0.15 * i
		_tick -= delta
		if _tick <= 0.0:
			_tick = 0.15
			var c := global_position + Vector3(0, 1.0, 0)
			for e in player.enemies():
				if e.global_position.distance_to(global_position) < 4.5:
					if e.has_method("pull"):
						e.pull(global_position, 7.0)
			player.area_damage(c, 3.2, 9.0, true, 1.0)
