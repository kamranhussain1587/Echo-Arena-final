extends Control
## Title screen over a live, slowly orbiting arena.

var _title: Label
var _ghost_a: Label
var _ghost_b: Label
var _box: VBoxContainer
var _controls: Control
var _quality_btn: Button
var _t := 0.0


func _ready() -> void:
	get_tree().paused = false
	Game.reset_time()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	var bg: Arena = load("res://levels/arena.gd").new()
	bg.menu_mode = true
	bg.theme_index = 0
	add_child(bg)

	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0.02, 0.25)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)

	_ghost_a = _make_title(Color(0.2, 0.95, 1.0, 0.6))
	_ghost_b = _make_title(Color(1.0, 0.2, 0.55, 0.6))
	_title = _make_title(Color.WHITE)
	_title.add_theme_color_override("font_shadow_color", Color(1, 0.25, 0.5, 0.8))
	_title.add_theme_constant_override("shadow_outline_size", 22)
	var sub := UIKit.label("FOUR FIGHTERS.  ONE TOWER.  NO MERCY.", 20, UIKit.GOLD, true, Color(1, 0.6, 0.2, 0.4))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.position = Vector2(0, 228)
	sub.size = Vector2(1280, 30)
	add_child(sub)

	_box = VBoxContainer.new()
	_box.position = Vector2(640 - 170, 300)
	_box.custom_minimum_size = Vector2(340, 0)
	_box.add_theme_constant_override("separation", 12)
	add_child(_box)
	var play := UIKit.button(_box, "PLAY", _on_play, 340)
	UIKit.button(_box, "CONTROLS", _on_controls, 340)
	_quality_btn = UIKit.button(_box, "", _on_quality, 340)
	_update_quality_text()
	if OS.get_name() != "Web":
		UIKit.button(_box, "QUIT", _on_quit, 340)
	play.grab_focus.call_deferred()

	var foot := UIKit.label("ECHO ARENA  -  a first-person anime brawler  -  made with Godot 4", 13, Color(UIKit.DIM, 0.8))
	foot.position = Vector2(24, 690)
	add_child(foot)
	_build_controls()
	Audio.play_music("menu")


func _make_title(c: Color) -> Label:
	var l := UIKit.label("ECHO ARENA", 104, c, true)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.position = Vector2(0, 90)
	l.size = Vector2(1280, 130)
	add_child(l)
	return l


func _process(delta: float) -> void:
	_t += delta
	var glitch := fmod(_t, 3.5) < 0.1
	_ghost_a.position.x = -4.0 + (randf_range(-6, 6) if glitch else 0.0)
	_ghost_b.position.x = 4.0 + (randf_range(-6, 6) if glitch else 0.0)
	_title.scale = Vector2.ONE * (1.0 + sin(_t * 2.0) * 0.008)
	_title.pivot_offset = Vector2(640, 65)


func _build_controls() -> void:
	_controls = Control.new()
	_controls.set_anchors_preset(Control.PRESET_FULL_RECT)
	_controls.visible = false
	add_child(_controls)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0.03, 0.88)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	_controls.add_child(dim)
	var box := VBoxContainer.new()
	box.position = Vector2(640 - 300, 90)
	box.custom_minimum_size = Vector2(600, 0)
	box.add_theme_constant_override("separation", 8)
	_controls.add_child(box)
	var t := UIKit.label("CONTROLS", 44, Color.WHITE, true, Color(1, 0.3, 0.5, 0.6))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(t)
	var rows := [
		["W A S D", "move"], ["MOUSE", "look"], ["LEFT CLICK", "attack (hold for auto)"],
		["RIGHT CLICK", "block  -  tap just before a hit to PARRY"], ["SHIFT", "flash step dash"],
		["SPACE", "jump  (press again for double jump)"], ["Q", "skill 1  (VOLT: hold to charge)"],
		["E", "skill 2"], ["F", "ULTIMATE when the bar is full"], ["ESC", "pause"], ["F11", "fullscreen"],
	]
	for row in rows:
		var hb := HBoxContainer.new()
		var k := UIKit.label(row[0], 20, UIKit.HOT, true)
		k.custom_minimum_size = Vector2(230, 0)
		hb.add_child(k)
		hb.add_child(UIKit.label(row[1], 20, UIKit.TEXT))
		box.add_child(hb)
	var sp := Control.new()
	sp.custom_minimum_size = Vector2(0, 10)
	box.add_child(sp)
	UIKit.button(box, "BACK", _on_back, 600)


func _on_play() -> void:
	Game.change_scene(Game.SELECT)


func _on_controls() -> void:
	_controls.visible = true
	_box.visible = false
	(_controls.get_child(1).get_child(_controls.get_child(1).get_child_count() - 1) as Button).grab_focus()


func _on_back() -> void:
	_controls.visible = false
	_box.visible = true
	(_box.get_child(0) as Button).grab_focus()


func _on_quality() -> void:
	Game.settings.quality_high = not bool(Game.settings.quality_high)
	Game.save_settings()
	_update_quality_text()


func _update_quality_text() -> void:
	_quality_btn.text = "GRAPHICS:  " + ("ULTRA" if Game.settings.quality_high else "PERFORMANCE")


func _on_quit() -> void:
	get_tree().quit()


func _unhandled_input(event: InputEvent) -> void:
	if _controls.visible and (event.is_action_pressed("ui_cancel") or event.is_action_pressed("pause")):
		get_viewport().set_input_as_handled()
		_on_back()
