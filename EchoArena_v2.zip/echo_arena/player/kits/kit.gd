class_name Kit
extends Node
## Base class for a fighter's moveset + first-person viewmodel.
## Subclasses override build_viewmodel / primary / skill1_* / skill2 / ultimate.

var player: Player
var vm: Node3D
var color: Color
var q_cd := 0.0
var e_cd := 0.0
var q_cd_max := 6.0
var e_cd_max := 7.0
var primary_cd := 0.0
var ult_active := 0.0


func setup(p: Player) -> void:
	player = p
	color = Fighters.color(p.fighter)
	vm = Node3D.new()
	p.vm_root.add_child(vm)
	build_viewmodel()


func physics(delta: float) -> void:
	q_cd = maxf(q_cd - delta, 0.0)
	e_cd = maxf(e_cd - delta, 0.0)
	primary_cd = maxf(primary_cd - delta, 0.0)
	if ult_active > 0.0:
		ult_active -= delta
		if ult_active <= 0.0:
			end_ultimate()
	process_kit(delta)


## Cooldown fractions for the HUD (0 = ready).
func q_fraction() -> float:
	return q_cd / q_cd_max if q_cd_max > 0.0 else 0.0


func e_fraction() -> float:
	return e_cd / e_cd_max if e_cd_max > 0.0 else 0.0


# --- overridable moves (defaults do nothing on purpose) ---------------------

func build_viewmodel() -> void:
	pass


func process_kit(_delta: float) -> void:
	pass


func primary(_held: bool, _just: bool) -> void:
	pass


func skill1_press() -> void:
	pass


func skill1_release() -> void:
	pass


func skill2() -> void:
	pass


func ultimate() -> void:
	pass


func end_ultimate() -> void:
	if player.overlay != null:
		player.overlay.set_aura(Color(0, 0, 0, 0))


func on_landed() -> void:
	pass


# --- helpers ------------------------------------------------------------------

func world() -> Node:
	return player.get_parent()


func callout(text: String, big := false) -> void:
	if player.hud != null:
		player.hud.callout(text, color, big)
	Audio.play("callout", -8.0)


func cooldown_denied() -> void:
	Audio.play("denied", -12.0)


func start_ult(duration: float, title: String) -> void:
	ult_active = duration
	callout(title, true)
	Audio.play("ult", 0.0)
	Game.slowmo(0.3, 0.7)
	player.add_shake(0.4)
	Fx3D.ring(world(), player.global_position + Vector3(0, 0.15, 0), color, 9.0, 0.5, 0.04)
	Fx3D.sparks(world(), player.global_position + Vector3(0, 1.0, 0), color, 30, 9.0, 0.08, 0.9, -2.0)
	if player.overlay != null:
		player.overlay.set_aura(color)
		player.overlay.speed_burst(1.0)


func make_mesh(mesh: Mesh, mat: Material, pos: Vector3, parent: Node3D = null, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation = rot
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	(parent if parent != null else vm).add_child(mi)
	return mi


func box(size: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = size
	return b


func cyl(radius: float, height: float, top := -1.0) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = radius if top < 0.0 else top
	c.bottom_radius = radius
	c.height = height
	c.radial_segments = 16
	return c


func sphere(radius: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 16
	s.rings = 8
	return s


func hand_light(parent: Node3D, energy := 1.2) -> OmniLight3D:
	var l := OmniLight3D.new()
	l.light_color = color
	l.light_energy = energy * 0.35
	l.omni_range = 1.6
	l.light_volumetric_fog_energy = 0.0
	l.light_specular = 0.2
	parent.add_child(l)
	return l


## Quick "punch out and back" animation for a viewmodel part.
func jab(node: Node3D, offset: Vector3, out_time := 0.06, back_time := 0.14) -> void:
	var base: Vector3 = node.get_meta("base_pos", node.position)
	node.set_meta("base_pos", base)
	var tw := node.create_tween()
	tw.tween_property(node, "position", base + offset, out_time).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_property(node, "position", base, back_time).set_trans(Tween.TRANS_QUAD)
