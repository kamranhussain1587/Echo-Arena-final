class_name Fx3D
extends RefCounted
## Self-cleaning 3D effects built from primitives: glow materials, sparks,
## explosions, shockwave rings, beams, slashes, damage numbers.

static var _arc_mesh: ArrayMesh
static var _font: Font


## Unshaded additive HDR material: anything using it blooms.
static func glow_mat(color: Color, energy := 4.0, alpha := 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(color.r * energy, color.g * energy, color.b * energy, alpha)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	m.vertex_color_use_as_albedo = true
	return m


## Lit material with emissive glow (for solid objects like enemies & props).
static func neon_mat(base: Color, glow: Color, energy := 3.0, metallic := 0.6, roughness := 0.35) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = base
	m.metallic = metallic
	m.roughness = roughness
	m.emission_enabled = glow.a > 0.0
	m.emission = Color(glow.r, glow.g, glow.b)
	m.emission_energy_multiplier = energy
	m.rim_enabled = true
	m.rim = 0.25
	m.rim_tint = 0.6
	return m


static func _add(parent: Node, n: Node3D, pos: Vector3) -> bool:
	if parent == null or not parent.is_inside_tree():
		n.free()
		return false
	parent.add_child(n)
	n.global_position = pos
	return true


static func sparks(parent: Node, pos: Vector3, color: Color, amount := 24, speed := 8.0, size := 0.07, lifetime := 0.5, gravity := -12.0) -> void:
	var p := GPUParticles3D.new()
	p.one_shot = true
	p.explosiveness = 0.95
	p.amount = amount
	p.lifetime = lifetime
	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3.UP
	pm.spread = 180.0
	pm.initial_velocity_min = speed * 0.4
	pm.initial_velocity_max = speed
	pm.gravity = Vector3(0, gravity, 0)
	pm.damping_min = 2.0
	pm.damping_max = 4.0
	pm.scale_min = 0.5
	pm.scale_max = 1.3
	var curve := Curve.new()
	curve.add_point(Vector2(0, 1))
	curve.add_point(Vector2(1, 0))
	var ct := CurveTexture.new()
	ct.curve = curve
	pm.scale_curve = ct
	p.process_material = pm
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	var m := glow_mat(color, 6.0)
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = m
	p.draw_pass_1 = q
	if _add(parent, p, pos):
		p.emitting = true
		p.finished.connect(p.queue_free)


static func flash_light(parent: Node, pos: Vector3, color: Color, energy := 6.0, light_range := 8.0, duration := 0.3) -> void:
	var l := OmniLight3D.new()
	l.light_color = color
	l.light_energy = energy
	l.omni_range = light_range
	l.light_volumetric_fog_energy = 2.0
	if not _add(parent, l, pos):
		return
	var tw := l.create_tween()
	tw.tween_property(l, "light_energy", 0.0, duration)
	tw.tween_callback(l.queue_free)


## Expanding glowing ring (shockwaves, impacts).
static func ring(parent: Node, pos: Vector3, color: Color, max_radius := 4.0, duration := 0.45, thickness := 0.12, flat := true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var t := TorusMesh.new()
	t.inner_radius = 1.0 - thickness
	t.outer_radius = 1.0
	t.rings = 48
	t.ring_segments = 6
	mi.mesh = t
	var m := glow_mat(color, 5.0)
	mi.material_override = m
	mi.scale = Vector3.ONE * 0.1
	if not flat:
		mi.rotation.x = PI * 0.5
	if not _add(parent, mi, pos):
		return null
	var tw := mi.create_tween().set_parallel(true)
	tw.tween_property(mi, "scale", Vector3(max_radius, max_radius * (1.0 if flat else 1.0), max_radius), duration).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(m, "albedo_color:a", 0.0, duration)
	tw.chain().tween_callback(mi.queue_free)
	return mi


static func explosion(parent: Node, pos: Vector3, color: Color, radius := 2.5) -> void:
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 1.0
	s.height = 2.0
	s.radial_segments = 24
	s.rings = 12
	mi.mesh = s
	var m := glow_mat(color, 4.0, 0.9)
	mi.material_override = m
	mi.scale = Vector3.ONE * 0.2
	if not _add(parent, mi, pos):
		return
	var tw := mi.create_tween().set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * radius, 0.35).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_OUT)
	tw.tween_property(m, "albedo_color:a", 0.0, 0.4)
	tw.chain().tween_callback(mi.queue_free)
	sparks(parent, pos, color, 40, 10.0 * radius * 0.4, 0.12, 0.8)
	sparks(parent, pos, Color(1, 0.9, 0.7), 20, 6.0, 0.06, 0.4)
	ring(parent, pos, color, radius * 1.6, 0.5, 0.1)
	flash_light(parent, pos, color, 10.0, radius * 5.0, 0.45)


## A straight energy beam between two points that thins out and vanishes.
static func beam(parent: Node, from: Vector3, to: Vector3, color: Color, width := 0.35, duration := 0.35) -> void:
	var length := from.distance_to(to)
	if length < 0.01:
		return
	var root := Node3D.new()
	if not _add(parent, root, from):
		return
	root.look_at(to, Vector3.UP if absf((to - from).normalized().y) < 0.99 else Vector3.RIGHT)
	for layer in 2:
		var mi := MeshInstance3D.new()
		var c := CylinderMesh.new()
		c.top_radius = width * (1.0 if layer == 0 else 0.45)
		c.bottom_radius = c.top_radius
		c.height = length
		c.radial_segments = 16
		mi.mesh = c
		mi.material_override = glow_mat(color if layer == 0 else Color(1, 1, 1), 3.0 if layer == 0 else 6.0, 0.8)
		mi.rotation.x = -PI * 0.5
		mi.position = Vector3(0, 0, -length * 0.5)
		root.add_child(mi)
	var tw := root.create_tween()
	tw.tween_property(root, "scale", Vector3(0.0, 0.0, 1.0), duration).set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
	tw.tween_callback(root.queue_free)
	var mid := (from + to) * 0.5
	flash_light(parent, mid, color, 8.0, length * 0.6, duration)


## Glowing sword-swing streak, drawn in front of the camera.
static func slash(cam: Node3D, color: Color, roll_deg := 0.0, radius := 2.2, duration := 0.22, flip := false) -> void:
	if cam == null or not cam.is_inside_tree():
		return
	if _arc_mesh == null:
		_arc_mesh = _build_arc()
	var mi := MeshInstance3D.new()
	mi.mesh = _arc_mesh
	var m := glow_mat(color, 5.0)
	mi.material_override = m
	cam.add_child(mi)
	mi.position = Vector3(0, -0.25, -0.4)
	mi.rotation = Vector3(0, 0, deg_to_rad(roll_deg))
	mi.scale = Vector3(-radius if flip else radius, radius, radius)
	var tw := mi.create_tween().set_parallel(true)
	tw.tween_property(mi, "rotation:y", deg_to_rad(-25.0 if flip else 25.0), duration)
	tw.tween_property(m, "albedo_color:a", 0.0, duration).set_ease(Tween.EASE_IN)
	tw.chain().tween_callback(mi.queue_free)


static func _build_arc() -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var segs := 28
	var a0 := deg_to_rad(-75.0)
	var a1 := deg_to_rad(75.0)
	for i in segs:
		var k0 := float(i) / segs
		var k1 := float(i + 1) / segs
		var t0 := lerpf(a0, a1, k0)
		var t1 := lerpf(a0, a1, k1)
		var w0 := sin(k0 * PI)
		var w1 := sin(k1 * PI)
		var in0 := Vector3(sin(t0), 0, -cos(t0)) * (1.0 - 0.28 * w0)
		var out0 := Vector3(sin(t0), 0, -cos(t0))
		var in1 := Vector3(sin(t1), 0, -cos(t1)) * (1.0 - 0.28 * w1)
		var out1 := Vector3(sin(t1), 0, -cos(t1))
		var c0 := Color(1, 1, 1, w0 * k0)
		var c1 := Color(1, 1, 1, w1 * k1)
		for v in [[in0, c0], [out0, c0], [out1, c1], [in0, c0], [out1, c1], [in1, c1]]:
			st.set_color(v[1])
			st.add_vertex(v[0])
	return st.commit()


static func damage_number(parent: Node, pos: Vector3, amount: float, color := Color.WHITE, big := false) -> void:
	var l := Label3D.new()
	l.text = str(int(round(amount)))
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.fixed_size = true
	l.pixel_size = 0.0009 if big else 0.0007
	l.font_size = 64
	l.outline_size = 14
	l.modulate = color
	l.outline_modulate = Color(0, 0, 0, 0.85)
	if _font == null and ResourceLoader.exists("res://fonts/Orbitron.ttf"):
		var fv := FontVariation.new()
		fv.base_font = load("res://fonts/Orbitron.ttf")
		fv.variation_opentype = {"wght": 900}
		_font = fv
	if _font != null:
		l.font = _font
	l.render_priority = 10
	if not _add(parent, l, pos + Vector3(randf_range(-0.3, 0.3), 0.3, randf_range(-0.3, 0.3))):
		return
	l.scale = Vector3.ONE * 0.4
	var tw := l.create_tween()
	tw.tween_property(l, "scale", Vector3.ONE * (1.5 if big else 1.15), 0.08)
	tw.tween_property(l, "scale", Vector3.ONE, 0.1)
	tw.parallel().tween_property(l, "global_position:y", pos.y + 1.4, 0.7).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.25)
	tw.tween_callback(l.queue_free)


const CIRCLE_SHADER := """
shader_type spatial;
render_mode unshaded, blend_add, cull_disabled, depth_draw_never, shadows_disabled;
uniform vec4 color : source_color = vec4(0.7, 0.4, 1.0, 1.0);
uniform float fade = 1.0;
uniform float energy = 4.0;
float line_d(vec2 p, vec2 a, vec2 b) {
	vec2 pa = p - a, ba = b - a;
	float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
	return length(pa - ba * h);
}
void fragment() {
	vec2 p = UV * 2.0 - 1.0;
	float r = length(p);
	float a = atan(p.y, p.x);
	float m = 0.0;
	m += smoothstep(0.025, 0.0, abs(r - 0.96));
	m += smoothstep(0.015, 0.0, abs(r - 0.86));
	m += smoothstep(0.012, 0.0, abs(r - 0.5));
	float spin = TIME * 0.6;
	float ticks = step(0.75, fract((a + spin) * 24.0 / 6.2831853));
	m += ticks * step(0.87, r) * step(r, 0.95) * 0.8;
	for (int i = 0; i < 6; i++) {
		float t0 = float(i) * 6.2831853 / 3.0 - spin * 0.5;
		float t1 = t0 + 6.2831853 / 3.0;
		float o = float(i / 3) * 3.14159265 / 3.0;
		vec2 A = vec2(cos(t0 + o), sin(t0 + o)) * 0.86;
		vec2 B = vec2(cos(t1 + o), sin(t1 + o)) * 0.86;
		m += smoothstep(0.012, 0.0, line_d(p, A, B)) * 0.9;
	}
	m += smoothstep(0.35, 0.0, r) * 0.25;
	m *= step(r, 1.0) * fade;
	ALBEDO = color.rgb * energy * m;
	ALPHA = clamp(m, 0.0, 1.0);
}
"""

static var _circle_shader: Shader


## Rotating magic circle (Hex's sigils), lies flat on the ground or in the sky.
static func magic_circle(parent: Node, pos: Vector3, radius: float, color: Color, duration := 1.5) -> void:
	if _circle_shader == null:
		_circle_shader = Shader.new()
		_circle_shader.code = CIRCLE_SHADER
	var mi := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(radius * 2.0, radius * 2.0)
	mi.mesh = plane
	var m := ShaderMaterial.new()
	m.shader = _circle_shader
	m.set_shader_parameter("color", color)
	m.set_shader_parameter("fade", 0.0)
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	if not _add(parent, mi, pos):
		return
	var tw := mi.create_tween()
	tw.tween_method(func(v: float) -> void: m.set_shader_parameter("fade", v), 0.0, 1.0, 0.2)
	tw.parallel().tween_property(mi, "rotation:y", PI * 0.5, duration)
	tw.tween_method(func(v: float) -> void: m.set_shader_parameter("fade", v), 1.0, 0.0, 0.4)
	tw.tween_callback(mi.queue_free)
	var l := OmniLight3D.new()
	l.light_color = color
	l.light_energy = 3.0
	l.omni_range = radius * 1.5
	mi.add_child(l)
	l.position = Vector3(0, 0.8, 0)


static func clear_cache() -> void:
	_circle_shader = null
	_arc_mesh = null
	_font = null
