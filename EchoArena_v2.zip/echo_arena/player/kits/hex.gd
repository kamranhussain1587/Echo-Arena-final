extends Kit
## HEX - magic. Homing arcane orbs, Frost Sigil, Blink, Meteor Rain.

const ICE := Color(0.55, 0.9, 1.0)

var _staff: Node3D
var _crystal: MeshInstance3D
var _rune: MeshInstance3D
var _meteor_t := 0.0
var _meteors_left := 0
var _sky_center := Vector3.ZERO


func build_viewmodel() -> void:
	q_cd_max = 8.0
	e_cd_max = 3.5
	_staff = Node3D.new()
	_staff.position = Vector3(0.42, -0.62, -0.75)
	_staff.rotation = Vector3(0.45, 0, -0.35)
	vm.add_child(_staff)
	make_mesh(cyl(0.022, 1.1, 0.03), Fx3D.neon_mat(Color(0.12, 0.08, 0.16), Color(0, 0, 0, 0), 0.0, 0.3, 0.5), Vector3(0, 0.2, 0), _staff)
	make_mesh(cyl(0.05, 0.04), Fx3D.neon_mat(Color(0.3, 0.25, 0.1), Color(1, 0.8, 0.4), 1.0, 1.0, 0.2), Vector3(0, 0.73, 0), _staff)
	var prism := PrismMesh.new()
	prism.size = Vector3(0.1, 0.18, 0.1)
	_crystal = make_mesh(prism, Fx3D.glow_mat(color, 2.5), Vector3(0, 0.86, 0), _staff)
	hand_light(_staff, 1.4).position = Vector3(0, 0.86, 0)
	var torus := TorusMesh.new()
	torus.inner_radius = 0.06
	torus.outer_radius = 0.075
	_rune = make_mesh(torus, Fx3D.glow_mat(color, 2.0), Vector3(-0.36, -0.36, -0.7), null, Vector3(PI * 0.5, 0, 0))
	_rune.scale = Vector3.ONE * 0.6


func process_kit(delta: float) -> void:
	var t := Time.get_ticks_msec() * 0.001
	_crystal.rotation.y = t * 2.0
	_crystal.position.y = 0.86 + sin(t * 3.0) * 0.015
	_rune.rotation.z = t * 3.0
	if _meteors_left > 0:
		_meteor_t -= delta
		if _meteor_t <= 0.0:
			_meteor_t = 0.2
			_meteors_left -= 1
			_drop_meteor()


func primary(held: bool, _just: bool) -> void:
	if not held or primary_cd > 0.0:
		return
	primary_cd = 0.36
	var tw := _staff.create_tween()
	tw.tween_property(_staff, "position:z", -0.9, 0.05)
	tw.tween_property(_staff, "position:z", -0.75, 0.15)
	var from := _crystal.global_position
	var target := player.aim_point(80.0)
	var p := Projectile.spawn(world(), from, (target - from).normalized() * 26.0, 0, 17.0, color, 0.2)
	p.source = player
	p.homing_target = player.nearest_enemy(45.0, true)
	p.homing_turn = 5.0
	p.lifetime = 4.0
	Audio.play("orb", -8.0, 0.1)


func skill1_press() -> void:
	if q_cd > 0.0:
		cooldown_denied()
		return
	q_cd = q_cd_max
	var pt := player.aim_point(20.0)
	pt.y = player.global_position.y + 0.05
	Fx3D.magic_circle(world(), pt, 4.5, ICE, 1.6)
	Fx3D.sparks(world(), pt + Vector3(0, 0.3, 0), ICE, 40, 5.0, 0.08, 1.0, 2.0)
	Fx3D.flash_light(world(), pt + Vector3(0, 1, 0), ICE, 6.0, 9.0, 1.0)
	for e in player.enemies():
		var d: float = Vector2(e.global_position.x - pt.x, e.global_position.z - pt.z).length()
		if d < 4.5 + e.hit_radius:
			e.freeze(3.0)
			var dealt: float = e.take_hit(15.0 * player.damage_mult, Vector3.ZERO, false, pt)
			player.register_hit(e, dealt, e.aim_point(), false)
	Audio.play("freeze", -2.0)
	callout("FROST SIGIL!")


func skill2() -> void:
	if e_cd > 0.0:
		cooldown_denied()
		return
	e_cd = e_cd_max
	var dir := Vector3(player.aim_dir().x, 0, player.aim_dir().z).normalized()
	var from := player.global_position + Vector3(0, 0.9, 0)
	var q := PhysicsRayQueryParameters3D.create(from, from + dir * 8.0, 1, [player.get_rid()])
	var hit := player.get_world_3d().direct_space_state.intersect_ray(q)
	var dist := 8.0
	if not hit.is_empty():
		dist = maxf(from.distance_to(hit.position) - 0.7, 0.0)
	Fx3D.sparks(world(), from, color, 24, 4.0, 0.07, 0.4, 0.0)
	Fx3D.ring(world(), player.global_position + Vector3(0, 0.1, 0), color, 1.5, 0.3, 0.12)
	player.global_position += dir * dist
	player.invuln = maxf(player.invuln, 0.25)
	Fx3D.sparks(world(), player.global_position + Vector3(0, 0.9, 0), color, 24, 4.0, 0.07, 0.4, 0.0)
	Fx3D.ring(world(), player.global_position + Vector3(0, 0.1, 0), color, 1.8, 0.3, 0.12)
	if player.overlay != null:
		player.overlay.speed_burst(0.5)
	Audio.play("blink", -4.0)


func ultimate() -> void:
	start_ult(3.2, "METEOR RAIN!!")
	_sky_center = player.global_position + Vector3(0, 20.0, 0) + Vector3(player.aim_dir().x, 0, player.aim_dir().z) * 8.0
	Fx3D.magic_circle(world(), _sky_center, 15.0, color, 3.6)
	_meteors_left = 15
	_meteor_t = 0.35


func _drop_meteor() -> void:
	var list := player.enemies()
	var target: Vector3
	if list.is_empty():
		target = Vector3(_sky_center.x + randf_range(-10, 10), player.global_position.y, _sky_center.z + randf_range(-10, 10))
	else:
		var e: Node3D = list[randi() % list.size()]
		target = e.aim_point() + Vector3(randf_range(-1.5, 1.5), 0, randf_range(-1.5, 1.5))
	var from := _sky_center + Vector3(randf_range(-8, 8), 0, randf_range(-8, 8))
	var p := Projectile.spawn(world(), from, (target - from).normalized() * 32.0, 0, 40.0, Color(1.0, 0.55, 0.9), 0.55)
	p.explode_radius = 3.2
	p.heavy = true
	p.source = player
	p.light_energy = 4.0
	Audio.play("meteor", -8.0, 0.15)
