class_name Overlay
extends CanvasLayer
## Full-screen anime post effects: speed lines, chromatic aberration on hits,
## ultimate aura around the screen edge, "time stop" desaturation, low-HP pulse.

const SHADER := """
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_linear;
uniform float speed = 0.0;
uniform float damage = 0.0;
uniform vec4 aura = vec4(0.0);
uniform float stop = 0.0;
uniform float low_hp = 0.0;
float hash(float n) { return fract(sin(n) * 43758.5453); }
void fragment() {
	vec2 uv = SCREEN_UV;
	vec2 d = uv - 0.5;
	float r = length(d * vec2(1.6, 1.0));
	float ab = 0.0015 + damage * 0.012 + speed * 0.006;
	vec3 col;
	col.r = texture(screen_tex, uv + d * ab).r;
	col.g = texture(screen_tex, uv).g;
	col.b = texture(screen_tex, uv - d * ab).b;
	float ang = atan(d.y, d.x);
	float lines = step(0.8, hash(floor(ang * 70.0) + floor(TIME * 24.0) * 13.0));
	col = mix(col, vec3(1.0), lines * smoothstep(0.38, 0.95, r) * speed * 0.55);
	float g = dot(col, vec3(0.299, 0.587, 0.114));
	col = mix(col, vec3(g) * vec3(0.75, 0.88, 1.15) + vec3(0.0, 0.02, 0.05), stop * 0.9);
	col += aura.rgb * aura.a * smoothstep(0.5, 1.05, r) * (0.55 + 0.45 * sin(TIME * 7.0));
	float vig = smoothstep(0.55, 1.1, r);
	col *= 1.0 - vig * 0.45;
	col = mix(col, vec3(0.75, 0.0, 0.05), vig * clamp(damage * 0.9 + low_hp * (0.35 + 0.2 * sin(TIME * 5.0)), 0.0, 0.9));
	COLOR = vec4(col, 1.0);
}
"""

var _mat: ShaderMaterial
var _speed := 0.0
var _damage := 0.0
var _stop := 0.0
var _stop_t := 0.0
var _aura := Color(0, 0, 0, 0)
var _player: Player


func _init() -> void:
	layer = 4


func _ready() -> void:
	var rect := ColorRect.new()
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sh := Shader.new()
	sh.code = SHADER
	_mat = ShaderMaterial.new()
	_mat.shader = sh
	rect.material = _mat
	add_child(rect)


func _process(delta: float) -> void:
	var rd := delta / maxf(Engine.time_scale, 0.05)
	if _player == null:
		_player = get_tree().get_first_node_in_group("player") as Player
	_speed = move_toward(_speed, 0.0, rd * 2.0)
	_damage = move_toward(_damage, 0.0, rd * 2.5)
	if _stop_t > 0.0:
		_stop_t -= rd
		_stop = move_toward(_stop, 1.0, rd * 8.0)
	else:
		_stop = move_toward(_stop, 0.0, rd * 3.0)
	var aura_speed := _aura.a > 0.0
	var low := 0.0
	if _player != null:
		low = clampf(1.0 - _player.hp / (_player.max_hp * 0.35), 0.0, 1.0) if _player.alive else 1.0
	_mat.set_shader_parameter("speed", maxf(_speed, 0.35 if aura_speed else 0.0))
	_mat.set_shader_parameter("damage", _damage)
	_mat.set_shader_parameter("stop", _stop)
	_mat.set_shader_parameter("aura", _aura)
	_mat.set_shader_parameter("low_hp", low)


func speed_burst(amount := 1.0) -> void:
	_speed = maxf(_speed, amount)


func damage_flash(amount := 0.6) -> void:
	_damage = maxf(_damage, amount)


func set_aura(c: Color) -> void:
	_aura = Color(c.r, c.g, c.b, 0.55) if c.a > 0.0 else Color(0, 0, 0, 0)


func time_stop(duration: float) -> void:
	_stop_t = duration
